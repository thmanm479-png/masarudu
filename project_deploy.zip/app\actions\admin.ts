"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { getSession } from "@/lib/auth";

// Helper for auth check
async function checkAuth() {
    const session = await getSession();
    if (!session) {
        throw new Error("Unauthorized");
    }
}

// --- DELETE ACTIONS ---

export async function deleteClient(id: number) {
    try {
        await checkAuth();
        await prisma.client.delete({
            where: { id },
        });
        revalidatePath("/admin/clients");
        return { success: true };
    } catch (error) {
        console.error("Failed to delete client:", error);
        return { success: false, error: "فشل حذف العميل" };
    }
}

export async function deleteAgent(id: number) {
    try {
        await checkAuth();
        await prisma.agent.delete({
            where: { id },
        });
        revalidatePath("/admin/agents");
        return { success: true };
    } catch (error) {
        console.error("Failed to delete agent:", error);
        return { success: false, error: "فشل حذف الوكيل" };
    }
}

export async function deleteEmployee(id: number) {
    try {
        await checkAuth();
        await prisma.employee.delete({
            where: { id },
        });
        revalidatePath("/admin/employees");
        return { success: true };
    } catch (error) {
        console.error("Failed to delete employee:", error);
        return { success: false, error: "فشل حذف الموظف" };
    }
}

// --- UPDATE ACTIONS ---

export async function updateClient(id: number, data: any) {
    try {
        await checkAuth();
        await prisma.client.update({
            where: { id },
            data: {
                fullName: data.fullName,
                phone: data.phone,
                email: data.email,
                nationality: data.nationality,
                certificateType: data.certificateType,
                gpa: data.gpa,
                desiredMajor: data.desiredMajor,
                universityType: data.universityType,
                notes: data.notes,
                status: data.status,
            },
        });
        revalidatePath(`/admin/clients/${id}`);
        revalidatePath("/admin/clients");
        return { success: true };
    } catch (error) {
        console.error("Failed to update client:", error);
        return { success: false, error: "فشل تحديث بيانات العميل" };
    }
}

export async function updateAgent(id: number, data: any) {
    try {
        await checkAuth();
        await prisma.agent.update({
            where: { id },
            data: {
                fullName: data.fullName,
                phone: data.phone,
                email: data.email,
                city: data.city,
                status: data.status,
                paymentMethod: data.paymentMethod,
                paymentDetails: data.paymentDetails,
            },
        });
        revalidatePath(`/admin/agents/${id}`);
        revalidatePath("/admin/agents");
        return { success: true };
    } catch (error) {
        console.error("Failed to update agent:", error);
        return { success: false, error: "فشل تحديث بيانات الوكيل" };
    }
}

export async function updateEmployee(id: number, data: any) {
    try {
        await checkAuth();
        await prisma.employee.update({
            where: { id },
            data: {
                fullName: data.fullName,
                phone: data.phone,
                email: data.email,
                role: data.role,
                status: data.status,
            },
        });
        revalidatePath(`/admin/employees/${id}`);
        revalidatePath("/admin/employees");
        return { success: true };
    } catch (error) {
        console.error("Failed to update employee:", error);
        return { success: false, error: "فشل تحديث بيانات الموظف" };
    }
}

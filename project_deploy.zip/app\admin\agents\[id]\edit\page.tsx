import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import EditAgentForm from "@/components/admin/EditAgentForm";

interface EditAgentPageProps {
    params: {
        id: string;
    };
}

export default async function EditAgentPage({ params }: EditAgentPageProps) {
    const id = parseInt(params.id);
    if (isNaN(id)) notFound();

    const agent = await prisma.agent.findUnique({
        where: { id },
    });

    if (!agent) notFound();

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4 mb-6">
                <Link
                    href={`/admin/agents/${agent.id}`}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                    <ArrowRight className="w-5 h-5 text-gray-600" />
                </Link>
                <h1 className="text-2xl font-bold text-gray-900">تعديل بيانات الوكيل: {agent.fullName}</h1>
            </div>

            <EditAgentForm agent={agent} />
        </div>
    );
}

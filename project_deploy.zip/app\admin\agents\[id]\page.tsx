import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowRight, Edit } from "lucide-react";

interface AgentPageProps {
    params: {
        id: string;
    };
}

export default async function AgentPage({ params }: AgentPageProps) {
    const id = parseInt(params.id);
    if (isNaN(id)) notFound();

    const agent = await prisma.agent.findUnique({
        where: { id },
        include: {
            _count: {
                select: { clients: true }
            }
        }
    });

    if (!agent) notFound();

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <Link
                        href="/admin/agents"
                        className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                    >
                        <ArrowRight className="w-5 h-5 text-gray-600" />
                    </Link>
                    <h1 className="text-2xl font-bold text-gray-900">تفاصيل الوكيل</h1>
                </div>
                <Link
                    href={`/admin/agents/${agent.id}/edit`}
                    className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
                >
                    <Edit className="w-4 h-4" />
                    تعديل البيانات
                </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <h2 className="text-lg font-semibold mb-4 border-b pb-2">المعلومات الشخصية</h2>
                    <div className="space-y-4">
                        <div>
                            <label className="text-sm text-gray-500">الاسم الكامل</label>
                            <p className="font-medium">{agent.fullName}</p>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">البريد الإلكتروني</label>
                            <p className="font-medium" dir="ltr">{agent.email}</p>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">رقم الهاتف</label>
                            <p className="font-medium" dir="ltr">{agent.phone || "-"}</p>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">المدينة</label>
                            <p className="font-medium">{agent.city || "-"}</p>
                        </div>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <h2 className="text-lg font-semibold mb-4 border-b pb-2">معلومات العمل</h2>
                    <div className="space-y-4">
                        <div>
                            <label className="text-sm text-gray-500">عدد الطلاب</label>
                            <p className="font-medium">{agent._count.clients}</p>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">الحالة</label>
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium mt-1
                                ${agent.status === 'نشط' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                                {agent.status}
                            </span>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">طريقة الدفع</label>
                            <p className="font-medium">{agent.paymentMethod || "-"}</p>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">تفاصيل الدفع</label>
                            <p className="font-medium text-gray-700 whitespace-pre-wrap">{agent.paymentDetails || "-"}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

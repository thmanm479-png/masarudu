import { prisma } from "@/lib/prisma";
import { Search, Briefcase, Eye, Edit, Trash2 } from "lucide-react";
import AgentRow from "@/components/admin/AgentRow";

export const dynamic = 'force-dynamic';

async function getAgents() {
    try {
        const agents = await prisma.agent.findMany({
            orderBy: { createdAt: "desc" },
            include: {
                _count: {
                    select: { clients: true },
                },
            },
        });
        return agents;
    } catch (error) {
        console.error("Failed to fetch agents:", error);
        return [];
    }
}

export default async function AgentsPage() {
    const agents = await getAgents();

    return (
        <div>
            <div className="flex justify-between items-center mb-8">
                <h1 className="text-2xl font-bold text-gray-900">إدارة الوكلاء</h1>
                <div className="relative">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                    <input
                        type="text"
                        placeholder="بحث عن وكيل..."
                        className="pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary w-64"
                    />
                </div>
            </div>

            <div className="bg-white shadow-sm rounded-xl overflow-hidden border border-gray-200">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                اسم الوكيل
                            </th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                التواصل
                            </th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                المدينة
                            </th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                عدد الطلاب
                            </th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                الحالة
                            </th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                الإجراءات
                            </th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {agents.length === 0 ? (
                            <tr>
                                <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                                    <Briefcase className="mx-auto h-12 w-12 text-gray-300 mb-3" />
                                    <p>لا يوجد وكلاء حالياً</p>
                                </td>
                            </tr>
                        ) : (
                            agents.map((agent) => (
                                <AgentRow key={agent.id} agent={agent} />
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import EditClientForm from "@/components/admin/EditClientForm";

interface EditClientPageProps {
    params: {
        id: string;
    };
}

export default async function EditClientPage({ params }: EditClientPageProps) {
    const id = parseInt(params.id);
    if (isNaN(id)) notFound();

    const client = await prisma.client.findUnique({
        where: { id },
    });

    if (!client) notFound();

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4 mb-6">
                <Link
                    href={`/admin/clients/${client.id}`}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                    <ArrowRight className="w-5 h-5 text-gray-600" />
                </Link>
                <h1 className="text-2xl font-bold text-gray-900">تعديل بيانات العميل: {client.fullName}</h1>
            </div>

            <EditClientForm client={client} />
        </div>
    );
}

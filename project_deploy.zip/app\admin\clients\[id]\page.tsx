import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowRight, Edit } from "lucide-react";

interface ClientPageProps {
    params: {
        id: string;
    };
}

export default async function ClientPage({ params }: ClientPageProps) {
    const id = parseInt(params.id);
    if (isNaN(id)) notFound();

    const client = await prisma.client.findUnique({
        where: { id },
    });

    if (!client) notFound();

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <Link
                        href="/admin/clients"
                        className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                    >
                        <ArrowRight className="w-5 h-5 text-gray-600" />
                    </Link>
                    <h1 className="text-2xl font-bold text-gray-900">تفاصيل العميل</h1>
                </div>
                <Link
                    href={`/admin/clients/${client.id}/edit`}
                    className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
                >
                    <Edit className="w-4 h-4" />
                    تعديل البيانات
                </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <h2 className="text-lg font-semibold mb-4 border-b pb-2">المعلومات الشخصية</h2>
                    <div className="space-y-4">
                        <div>
                            <label className="text-sm text-gray-500">الاسم الكامل</label>
                            <p className="font-medium">{client.fullName}</p>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">البريد الإلكتروني</label>
                            <p className="font-medium" dir="ltr">{client.email || "-"}</p>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">رقم الهاتف</label>
                            <p className="font-medium" dir="ltr">{client.phone}</p>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">الجنسية</label>
                            <p className="font-medium">{client.nationality || "-"}</p>
                        </div>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <h2 className="text-lg font-semibold mb-4 border-b pb-2">معلومات الدراسة</h2>
                    <div className="space-y-4">
                        <div>
                            <label className="text-sm text-gray-500">نوع الشهادة</label>
                            <p className="font-medium">{client.certificateType || "-"}</p>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">المعدل</label>
                            <p className="font-medium">{client.gpa || "-"}</p>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">التخصص المطلوب</label>
                            <p className="font-medium">{client.desiredMajor || "-"}</p>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">نوع الجامعة</label>
                            <p className="font-medium">{client.universityType || "-"}</p>
                        </div>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 md:col-span-2">
                    <h2 className="text-lg font-semibold mb-4 border-b pb-2">معلومات إضافية</h2>
                    <div className="space-y-4">
                        <div>
                            <label className="text-sm text-gray-500">الحالة</label>
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium mt-1
                                ${client.status === 'جديد' ? 'bg-blue-100 text-blue-800' :
                                    client.status === 'تم القبول' ? 'bg-green-100 text-green-800' :
                                        'bg-gray-100 text-gray-800'}`}>
                                {client.status}
                            </span>
                        </div>
                        <div>
                            <label className="text-sm text-gray-500">ملاحظات</label>
                            <p className="font-medium text-gray-700 whitespace-pre-wrap">{client.notes || "لا توجد ملاحظات"}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

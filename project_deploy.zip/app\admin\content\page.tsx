"use client";

import { useState, useEffect } from "react";
import { Edit2, Save, Loader2, AlertCircle, CheckCircle2, Layout, Type } from "lucide-react";

interface ContentItem {
    id: number;
    key: string;
    value: string;
    group: string | null;
}

export default function ContentPage() {
    const [content, setContent] = useState<ContentItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState<number | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<string | null>(null);

    useEffect(() => {
        fetchContent();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const fetchContent = async () => {
        try {
            const res = await fetch("/api/admin/content");
            const data = await res.json();
            if (res.ok) {
                // If no content exists, seed with some defaults
                if (data.length === 0) {
                    await seedDefaults();
                } else {
                    setContent(data);
                }
            }
        } catch (err) {
            console.error("Failed to fetch content:", err);
        } finally {
            setLoading(false);
        }
    };

    const seedDefaults = async () => {
        const defaults = [
            { key: "hero_title", value: "مستقبلك يبدأ هنا مع مسار", group: "Hero" },
            { key: "hero_subtitle", value: "نساعدك في اختيار التخصص الجامعي المناسب وتأمين قبولك في أفضل الجامعات التركية", group: "Hero" },
            { key: "services_title", value: "خدماتنا المتميزة", group: "Services" },
            { key: "footer_about", value: "مسار للخدمات الاستشارية والتعليمية، رفيقك نحو التميز الأكاديمي", group: "Footer" },
        ];

        for (const item of defaults) {
            await fetch("/api/admin/content", {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(item),
            });
        }
        const res = await fetch("/api/admin/content");
        const data = await res.json();
        setContent(data);
    };

    const handleUpdate = async (item: ContentItem) => {
        setSaving(item.id);
        setError(null);
        setSuccess(null);

        try {
            const res = await fetch("/api/admin/content", {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(item),
            });

            if (res.ok) {
                setSuccess(`تم تحديث "${item.key}" بنجاح`);
            } else {
                setError("فشل تحديث المحتوى");
            }
        } catch (err) {
            setError("حدث خطأ ما");
        } finally {
            setSaving(null);
        }
    };

    const handleChange = (id: number, newValue: string) => {
        setContent(content.map(item => item.id === id ? { ...item, value: newValue } : item));
    };

    if (loading) {
        return (
            <div className="flex h-96 items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
        );
    }

    // Group items by their 'group' field
    const groupedContent = content.reduce((acc, item) => {
        const group = item.group || "عام";
        if (!acc[group]) acc[group] = [];
        acc[group].push(item);
        return acc;
    }, {} as Record<string, ContentItem[]>);

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">إدارة محتوى الموقع</h1>
                    <p className="text-gray-500 text-sm mt-1">تعديل النصوص والفقرات التي تظهر في صفحات الموقع</p>
                </div>
            </div>

            {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                    <AlertCircle className="h-5 w-5" />
                    <p>{error}</p>
                </div>
            )}

            {success && (
                <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                    <CheckCircle2 className="h-5 w-5" />
                    <p>{success}</p>
                </div>
            )}

            <div className="space-y-8">
                {Object.entries(groupedContent).map(([group, items]) => (
                    <div key={group} className="space-y-4">
                        <div className="flex items-center gap-2 border-b border-gray-100 pb-2">
                            <Layout className="h-5 w-5 text-gray-400" />
                            <h2 className="text-lg font-bold text-gray-900 capitalize">{group}</h2>
                        </div>
                        <div className="grid grid-cols-1 gap-4">
                            {items.map((item) => (
                                <div key={item.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:border-primary/20 transition-all">
                                    <div className="flex items-center gap-2 mb-3">
                                        <Type className="h-4 w-4 text-gray-400" />
                                        <span className="text-sm font-mono text-gray-500">{item.key}</span>
                                    </div>
                                    <div className="flex gap-4">
                                        <textarea
                                            value={item.value}
                                            onChange={(e) => handleChange(item.id, e.target.value)}
                                            rows={2}
                                            className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all resize-none"
                                        />
                                        <button
                                            onClick={() => handleUpdate(item)}
                                            disabled={saving === item.id}
                                            className="self-end bg-primary/10 text-primary p-3 rounded-xl hover:bg-primary/20 transition-all disabled:opacity-50"
                                            title="حفظ التغييرات"
                                        >
                                            {saving === item.id ? (
                                                <Loader2 className="h-5 w-5 animate-spin" />
                                            ) : (
                                                <Save className="h-5 w-5" />
                                            )}
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import EditEmployeeForm from "@/components/admin/EditEmployeeForm";

interface EditEmployeePageProps {
    params: {
        id: string;
    };
}

export default async function EditEmployeePage({ params }: EditEmployeePageProps) {
    const id = parseInt(params.id);
    if (isNaN(id)) notFound();

    const employee = await prisma.employee.findUnique({
        where: { id },
    });

    if (!employee) notFound();

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4 mb-6">
                <Link
                    href={`/admin/employees/${employee.id}`}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                    <ArrowRight className="w-5 h-5 text-gray-600" />
                </Link>
                <h1 className="text-2xl font-bold text-gray-900">تعديل بيانات الموظف: {employee.fullName}</h1>
            </div>

            <EditEmployeeForm employee={employee} />
        </div>
    );
}

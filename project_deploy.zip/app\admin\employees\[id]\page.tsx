import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowRight, Edit } from "lucide-react";

interface EmployeePageProps {
    params: {
        id: string;
    };
}

export default async function EmployeePage({ params }: EmployeePageProps) {
    const id = parseInt(params.id);
    if (isNaN(id)) notFound();

    const employee = await prisma.employee.findUnique({
        where: { id },
    });

    if (!employee) notFound();

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <Link
                        href="/admin/employees"
                        className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                    >
                        <ArrowRight className="w-5 h-5 text-gray-600" />
                    </Link>
                    <h1 className="text-2xl font-bold text-gray-900">تفاصيل الموظف</h1>
                </div>
                <Link
                    href={`/admin/employees/${employee.id}/edit`}
                    className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
                >
                    <Edit className="w-4 h-4" />
                    تعديل البيانات
                </Link>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <h2 className="text-lg font-semibold mb-4 border-b pb-2">المعلومات الشخصية</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="text-sm text-gray-500">الاسم الكامل</label>
                        <p className="font-medium">{employee.fullName}</p>
                    </div>
                    <div>
                        <label className="text-sm text-gray-500">البريد الإلكتروني</label>
                        <p className="font-medium" dir="ltr">{employee.email}</p>
                    </div>
                    <div>
                        <label className="text-sm text-gray-500">رقم الهاتف</label>
                        <p className="font-medium" dir="ltr">{employee.phone || "-"}</p>
                    </div>
                    <div>
                        <label className="text-sm text-gray-500">الدور الوظيفي</label>
                        <p className="font-medium">{employee.role}</p>
                    </div>
                    <div>
                        <label className="text-sm text-gray-500">الحالة</label>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium mt-1
                            ${employee.status === 'نشط' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                            {employee.status}
                        </span>
                    </div>
                    <div>
                        <label className="text-sm text-gray-500">تاريخ الانضمام</label>
                        <p className="font-medium">{new Date(employee.createdAt).toLocaleDateString("ar-EG")}</p>
                    </div>
                </div>
            </div>
        </div>
    );
}

import { prisma } from "@/lib/prisma";
import { Search, UserCog, Eye, Edit, Trash2 } from "lucide-react";
import EmployeeRow from "@/components/admin/EmployeeRow";
import { Employee } from "@prisma/client";

export const dynamic = 'force-dynamic';

async function getEmployees() {
    try {
        const employees = await prisma.employee.findMany({
            orderBy: { createdAt: "desc" },
        });
        return employees;
    } catch (error) {
        console.error("Failed to fetch employees:", error);
        return [];
    }
}

export default async function EmployeesPage() {
    const employees = await getEmployees();

    return (
        <div>
            <div className="flex justify-between items-center mb-8">
                <h1 className="text-2xl font-bold text-gray-900">إدارة الموظفين</h1>
                <div className="relative">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                    <input
                        type="text"
                        placeholder="بحث عن موظف..."
                        className="pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary w-64"
                    />
                </div>
            </div>

            <div className="bg-white shadow-sm rounded-xl overflow-hidden border border-gray-200">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                اسم الموظف
                            </th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                التواصل
                            </th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                الدور الوظيفي
                            </th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                الحالة
                            </th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                تاريخ الانضمام
                            </th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                الإجراءات
                            </th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {employees.length === 0 ? (
                            <tr>
                                <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                                    <UserCog className="mx-auto h-12 w-12 text-gray-300 mb-3" />
                                    <p>لا يوجد موظفين حالياً</p>
                                </td>
                            </tr>
                        ) : (
                            employees.map((employee) => (
                                <EmployeeRow key={employee.id} employee={employee} />
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

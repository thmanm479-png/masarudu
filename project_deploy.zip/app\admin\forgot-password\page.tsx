"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { KeyRound, AlertCircle, CheckCircle, ArrowRight, GraduationCap } from "lucide-react";
import Link from "next/link";

const schema = z.object({
    email: z.string().email({ message: "البريد الإلكتروني غير صالح" }),
});

type FormData = z.infer<typeof schema>;

export default function AdminForgotPassword() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState("");

    const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
        resolver: zodResolver(schema),
    });

    const onSubmit = async (data: FormData) => {
        setIsSubmitting(true);
        setError("");

        try {
            const response = await fetch('/api/admin/forgot-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || "حدث خطأ أثناء معالجة الطلب");
            }

            setIsSuccess(true);
        } catch (err: any) {
            setError(err.message || "حدث خطأ أثناء إرسال طلب إعادة التعيين");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="min-h-screen relative flex items-center justify-center overflow-hidden bg-gray-900 font-sans" dir="rtl">
            {/* Background elements */}
            <div className="absolute top-0 left-0 w-full h-full">
                <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-primary/20 rounded-full blur-[120px] animate-pulse" />
                <div className="absolute bottom-[-10%] left-[-10%] w-[50%] h-[50%] bg-secondary/10 rounded-full blur-[120px] animate-pulse" />
            </div>

            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="relative z-10 w-full max-w-md px-4"
            >
                <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-8 shadow-2xl">
                    <div className="text-center mb-8">
                        <div className="inline-flex items-center justify-center p-4 bg-gradient-to-br from-primary to-primary-dark rounded-2xl shadow-lg shadow-primary/20 mb-4 transition-transform hover:scale-105">
                            <GraduationCap className="h-8 w-8 text-white" />
                        </div>
                        <h1 className="text-2xl font-bold text-white mb-2">نسيت كلمة المرور؟</h1>
                        <p className="text-gray-400 text-sm">أدخل بريدك الإلكتروني وسنرسل لك رابطاً لإعادة التعيين.</p>
                    </div>

                    {isSuccess ? (
                        <div className="text-center space-y-6">
                            <div className="mx-auto w-16 h-16 bg-green-500/10 border border-green-500/20 rounded-full flex items-center justify-center">
                                <CheckCircle className="w-8 h-8 text-green-500" />
                            </div>
                            <div className="space-y-2">
                                <h3 className="text-xl font-bold text-white">تم الإرسال بنجاح</h3>
                                <p className="text-gray-400 text-sm">
                                    إذا كان هذا البريد مسجلاً لدينا، فستتلقى رسالة تحتوي على تعليمات إعادة تعيين كلمة المرور قريباً.
                                </p>
                            </div>
                            <Link
                                href="/admin/login"
                                className="inline-flex items-center gap-2 text-primary hover:underline font-medium"
                            >
                                <ArrowRight className="h-4 w-4" /> العودة لتسجيل الدخول
                            </Link>
                        </div>
                    ) : (
                        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                            <div className="space-y-2">
                                <label className="text-sm font-medium text-gray-300 mr-1 block">البريد الإلكتروني</label>
                                <div className="relative group">
                                    <input
                                        type="email"
                                        {...register("email")}
                                        placeholder="admin@example.com"
                                        className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all placeholder:text-gray-600"
                                    />
                                </div>
                                {errors.email && <p className="text-red-500 text-xs mt-1 mr-1">{errors.email.message}</p>}
                            </div>

                            {error && (
                                <div className="bg-red-500/10 border border-red-500/20 text-red-500 text-sm py-3 px-4 rounded-xl flex items-center gap-2">
                                    <AlertCircle className="h-5 w-5 flex-shrink-0" />
                                    <span>{error}</span>
                                </div>
                            )}

                            <button
                                type="submit"
                                disabled={isSubmitting}
                                className="w-full bg-gradient-to-r from-primary to-primary-dark text-white font-bold py-3.5 px-6 rounded-xl shadow-lg shadow-primary/20 hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                {isSubmitting ? (
                                    <div className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                ) : (
                                    <>
                                        <KeyRound className="h-5 w-5" />
                                        <span>إرسال رابط إعادة التعيين</span>
                                    </>
                                )}
                            </button>

                            <div className="text-center">
                                <Link
                                    href="/admin/login"
                                    className="text-sm text-gray-500 hover:text-primary transition-colors inline-flex items-center gap-1"
                                >
                                    <ArrowRight className="h-4 w-4" /> تذكرت كلمة المرور؟ عد للدخول
                                </Link>
                            </div>
                        </form>
                    )}
                </div>
            </motion.div>
        </div>
    );
}

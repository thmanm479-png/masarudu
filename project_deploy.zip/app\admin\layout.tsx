"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Users, FileText, Settings, LogOut, UserCog, Briefcase, GraduationCap, Menu, Shield, Mail, X, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";


import Logo from "@/components/Logo";

const navigation = [
    { name: 'لوحة التحكم', href: '/admin', icon: LayoutDashboard },
    { name: 'العملاء', href: '/admin/clients', icon: Users },
    { name: 'الموظفين', href: '/admin/employees', icon: UserCog },
    { name: 'الوكلاء', href: '/admin/agents', icon: Briefcase },
    { name: 'الجامعات', href: '/admin/universities', icon: GraduationCap },
    { name: 'رسائل التواصل', href: '/admin/submissions', icon: Mail },
    { name: 'محتوى الموقع', href: '/admin/content', icon: FileText },
    { name: 'إدارة المشرفين', href: '/admin/admins', icon: Shield },
    { name: 'الإعدادات', href: '/admin/settings', icon: Settings },
];

export default function AdminLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const pathname = usePathname();
    const [sidebarOpen, setSidebarOpen] = useState(false);

    // Initial check and resize handler
    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth >= 1024) {
                setSidebarOpen(true);
            } else {
                setSidebarOpen(false);
            }
        };

        // Set initial state
        handleResize();

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    // Exclude sidebar/header from login page
    if (pathname && (pathname.startsWith("/admin/login") || pathname.startsWith("/admin/register"))) {
        return <>{children}</>;
    }

    return (
        <div className="min-h-screen bg-gray-50 flex" dir="rtl">
            {/* Sidebar Overlay for Mobile */}
            {sidebarOpen && (
                <div
                    className="fixed inset-0 bg-black/50 z-40 lg:hidden backdrop-blur-sm"
                    onClick={() => setSidebarOpen(false)}
                />
            )}

            {/* Sidebar */}
            <aside
                className={cn(
                    "fixed inset-y-0 right-0 z-50 flex flex-col transition-all duration-300 ease-in-out bg-gray-900 shadow-xl",
                    sidebarOpen ? "w-64 translate-x-0" : "w-64 translate-x-full lg:translate-x-0 lg:w-20"
                )}
            >
                <div className="h-20 flex items-center justify-between border-b border-gray-800 px-6 relative">
                    <Link href="/" className="flex items-center gap-2">
                        <Logo className="h-8" showText={sidebarOpen} />
                    </Link>
                    <button
                        onClick={() => setSidebarOpen(!sidebarOpen)}
                        className="lg:flex hidden absolute left-[-12px] top-8 bg-secondary text-white p-1 rounded-full shadow-lg hover:bg-secondary-light transition-colors z-[60]"
                    >
                        {sidebarOpen ? <ChevronRight className="h-4 w-4 rotate-180" /> : <ChevronRight className="h-4 w-4" />}
                    </button>
                    {/* Mobile close button */}
                    <button
                        onClick={() => setSidebarOpen(false)}
                        className="lg:hidden p-2 text-gray-400 hover:text-white bg-gray-800 rounded-xl"
                    >
                        <X className="h-6 w-6" />
                    </button>
                </div>

                <nav className="flex-1 p-4 space-y-2 overflow-y-auto custom-scrollbar">
                    {navigation.map((item) => {
                        const isActive = pathname === item.href;
                        // Determine if collapsed state: sidebar is closed AND we are on desktop (>1024px usually)
                        // But since we can't check window directly for rendering without hydration mismatch,
                        // we generally rely on sidebarOpen.
                        // However, on mobile, if sidebarOpen is false, it is hidden, not collapsed.
                        // The logic below relies on CSS classes mostly.
                        // Let's use CSS to hide text if not open, or simpler logic.
                        // The original code used window check.
                        // We will simplify: always render text, but hide it with CSS if collapsed?
                        // Or just rely on sidebarOpen.

                        return (
                            <Link
                                key={item.name}
                                href={item.href}
                                onClick={() => {
                                    // Close sidebar on mobile when link clicked
                                    // Use a safe check or just always set false if it was open (handled by state)
                                    if (typeof window !== 'undefined' && window.innerWidth < 1024) setSidebarOpen(false);
                                }}
                                className={cn(
                                    "flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-all duration-200 group relative overflow-hidden",
                                    isActive
                                        ? "bg-gradient-to-r from-secondary to-secondary-dark text-white shadow-lg"
                                        : "text-gray-400 hover:bg-gray-800 hover:text-white"
                                )}
                                title={!sidebarOpen ? item.name : ""}
                            >
                                <item.icon className={cn("h-5 w-5 flex-shrink-0 transition-transform duration-300", isActive && "scale-110")} />
                                <span className={cn("transition-all duration-200", !sidebarOpen && "lg:opacity-0 lg:w-0 lg:hidden")}>
                                    {item.name}
                                </span>
                                {isActive && <div className="absolute inset-0 bg-white/10 animate-pulse" />}
                            </Link>
                        );
                    })}
                </nav>

                <div className="p-4 border-t border-gray-800">
                    <Link
                        href="/admin/login"
                        className={cn(
                            "flex items-center gap-3 px-4 py-3 text-sm font-medium text-red-400 rounded-xl hover:bg-red-950/30 hover:text-red-300 transition-colors",
                            !sidebarOpen && "lg:justify-center lg:px-2"
                        )}
                        title={!sidebarOpen ? "تسجيل الخروج" : ""}
                    >
                        <LogOut className="h-5 w-5 flex-shrink-0" />
                        <span className={cn("transition-all duration-200", !sidebarOpen && "lg:hidden")}>
                            تسجيل الخروج
                        </span>
                    </Link>
                </div>
            </aside>

            {/* Main Content */}
            <main
                className={cn(
                    "flex-1 transition-all duration-300 ease-in-out p-4 md:p-8 min-w-0 w-full",
                    sidebarOpen ? "lg:mr-64" : "lg:mr-20"
                )}
            >
                {/* Mobile Header */}
                <div className="lg:hidden flex items-center justify-between mb-6 bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
                    <button
                        onClick={() => setSidebarOpen(true)}
                        className="p-2 text-gray-600 hover:bg-gray-100 rounded-xl"
                    >
                        <Menu className="h-6 w-6" />
                    </button>
                    <Logo className="h-8" showText={false} />
                    <div className="w-10"></div> {/* Spacer */}
                </div>

                {children}
            </main>
        </div>
    );
}

import { prisma } from "@/lib/prisma";
import {
    CheckCircle,
    Clock,
    XCircle,
    AlertCircle,
    Users,
    UserCheck,
    GraduationCap,
    TrendingUp,
    Briefcase,
    Globe
} from "lucide-react";

// Force dynamic rendering to ensure up-to-date data
export const dynamic = 'force-dynamic';

async function getStats() {
    try {
        const [clients, agents, employees, universities] = await Promise.all([
            prisma.client.findMany({ orderBy: { createdAt: "desc" } }),
            prisma.agent.count(),
            prisma.employee.count(),
            prisma.university.count(),
        ]);

        return {
            clients,
            agentsCount: agents,
            employeesCount: employees,
            universitiesCount: universities,
            error: null
        };
    } catch (error) {
        console.error("Failed to fetch stats:", error);
        return {
            clients: [],
            agentsCount: 0,
            employeesCount: 0,
            universitiesCount: 0,
            error: error instanceof Error ? error.message : "Database connection failed"
        };
    }
}

export default async function AdminDashboard() {
    const { clients, agentsCount, employeesCount, universitiesCount, error } = await getStats();

    // Show error message if database connection failed
    if (error) {
        return (
            <div className="flex items-center justify-center min-h-[60vh]">
                <div className="text-center space-y-4 max-w-md">
                    <AlertCircle className="mx-auto h-16 w-16 text-red-500" />
                    <h2 className="text-2xl font-bold text-gray-900">خطأ في الاتصال بقاعدة البيانات</h2>
                    <p className="text-gray-600">يرجى التحقق من إعدادات قاعدة البيانات والمحاولة مرة أخرى</p>
                    <pre className="text-xs text-left bg-red-50 p-4 rounded-lg overflow-auto max-h-40">
                        {error}
                    </pre>
                </div>
            </div>
        );
    }

    const mainStats = [
        { name: 'إجمالي الطلاب', value: clients.length, icon: Users, color: 'text-blue-600', bg: 'bg-blue-100', trend: '+12%' },
        { name: 'الوكلاء النشطين', value: agentsCount, icon: UserCheck, color: 'text-purple-600', bg: 'bg-purple-100', trend: '+5%' },
        { name: 'الجامعات المتاحة', value: universitiesCount, icon: GraduationCap, color: 'text-green-600', bg: 'bg-green-100', trend: 'ثابت' },
        { name: 'الموظفين', value: employeesCount, icon: Briefcase, color: 'text-orange-600', bg: 'bg-orange-100', trend: 'ثابت' },
    ];

    const statusStats = [
        { name: 'طلبات جديدة', value: clients.filter((c: any) => c.status === 'جديد').length, color: 'bg-yellow-500' },
        { name: 'قيد المراجعة', value: clients.filter((c: any) => c.status === 'قيد المراجعة').length, color: 'bg-blue-500' },
        { name: 'تم القبول', value: clients.filter((c: any) => c.status === 'تم القبول').length, color: 'bg-green-500' },
        { name: 'مرفوض', value: clients.filter((c: any) => c.status === 'مرفوض').length, color: 'bg-red-500' },
    ];

    return (
        <div className="space-y-8 pb-10">
            <div className="flex flex-col gap-2">
                <h1 className="text-3xl font-bold text-gray-900">لوحة التحكم</h1>
                <p className="text-gray-500">نظرة عامة على أداء المنصة وآخر المستجدات</p>
            </div>

            {/* Main Stats Grid */}
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
                {mainStats.map((item) => (
                    <div key={item.name} className="relative overflow-hidden rounded-3xl bg-white p-6 shadow-sm border border-gray-100 transition-all hover:shadow-md group">
                        <div className="flex items-start justify-between">
                            <div className={`rounded-2xl p-4 ${item.bg} group-hover:scale-110 transition-transform duration-300`}>
                                <item.icon className={`h-6 w-6 ${item.color}`} aria-hidden="true" />
                            </div>
                            <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-lg">
                                {item.trend}
                            </span>
                        </div>
                        <div className="mt-4">
                            <h3 className="text-sm font-medium text-gray-500">{item.name}</h3>
                            <p className="text-2xl font-bold text-gray-900 mt-1">{item.value}</p>
                        </div>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Status breakdown */}
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 lg:col-span-1">
                    <h2 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
                        <TrendingUp className="h-5 w-5 text-primary" />
                        حالات الطلبات
                    </h2>
                    <div className="space-y-4">
                        {statusStats.map((stat) => (
                            <div key={stat.name} className="space-y-2">
                                <div className="flex justify-between text-sm">
                                    <span className="text-gray-600">{stat.name}</span>
                                    <span className="font-bold">{stat.value}</span>
                                </div>
                                <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                                    <div
                                        className={`h-full ${stat.color} transition-all duration-500`}
                                        style={{ width: `${clients.length > 0 ? (stat.value / clients.length) * 100 : 0}%` }}
                                    />
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Table Section */}
                <div className="bg-white shadow-sm rounded-3xl border border-gray-100 overflow-hidden lg:col-span-2">
                    <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/30">
                        <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                            <Clock className="h-5 w-5 text-primary" />
                            أحدث الطلبات
                        </h2>
                        <button className="text-primary text-sm font-medium hover:underline">عرض الكل</button>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-100">
                            <thead>
                                <tr>
                                    <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase">الطالب</th>
                                    <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase">التخصص</th>
                                    <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase">الحالة</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {clients.length === 0 ? (
                                    <tr>
                                        <td colSpan={3} className="px-6 py-12 text-center text-gray-500">
                                            <AlertCircle className="mx-auto h-12 w-12 text-gray-300 mb-2" />
                                            <p>لا يوجد طلبات حالياً</p>
                                        </td>
                                    </tr>
                                ) : (
                                    clients.slice(0, 5).map((client: any) => (
                                        <tr key={client.id} className="hover:bg-gray-50/80 transition-colors">
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <div className="flex items-center gap-3">
                                                    <div className="h-10 w-10 rounded-2xl bg-primary/5 flex items-center justify-center text-primary font-bold">
                                                        {client.fullName.charAt(0)}
                                                    </div>
                                                    <div className="flex flex-col">
                                                        <span className="text-sm font-bold text-gray-900">{client.fullName}</span>
                                                        <span className="text-xs text-gray-400 font-mono">{client.phone}</span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <div className="flex flex-col">
                                                    <span className="text-sm text-gray-900 font-medium">{client.desiredMajor}</span>
                                                    <span className="text-xs text-gray-400">{client.universityType}</span>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium
                                                    ${client.status === 'جديد' ? 'bg-yellow-50 text-yellow-700' :
                                                        client.status === 'تم القبول' ? 'bg-green-50 text-green-700' :
                                                            client.status === 'قيد المراجعة' ? 'bg-blue-50 text-blue-700' :
                                                                'bg-gray-50 text-gray-700'}`}>
                                                    <span className={`h-1.5 w-1.5 rounded-full ${client.status === 'جديد' ? 'bg-yellow-500' :
                                                        client.status === 'تم القبول' ? 'bg-green-500' :
                                                            client.status === 'قيد المراجعة' ? 'bg-blue-500' :
                                                                'bg-gray-500'
                                                        }`}></span>
                                                    {client.status}
                                                </span>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}

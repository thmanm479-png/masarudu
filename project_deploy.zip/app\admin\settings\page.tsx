"use client";

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { Lock, Save, AlertCircle, CheckCircle, Globe, Mail, Phone, Facebook, Twitter, Instagram, Linkedin, Image as ImageIcon } from "lucide-react";

type SiteSettings = {
    siteName: string;
    siteDescription: string;
    contactEmail: string;
    contactPhone: string;
    address: string;
    facebookUrl: string;
    twitterUrl: string;
    instagramUrl: string;
    linkedinUrl: string;
};

export default function AdminSettings() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [message, setMessage] = useState<{ type: "success" | "error", text: string } | null>(null);
    const [settingsLoading, setSettingsLoading] = useState(true);

    const { register: registerPassword, handleSubmit: handleSubmitPassword, reset: resetPassword, formState: { errors: passwordErrors } } = useForm();
    const { register: registerSettings, handleSubmit: handleSubmitSettings, reset: resetSettings, setValue } = useForm<SiteSettings>();

    useEffect(() => {
        const fetchSettings = async () => {
            try {
                const res = await fetch("/api/admin/site-settings");
                if (res.ok) {
                    const data = await res.json();
                    // Set form values
                    Object.keys(data).forEach((key) => {
                        setValue(key as any, data[key]);
                    });
                }
            } catch (error) {
                console.error("Failed to fetch settings", error);
            } finally {
                setSettingsLoading(false);
            }
        };

        fetchSettings();
    }, [setValue]);

    const onPasswordSubmit = async (data: any) => {
        setIsSubmitting(true);
        setMessage(null);

        try {
            const res = await fetch("/api/admin/settings", {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data),
            });

            const result = await res.json();

            if (!res.ok) {
                throw new Error(result.error || "Failed to update password");
            }

            setMessage({ type: "success", text: "تم تحديث كلمة المرور بنجاح" });
            resetPassword();
        } catch (error: any) {
            setMessage({ type: "error", text: error.message });
        } finally {
            setIsSubmitting(false);
        }
    };

    const onSettingsSubmit = async (data: SiteSettings) => {
        setIsSubmitting(true);
        setMessage(null);

        try {
            const res = await fetch("/api/admin/site-settings", {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data),
            });

            if (!res.ok) {
                throw new Error("Failed to update site settings");
            }

            setMessage({ type: "success", text: "تم تحديث إعدادات الموقع بنجاح" });
        } catch (error: any) {
            setMessage({ type: "error", text: error.message });
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-gray-900">الإعدادات العامة</h1>

            {message && (
                <div className={`p-4 rounded-xl flex items-center gap-3 shadow-sm ${message.type === "success" ? "bg-green-50 text-green-700 border border-green-200" : "bg-red-50 text-red-700 border border-red-200"
                    }`}>
                    {message.type === "success" ? <CheckCircle className="h-5 w-5" /> : <AlertCircle className="h-5 w-5" />}
                    {message.text}
                </div>
            )}

            {/* Site Settings Card */}
            <div className="bg-white shadow-sm rounded-2xl border border-gray-100 overflow-hidden">
                <div className="p-6 border-b border-gray-100 bg-gray-50/50">
                    <div className="flex items-center gap-3">
                        <div className="bg-primary/10 p-2 rounded-lg">
                            <Globe className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                            <h2 className="text-lg font-bold text-gray-900">معلومات الموقع</h2>
                            <p className="text-sm text-gray-500">تخصيص البيانات الأساسية للموقع ومعلومات التواصل</p>
                        </div>
                    </div>
                </div>

                <div className="p-6">
                    {settingsLoading ? (
                        <div className="flex justify-center py-8">
                            <div className="h-8 w-8 animate-spin rounded-full border-2 border-gray-200 border-t-primary" />
                        </div>
                    ) : (
                        <form onSubmit={handleSubmitSettings(onSettingsSubmit)} className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">اسم الموقع</label>
                                    <input
                                        {...registerSettings("siteName")}
                                        className="w-full border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all"
                                        placeholder="Masar Education"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">عنوان البريد الإلكتروني</label>
                                    <div className="relative">
                                        <Mail className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                                        <input
                                            {...registerSettings("contactEmail")}
                                            className="w-full pr-10 border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all"
                                            placeholder="contact@masar.com"
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">رقم الهاتف</label>
                                    <div className="relative">
                                        <Phone className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                                        <input
                                            {...registerSettings("contactPhone")}
                                            className="w-full pr-10 border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all"
                                            placeholder="+90 555 123 4567"
                                            dir="ltr"
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">العنوان</label>
                                    <input
                                        {...registerSettings("address")}
                                        className="w-full border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all"
                                        placeholder="Istanbul, Turkey"
                                    />
                                </div>
                                <div className="md:col-span-2">
                                    <label className="block text-sm font-medium text-gray-700 mb-2">وصف الموقع (SEO)</label>
                                    <textarea
                                        {...registerSettings("siteDescription")}
                                        rows={3}
                                        className="w-full border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all resize-none"
                                        placeholder="وصف مختصر للموقع يظهر في محركات البحث..."
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">رابط الشعار (Logo URL)</label>
                                    <div className="relative">
                                        <ImageIcon className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                                        <input
                                            {...registerSettings("logoUrl" as any)}
                                            className="w-full pr-10 border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all"
                                            placeholder="/logo.svg"
                                            dir="ltr"
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">رابط الأيقونة (Favicon URL)</label>
                                    <div className="relative">
                                        <Globe className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                                        <input
                                            {...registerSettings("faviconUrl" as any)}
                                            className="w-full pr-10 border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all"
                                            placeholder="/favicon.ico"
                                            dir="ltr"
                                        />
                                    </div>
                                </div>
                                <div className="flex items-center gap-3 bg-yellow-50 p-4 rounded-xl border border-yellow-100">
                                    <input
                                        type="checkbox"
                                        id="maintenanceMode"
                                        {...registerSettings("maintenanceMode" as any)}
                                        className="h-5 w-5 text-primary rounded border-gray-300 focus:ring-primary"
                                    />
                                    <label htmlFor="maintenanceMode" className="text-sm font-bold text-yellow-800">
                                        تفعيل وضع الصيانة (Maintenance Mode)
                                    </label>
                                </div>
                            </div>

                            <div className="pt-4 border-t border-gray-100">
                                <h3 className="text-sm font-bold text-gray-900 mb-4">روابط التواصل الاجتماعي</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="relative">
                                        <Facebook className="absolute right-3 top-2.5 h-5 w-5 text-blue-600" />
                                        <input
                                            {...registerSettings("facebookUrl")}
                                            className="w-full pr-10 border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all"
                                            placeholder="Facebook URL"
                                            dir="ltr"
                                        />
                                    </div>
                                    <div className="relative">
                                        <Twitter className="absolute right-3 top-2.5 h-5 w-5 text-sky-500" />
                                        <input
                                            {...registerSettings("twitterUrl")}
                                            className="w-full pr-10 border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all"
                                            placeholder="Twitter URL"
                                            dir="ltr"
                                        />
                                    </div>
                                    <div className="relative">
                                        <Instagram className="absolute right-3 top-2.5 h-5 w-5 text-pink-600" />
                                        <input
                                            {...registerSettings("instagramUrl")}
                                            className="w-full pr-10 border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all"
                                            placeholder="Instagram URL"
                                            dir="ltr"
                                        />
                                    </div>
                                    <div className="relative">
                                        <Linkedin className="absolute right-3 top-2.5 h-5 w-5 text-blue-700" />
                                        <input
                                            {...registerSettings("linkedinUrl")}
                                            className="w-full pr-10 border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all"
                                            placeholder="LinkedIn URL"
                                            dir="ltr"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="flex justify-end pt-4">
                                <button
                                    type="submit"
                                    disabled={isSubmitting}
                                    className="flex items-center gap-2 bg-primary text-white px-6 py-2.5 rounded-xl hover:bg-primary-dark transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-primary/20 disabled:opacity-70 disabled:cursor-not-allowed"
                                >
                                    <Save className="h-4 w-4" />
                                    {isSubmitting ? "جاري الحفظ..." : "حفظ الإعدادات"}
                                </button>
                            </div>
                        </form>
                    )}
                </div>
            </div>

            {/* Password Change Card */}
            <div className="bg-white shadow-sm rounded-2xl border border-gray-100 overflow-hidden max-w-2xl">
                <div className="p-6 border-b border-gray-100 bg-gray-50/50">
                    <div className="flex items-center gap-3">
                        <div className="bg-red-100 p-2 rounded-lg">
                            <Lock className="h-6 w-6 text-red-600" />
                        </div>
                        <div>
                            <h2 className="text-lg font-bold text-gray-900">الأمان وكلمة المرور</h2>
                            <p className="text-sm text-gray-500">تحديث كلمة المرور الخاصة بحساب المسؤول</p>
                        </div>
                    </div>
                </div>

                <div className="p-6">
                    <form onSubmit={handleSubmitPassword(onPasswordSubmit)} className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">كلمة المرور الحالية</label>
                            <input
                                type="password"
                                {...registerPassword("currentPassword", { required: "كلمة المرور الحالية مطلوبة" })}
                                className="w-full border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all"
                            />
                            {passwordErrors.currentPassword && (
                                <span className="text-xs text-red-500 mt-1">{passwordErrors.currentPassword.message as string}</span>
                            )}
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">كلمة المرور الجديدة</label>
                            <input
                                type="password"
                                {...registerPassword("newPassword", {
                                    required: "كلمة المرور الجديدة مطلوبة",
                                    minLength: { value: 6, message: "يجب أن تكون كلمة المرور 6 أحرف على الأقل" }
                                })}
                                className="w-full border-gray-300 rounded-xl shadow-sm focus:border-primary focus:ring-primary transition-all"
                            />
                            {passwordErrors.newPassword && (
                                <span className="text-xs text-red-500 mt-1">{passwordErrors.newPassword.message as string}</span>
                            )}
                        </div>

                        <div className="flex justify-end pt-4">
                            <button
                                type="submit"
                                disabled={isSubmitting}
                                className="flex items-center gap-2 bg-red-600 text-white px-6 py-2.5 rounded-xl hover:bg-red-700 transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-red-600/20 disabled:opacity-70 disabled:cursor-not-allowed"
                            >
                                <Save className="h-4 w-4" />
                                {isSubmitting ? "جاري التحديث..." : "تحديث كلمة المرور"}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}

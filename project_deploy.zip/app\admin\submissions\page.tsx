import { prisma } from "@/lib/prisma";
import { Mail, Phone, Calendar, User, MessageSquare, Search, Trash2, CheckCircle, Clock } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import SubmissionRow from "@/components/admin/SubmissionRow";

export const dynamic = 'force-dynamic';

async function getSubmissions() {
    try {
        const submissions = await prisma.contactSubmission.findMany({
            orderBy: { createdAt: "desc" },
        });
        return submissions;
    } catch (error) {
        console.error("Failed to fetch submissions:", error);
        return [];
    }
}

export default async function SubmissionsPage() {
    const submissions = await getSubmissions();

    return (
        <div className="space-y-8">
            <div className="flex flex-col gap-2">
                <h1 className="text-3xl font-bold text-gray-900">رسائل التواصل</h1>
                <p className="text-gray-500">استعرض الرسائل والاستفسارات الواردة من الموقع</p>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
                    <div className="p-3 bg-blue-50 rounded-xl">
                        <MessageSquare className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                        <p className="text-sm text-gray-500">إجمالي الرسائل</p>
                        <p className="text-2xl font-bold text-gray-900">{submissions.length}</p>
                    </div>
                </div>
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
                    <div className="p-3 bg-yellow-50 rounded-xl">
                        <Clock className="h-6 w-6 text-yellow-600" />
                    </div>
                    <div>
                        <p className="text-sm text-gray-500">رسائل جديدة</p>
                        <p className="text-2xl font-bold text-gray-900">
                            {submissions.filter(s => s.status === 'جديد').length}
                        </p>
                    </div>
                </div>
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
                    <div className="p-3 bg-green-50 rounded-xl">
                        <CheckCircle className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                        <p className="text-sm text-gray-500">تم الرد</p>
                        <p className="text-2xl font-bold text-gray-900">
                            {submissions.filter(s => s.status === 'تم الرد').length}
                        </p>
                    </div>
                </div>
            </div>

            <div className="bg-white shadow-sm rounded-3xl border border-gray-100 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-100">
                        <thead className="bg-gray-50/50">
                            <tr>
                                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">المرسل</th>
                                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">الرسالة</th>
                                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">التاريخ</th>
                                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">الحالة</th>
                                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider text-center">الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-100">
                            {submissions.length === 0 ? (
                                <tr>
                                    <td colSpan={5} className="px-6 py-20 text-center text-gray-500">
                                        <div className="flex flex-col items-center gap-2">
                                            <MessageSquare className="h-12 w-12 text-gray-200" />
                                            <p className="text-lg font-medium">لا توجد رسائل حالياً</p>
                                        </div>
                                    </td>
                                </tr>
                            ) : (
                                submissions.map((submission) => (
                                    <SubmissionRow
                                        key={submission.id}
                                        submission={{
                                            ...submission,
                                            createdAt: submission.createdAt.toISOString()
                                        }}
                                    />
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

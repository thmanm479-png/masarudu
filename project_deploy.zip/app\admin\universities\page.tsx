"use client";

import { useState, useEffect } from "react";
import { Plus, Edit, Trash2, Search, Building2, GraduationCap } from "lucide-react";
import { useForm } from "react-hook-form";

type University = {
    id: number;
    name: string;
    city: string;
    type: "Government" | "Private";
    description?: string;
    admissionReqs?: string; // Keeping as optional simple info
    language?: string; // Keeping as optional simple info
};

export default function UniversitiesAdmin() {
    const [universities, setUniversities] = useState<University[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingId, setEditingId] = useState<number | null>(null);
    const [searchTerm, setSearchTerm] = useState("");

    const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<University>();
    const universityType = watch("type");

    useEffect(() => {
        fetchUniversities();
    }, []);

    const fetchUniversities = async () => {
        try {
            const res = await fetch("/api/universities");
            const data = await res.json();
            setUniversities(data);
        } catch (error) {
            console.error("Failed to fetch universities", error);
        } finally {
            setIsLoading(false);
        }
    };

    const onSubmit = async (data: University) => {
        try {
            if (editingId) {
                await fetch(`/api/universities/${editingId}`, {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(data),
                });
            } else {
                await fetch("/api/universities", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(data),
                });
            }
            fetchUniversities();
            closeModal();
        } catch (error) {
            console.error("Failed to save university", error);
        }
    };

    const handleDelete = async (id: number) => {
        if (!confirm("هل أنت متأكد من حذف هذه الجامعة؟")) return;

        try {
            await fetch(`/api/universities/${id}`, {
                method: "DELETE",
            });
            fetchUniversities();
        } catch (error) {
            console.error("Failed to delete university", error);
        }
    };

    const openModal = (university?: University) => {
        if (university) {
            setEditingId(university.id);
            setValue("name", university.name);
            setValue("city", university.city);
            setValue("type", university.type);
            setValue("description", university.description);
            setValue("admissionReqs", university.admissionReqs);
            setValue("language", university.language);
        } else {
            setEditingId(null);
            reset();
            setValue("type", "Government"); // Default
        }
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setEditingId(null);
        reset();
    };

    const filteredUniversities = universities.filter(u =>
        u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.city.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div>
            <div className="flex justify-between items-center mb-8">
                <h1 className="text-2xl font-bold text-gray-900">إدارة الجامعات</h1>
                <button
                    onClick={() => openModal()}
                    className="flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark transition-colors"
                >
                    <Plus className="h-5 w-5" />
                    أضف جامعة جديدة
                </button>
            </div>

            <div className="bg-white shadow-sm rounded-lg border border-gray-200 p-4 mb-6">
                <div className="relative">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                    <input
                        type="text"
                        placeholder="ابحث باسم الجامعة أو المدينة..."
                        className="w-full pl-4 pr-10 py-2 border rounded-md focus:ring-primary focus:border-primary"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>

            {isLoading ? (
                <div className="text-center py-12">تحميل البيانات...</div>
            ) : (
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    {filteredUniversities.map((uni) => (
                        <div key={uni.id} className="bg-white border rounded-xl p-6 shadow-sm hover:shadow-md transition-all relative group">
                            <div className="absolute top-4 left-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button
                                    onClick={() => openModal(uni)}
                                    className="p-2 bg-gray-100 text-gray-600 rounded-full hover:bg-primary hover:text-white"
                                >
                                    <Edit className="h-4 w-4" />
                                </button>
                                <button
                                    onClick={() => handleDelete(uni.id)}
                                    className="p-2 bg-red-50 text-red-600 rounded-full hover:bg-red-600 hover:text-white"
                                >
                                    <Trash2 className="h-4 w-4" />
                                </button>
                            </div>

                            <div className="flex items-center gap-3 mb-4">
                                {uni.type === "Government" ? (
                                    <Building2 className="h-8 w-8 text-secondary" />
                                ) : (
                                    <GraduationCap className="h-8 w-8 text-secondary" />
                                )}
                                <h3 className="text-lg font-bold text-gray-900">{uni.name}</h3>
                            </div>

                            <div className="space-y-2 text-sm text-gray-600">
                                <p>📍 {uni.city}</p>
                                <p className="line-clamp-2">{uni.description}</p>
                                {uni.type === "Government" && uni.admissionReqs && <p>📄 {uni.admissionReqs}</p>}
                                {uni.type === "Private" && uni.language && <p>🌐 {uni.language}</p>}
                            </div>

                            <div className="mt-4 pt-4 border-t flex justify-between items-center">
                                <span className={`px-2 py-1 rounded text-xs font-medium ${uni.type === "Government" ? "bg-blue-100 text-blue-800" : "bg-purple-100 text-purple-800"
                                    }`}>
                                    {uni.type === "Government" ? "حكومية" : "خاصة"}
                                </span>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {/* Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
                    <div className="bg-white rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                        <div className="p-6 border-b flex justify-between items-center">
                            <h2 className="text-xl font-bold">
                                {editingId ? "تعديل بيانات الجامعة" : "إضافة جامعة جديدة"}
                            </h2>
                            <button onClick={closeModal} className="text-gray-500 hover:text-gray-700">
                                <Plus className="h-6 w-6 rotate-45" />
                            </button>
                        </div>

                        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">اسم الجامعة</label>
                                    <input
                                        {...register("name", { required: true })}
                                        className="w-full border rounded-md px-3 py-2"
                                        placeholder="مثال: جامعة اسطنبول"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">المدينة</label>
                                    <input
                                        {...register("city", { required: true })}
                                        className="w-full border rounded-md px-3 py-2"
                                        placeholder="مثال: اسطنبول"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">نوع الجامعة</label>
                                <select {...register("type")} className="w-full border rounded-md px-3 py-2">
                                    <option value="Government">جامعة حكومية</option>
                                    <option value="Private">جامعة خاصة</option>
                                </select>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">وصف موجز</label>
                                <textarea
                                    {...register("description")}
                                    className="w-full border rounded-md px-3 py-2 h-24"
                                    placeholder="اكتب وصفاً مختصراً عن الجامعة..."
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">
                                        {universityType === "Government" ? "شروط القبول" : "لغة الدراسة"}
                                    </label>
                                    <input
                                        {...register(universityType === "Government" ? "admissionReqs" : "language")}
                                        className="w-full border rounded-md px-3 py-2"
                                    />
                                </div>
                            </div>

                            <div className="pt-4 flex justify-end gap-3">
                                <button
                                    type="button"
                                    onClick={closeModal}
                                    className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md"
                                >
                                    إلغاء
                                </button>
                                <button
                                    type="submit"
                                    className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark"
                                >
                                    {editingId ? "حفظ التعديلات" : "إضافة الجامعة"}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}

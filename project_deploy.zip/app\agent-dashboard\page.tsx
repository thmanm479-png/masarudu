"use client";

import { useEffect, useState } from "react";
import {
    Users, DollarSign, TrendingUp, LogOut,
    CheckCircle, Clock, XCircle, Search,
    BarChart3, Wallet, GraduationCap, ChevronRight, Eye, Edit, Trash2
} from "lucide-react";
import Link from "next/link";
import FadeIn from "@/components/FadeIn";
import { motion, AnimatePresence } from "framer-motion";
import TableActions from "@/components/TableActions";
import { cn } from "@/lib/utils";

type Student = {
    id: number;
    fullName: string;
    desiredMajor: string;
    status: string;
    createdAt: string;
};

type DashboardData = {
    agentName: string;
    totalStudents: number;
    totalEarnings: number;
    currentTier: string;
    paymentMethod: string;
    paymentDetails: string;
    students: Student[];
};

export default function AgentDashboard() {
    const [data, setData] = useState<DashboardData | null>(null);
    const [loading, setLoading] = useState(true);
    const [showPaymentModal, setShowPaymentModal] = useState(false);
    const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
    const [copied, setCopied] = useState(false);
    const [updatingPayment, setUpdatingPayment] = useState(false);
    const [paymentForm, setPaymentForm] = useState({
        method: "",
        details: ""
    });

    useEffect(() => {
        const fetchDashboardData = async () => {
            const token = localStorage.getItem("agentToken");
            if (!token) {
                window.location.href = "/agent-login";
                return;
            }

            try {
                const response = await fetch('/api/agents/dashboard', {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                });

                if (!response.ok) {
                    if (response.status === 401) {
                        localStorage.removeItem("agentToken");
                        window.location.href = "/agent-login";
                        return;
                    }
                    throw new Error("فشل جلب البيانات");
                }

                const result = await response.json();
                setData(result);
                setPaymentForm({
                    method: result.paymentMethod || "",
                    details: result.paymentDetails || ""
                });
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchDashboardData();
    }, []);

    const logout = () => {
        localStorage.removeItem("agentToken");
        window.location.href = "/agent-login";
    };

    const handleUpdatePayment = async (e: React.FormEvent) => {
        e.preventDefault();
        setUpdatingPayment(true);
        const token = localStorage.getItem("agentToken");

        try {
            const response = await fetch('/api/agents/update-payment', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    paymentMethod: paymentForm.method,
                    paymentDetails: paymentForm.details
                }),
            });

            if (!response.ok) throw new Error("فشل تحديث البيانات");

            const result = await response.json();
            setData(prev => prev ? {
                ...prev,
                paymentMethod: result.agent.paymentMethod,
                paymentDetails: result.agent.paymentDetails
            } : null);
            setShowPaymentModal(false);
        } catch (err) {
            alert("حدث خطأ أثناء التحديث");
        } finally {
            setUpdatingPayment(false);
        }
    };

    const copyRefLink = () => {
        if (!data) return;
        // Generate a referral code based on agent name or other unique identifier available
        const refCode = `AGNT-${data.agentName.replace(/\s+/g, '').toUpperCase()}`;
        const link = `https://masar-edu.com/register?ref=${refCode}`;

        navigator.clipboard.writeText(link).then(() => {
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        });
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
            </div>
        );
    }

    if (!data) return null;

    return (
        <div className="min-h-screen bg-gray-50 pb-12">
            {/* Student Details Modal */}
            {selectedStudent && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setSelectedStudent(null)}>
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-white rounded-3xl p-8 max-w-lg w-full shadow-2xl relative"
                        onClick={e => e.stopPropagation()}
                    >
                        <button
                            onClick={() => setSelectedStudent(null)}
                            className="absolute top-4 left-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
                        >
                            <XCircle className="h-6 w-6 text-gray-400" />
                        </button>

                        <div className="text-center mb-6">
                            <div className="h-16 w-16 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-4 text-secondary">
                                <Users className="h-8 w-8" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900">{selectedStudent.fullName}</h3>
                            <p className="text-gray-500 mt-1">معلومات الطالب</p>
                        </div>

                        <div className="space-y-4">
                            <div className="bg-gray-50 p-4 rounded-xl border border-gray-100">
                                <span className="block text-xs text-gray-500 mb-1">التخصص المطلوب</span>
                                <span className="font-bold text-gray-900 block">{selectedStudent.desiredMajor}</span>
                            </div>

                            <div className="flex gap-4">
                                <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex-1">
                                    <span className="block text-xs text-gray-500 mb-1">تاريخ التسجيل</span>
                                    <span className="font-bold text-gray-900 block">
                                        {new Date(selectedStudent.createdAt).toLocaleDateString('ar-EG')}
                                    </span>
                                </div>
                                <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex-1">
                                    <span className="block text-xs text-gray-500 mb-1">الحالة</span>
                                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold w-fit mt-1
                                        ${selectedStudent.status === "تم القبول" ? "bg-green-100 text-green-700" :
                                            selectedStudent.status === "قيد المراجعة" ? "bg-blue-100 text-blue-700" :
                                                selectedStudent.status === "تم التواصل" ? "bg-yellow-100 text-yellow-700" :
                                                    "bg-gray-100 text-gray-700"}`}>
                                        {selectedStudent.status}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div className="mt-8 flex justify-center">
                            <button
                                onClick={() => setSelectedStudent(null)}
                                className="px-8 py-3 bg-gray-900 text-white rounded-xl font-bold hover:bg-gray-800 transition-colors"
                            >
                                إغلاق
                            </button>
                        </div>
                    </motion.div>
                </div>
            )}

            {/* Payment Modal */}
            {showPaymentModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl"
                    >
                        <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                            <Wallet className="h-6 w-6 text-secondary" />
                            تحديث بيانات الدفع
                        </h3>
                        <form onSubmit={handleUpdatePayment} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">وسيلة استلام الأرباح</label>
                                <select
                                    value={paymentForm.method}
                                    onChange={(e) => setPaymentForm({ ...paymentForm, method: e.target.value })}
                                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-secondary focus:ring-secondary transition-colors"
                                    required
                                >
                                    <option value="Bank Transfer">حوالة بنكية</option>
                                    <option value="USDT">USDT (Crypto)</option>
                                    <option value="Western Union">Western Union</option>
                                    <option value="Cash">استلام نقدي من المكتب</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">تفاصيل الدفع (رقم الحساب / المحفظة)</label>
                                <textarea
                                    value={paymentForm.details}
                                    onChange={(e) => setPaymentForm({ ...paymentForm, details: e.target.value })}
                                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-secondary focus:ring-secondary transition-colors"
                                    rows={3}
                                    placeholder="أدخل رقم الحساب البنكي أو عنوان المحفظة الإلكترونية هنا..."
                                />
                            </div>
                            <div className="flex gap-4 pt-4">
                                <button
                                    type="submit"
                                    disabled={updatingPayment}
                                    className="flex-1 bg-secondary text-white font-bold py-3 rounded-xl hover:bg-secondary-dark transition-colors disabled:opacity-50"
                                >
                                    {updatingPayment ? "جاري الحفظ..." : "حفظ التغييرات"}
                                </button>
                                <button
                                    type="button"
                                    onClick={() => setShowPaymentModal(false)}
                                    className="px-6 py-3 rounded-xl border border-gray-300 font-bold hover:bg-gray-50 transition-colors"
                                >
                                    إلغاء
                                </button>
                            </div>
                        </form>
                    </motion.div>
                </div>
            )}

            {/* Header */}
            <header className="bg-white border-b sticky top-0 z-30 shadow-sm">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <Link href="/" className="flex items-center gap-2">
                            <GraduationCap className="h-8 w-8 text-secondary" />
                            <span className="text-xl font-bold font-heading text-primary hidden sm:block">مسار التعليمية</span>
                        </Link>
                        <div className="h-6 w-[1px] bg-gray-200 mx-2 hidden sm:block"></div>
                        <h1 className="text-lg font-bold text-gray-700">لوحة التحكم للوكلاء</h1>
                    </div>

                    <div className="flex items-center gap-4">
                        <div className="bg-secondary/10 text-secondary px-3 py-1 rounded-full text-sm font-bold hidden sm:block">
                            مستوى {data.currentTier}
                        </div>
                        <button
                            onClick={logout}
                            className="flex items-center gap-2 text-gray-500 hover:text-red-500 transition-colors"
                        >
                            <span className="hidden sm:block text-sm">تسجيل الخروج</span>
                            <LogOut className="h-5 w-5" />
                        </button>
                    </div>
                </div>
            </header>

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Welcome Section */}
                <div className="mb-8">
                    <h2 className="text-2xl font-bold text-gray-900">أهلاً بك، {data.agentName} 👋</h2>
                    <p className="text-gray-600">إليك نظرة سريعة على أداء طلابك وأرباحك.</p>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <FadeIn delay={0.1} direction="up" className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
                        <div className="bg-primary/10 p-4 rounded-xl text-primary">
                            <Users className="h-8 w-8" />
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">إجمالي الطلاب</p>
                            <p className="text-2xl font-bold">{data.totalStudents}</p>
                        </div>
                    </FadeIn>

                    <FadeIn delay={0.2} direction="up" className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
                        <div className="bg-green-100 p-4 rounded-xl text-green-600">
                            <DollarSign className="h-8 w-8" />
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">إجمالي الأرباح</p>
                            <p className="text-2xl font-bold">${data.totalEarnings}</p>
                        </div>
                    </FadeIn>

                    <FadeIn delay={0.3} direction="up" className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
                        <div className="bg-secondary/10 p-4 rounded-xl text-secondary">
                            <TrendingUp className="h-8 w-8" />
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">المستوى الحالي</p>
                            <p className="text-2xl font-bold">{data.currentTier}</p>
                        </div>
                    </FadeIn>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Students List */}
                    <FadeIn delay={0.4} className="lg:col-span-2 space-y-6">
                        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                            <div className="p-6 border-b flex items-center justify-between">
                                <h3 className="text-lg font-bold flex items-center gap-2">
                                    <Users className="h-5 w-5 text-secondary" />
                                    قائمة الطلاب
                                </h3>
                                <div className="relative">
                                    <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
                                    <input
                                        type="text"
                                        placeholder="بحث عن طالب..."
                                        className="pr-10 pl-4 py-2 border rounded-lg text-sm focus:ring-secondary focus:border-secondary"
                                    />
                                </div>
                            </div>

                            <div className="overflow-x-auto">
                                <table className="w-full text-right">
                                    <thead className="bg-gray-50 text-gray-500 text-sm">
                                        <tr>
                                            <th className="px-6 py-4 font-semibold">اسم الطالب</th>
                                            <th className="px-6 py-4 font-semibold">التخصص</th>
                                            <th className="px-6 py-4 font-semibold">الحالة</th>
                                            <th className="px-6 py-4 font-semibold text-center">الإجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-100">
                                        {data.students.map((student) => (
                                            <tr key={student.id} className="hover:bg-gray-50 transition-colors">
                                                <td className="px-6 py-4 font-medium text-gray-900">{student.fullName}</td>
                                                <td className="px-6 py-4 text-gray-600">{student.desiredMajor}</td>
                                                <td className="px-6 py-4">
                                                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${student.status === "تم القبول" ? "bg-green-100 text-green-700" :
                                                        student.status === "قيد المراجعة" ? "bg-blue-100 text-blue-700" :
                                                            student.status === "تم التواصل" ? "bg-yellow-100 text-yellow-700" :
                                                                "bg-gray-100 text-gray-700"
                                                        }`}>
                                                        {student.status === "تم القبول" && <CheckCircle className="h-3 w-3" />}
                                                        {student.status === "قيد المراجعة" && <Clock className="h-3 w-3" />}
                                                        {student.status}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <TableActions
                                                        actions={[
                                                            { label: "عرض التفاصيل", icon: Eye, onClick: () => setSelectedStudent(student) },
                                                        ]}
                                                    />
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>

                            <div className="p-4 bg-gray-50 border-t text-center text-xs text-gray-400">
                                تم عرض جميع الطلاب
                            </div>
                        </div>
                    </FadeIn>

                    {/* Sidebar Info */}
                    <div className="space-y-6">
                        {/* Tier Progress */}
                        <FadeIn delay={0.5} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                                <BarChart3 className="h-5 w-5 text-secondary" />
                                التقدم نحو المستوى الذهبي
                            </h3>
                            <div className="space-y-4">
                                <div className="flex justify-between text-sm">
                                    <span className="text-gray-500">{data.totalStudents} / 16 طالب</span>
                                    <span className="font-bold text-secondary">
                                        {Math.min(100, Math.round((data.totalStudents / 16) * 100))}%
                                    </span>
                                </div>
                                <div className="w-full bg-gray-100 h-2.5 rounded-full overflow-hidden">
                                    <motion.div
                                        initial={{ width: 0 }}
                                        animate={{ width: `${Math.min(100, (data.totalStudents / 16) * 100)}%` }}
                                        className="h-full bg-secondary"
                                    ></motion.div>
                                </div>
                                <p className="text-xs text-gray-500 leading-relaxed italic">
                                    {data.totalStudents < 16
                                        ? `تبعد ${16 - data.totalStudents} طلاب فقط عن المستوى الذهبي لبدء استلام عمولة 100$ لكل طالب!`
                                        : "تهانينا! أنت الآن في المستوى الذهبي وتستحق أعلى عمولة."
                                    }
                                </p>
                            </div>
                        </FadeIn>

                        {/* Payment Info */}
                        <FadeIn delay={0.6} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                                <Wallet className="h-5 w-5 text-secondary" />
                                معلومات الدفع
                            </h3>
                            <div className="space-y-3 bg-gray-50 p-4 rounded-xl border border-dashed border-gray-200">
                                <div className="flex justify-between text-sm">
                                    <span className="text-gray-500">الوسيلة:</span>
                                    <span className="font-bold text-right">
                                        {data.paymentMethod === "Bank Transfer" ? "حوالة بنكية" :
                                            data.paymentMethod === "USDT" ? "USDT (Crypto)" :
                                                data.paymentMethod === "Western Union" ? "Western Union" :
                                                    data.paymentMethod === "Cash" ? "استلام نقدي" : data.paymentMethod || "غير محدد"}
                                    </span>
                                </div>
                                <div className="text-sm">
                                    <span className="text-gray-500 block mb-1 underline">تفاصيل الحساب:</span>
                                    <span className="font-mono text-xs break-all leading-relaxed bg-white p-2 rounded block border italic">
                                        {data.paymentDetails || "لم يتم تحديد تفاصيل بعد"}
                                    </span>
                                </div>
                                <button
                                    onClick={() => setShowPaymentModal(true)}
                                    className="w-full mt-2 text-primary text-xs font-bold hover:underline transition-all"
                                >
                                    تحديث بيانات الدفع
                                </button>
                            </div>
                        </FadeIn>

                        {/* Marketing Links placeholder */}
                        <FadeIn delay={0.7} className="bg-primary p-6 rounded-2xl shadow-lg text-white">
                            <h3 className="text-lg font-bold mb-2">رابط الإحالة الخاص بك</h3>
                            <p className="text-sm opacity-80 mb-4">شاركه مع الطلاب ليتم تسجيلهم تحت اسمك تلقائياً.</p>
                            <div className="bg-white/10 p-3 rounded-lg flex items-center justify-between border border-white/20">
                                <span className="text-xs font-mono truncate mr-2" dir="ltr">masar-edu.com/register?ref=AGNT-{data.agentName.replace(/\s+/g, '')}</span>
                                <button
                                    onClick={copyRefLink}
                                    className="bg-white text-primary px-3 py-1 rounded-md text-xs font-bold hover:bg-white/90 transition-colors min-w-[60px]"
                                >
                                    {copied ? "تم النسخ" : "نسخ"}
                                </button>
                            </div>
                        </FadeIn>
                    </div>
                </div>
            </main>
        </div>
    );
}


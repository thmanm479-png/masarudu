"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { KeyRound, AlertCircle, CheckCircle, ArrowRight } from "lucide-react";
import Link from "next/link";
import FadeIn from "@/components/FadeIn";

const schema = z.object({
    email: z.string().email({ message: "البريد الإلكتروني غير صالح" }),
});

type FormData = z.infer<typeof schema>;

export default function AgentForgotPassword() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState("");

    const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
        resolver: zodResolver(schema),
    });

    const onSubmit = async (data: FormData) => {
        setIsSubmitting(true);
        setError("");

        try {
            const response = await fetch('/api/agents/forgot-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || "حدث خطأ أثناء معالجة الطلب");
            }

            setIsSuccess(true);
        } catch (err: any) {
            setError(err.message || "حدث خطأ أثناء إرسال طلب إعادة التعيين");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="min-h-screen pt-24 pb-12 bg-gray-50 flex items-center justify-center px-4">
            <div className="max-w-md w-full">
                <div className="text-center mb-8">
                    <h1 className="text-3xl font-bold text-gray-900">نسيت كلمة المرور؟</h1>
                    <p className="text-gray-600 mt-2">أدخل بريدك الإلكتروني وسنرسل لك رابطاً لإعادة تعيين كلمة المرور.</p>
                </div>

                <FadeIn>
                    <div className="bg-white p-8 rounded-2xl shadow-xl border-t-4 border-secondary">
                        {isSuccess ? (
                            <div className="text-center">
                                <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                                    <CheckCircle className="w-8 h-8 text-green-600" />
                                </div>
                                <h3 className="text-xl font-bold text-gray-900 mb-2">تم الإرسال بنجاح</h3>
                                <p className="text-gray-600 mb-6">
                                    إذا كان هذا البريد مسجلاً لدينا، فستتلقى رسالة تحتوي على تعليمات إعادة تعيين كلمة المرور قريباً.
                                </p>
                                <Link
                                    href="/agent-login"
                                    className="text-primary font-bold hover:underline flex items-center justify-center gap-2"
                                >
                                    <ArrowRight className="h-4 w-4" /> العودة لتسجيل الدخول
                                </Link>
                            </div>
                        ) : (
                            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
                                    <input
                                        type="email"
                                        {...register("email")}
                                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-secondary focus:ring-secondary transition-colors"
                                        placeholder="example@email.com"
                                    />
                                    {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
                                </div>

                                {error && (
                                    <div className="bg-red-50 text-red-600 p-4 rounded-xl flex items-center gap-2">
                                        <AlertCircle className="h-5 w-5" />
                                        {error}
                                    </div>
                                )}

                                <button
                                    type="submit"
                                    disabled={isSubmitting}
                                    className="w-full bg-secondary text-white font-bold py-4 rounded-xl hover:bg-secondary-dark transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg flex justify-center items-center gap-2 disabled:opacity-70"
                                >
                                    <KeyRound className="h-5 w-5" />
                                    {isSubmitting ? "جاري الإرسال..." : "إرسال رابط إعادة التعيين"}
                                </button>

                                <div className="text-center">
                                    <Link
                                        href="/agent-login"
                                        className="text-sm text-gray-600 hover:text-primary transition-colors inline-flex items-center gap-1"
                                    >
                                        <ArrowRight className="h-4 w-4" /> تذكرت كلمة المرور؟ عد للدخول
                                    </Link>
                                </div>
                            </form>
                        )}
                    </div>
                </FadeIn>
            </div>
        </div>
    );
}

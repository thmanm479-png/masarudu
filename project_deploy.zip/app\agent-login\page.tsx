"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { LogIn, AlertCircle, GraduationCap } from "lucide-react";
import Link from "next/link";
import FadeIn from "@/components/FadeIn";

const schema = z.object({
    email: z.string().email({ message: "البريد الإلكتروني غير صالح" }),
    password: z.string().min(1, { message: "كلمة المرور مطلوبة" }),
});

type FormData = z.infer<typeof schema>;

export default function AgentLogin() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState("");

    const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
        resolver: zodResolver(schema),
    });

    const onSubmit = async (data: FormData) => {
        setIsSubmitting(true);
        setError("");

        try {
            const response = await fetch('/api/agents/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || "فشل تسجيل الدخول");
            }

            // In a real app, save token and redirect
            localStorage.setItem("agentToken", result.token);
            window.location.href = "/agent-dashboard";
        } catch (err: any) {
            setError(err.message || "حدث خطأ أثناء تسجيل الدخول");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="min-h-screen pt-24 pb-12 bg-gray-50 flex items-center justify-center px-4">
            <div className="max-w-md w-full">
                <div className="text-center mb-8">
                    <Link href="/" className="inline-flex items-center gap-2 mb-4">
                        <GraduationCap className="h-10 w-10 text-secondary" />
                        <span className="text-2xl font-bold text-gray-900">مسار التعليمية</span>
                    </Link>
                    <h1 className="text-3xl font-bold text-gray-900">دخول الوكلاء</h1>
                    <p className="text-gray-600 mt-2">مرحباً بك مجدداً في لوحة التحكم الخاصة بك</p>
                </div>

                <FadeIn>
                    <div className="bg-white p-8 rounded-2xl shadow-xl border-t-4 border-primary">
                        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
                                <input
                                    type="email"
                                    {...register("email")}
                                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-primary focus:ring-primary transition-colors"
                                    placeholder="example@email.com"
                                />
                                {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
                            </div>

                            <div>
                                <div className="flex items-center justify-between mb-1">
                                    <label className="block text-sm font-medium text-gray-700">كلمة المرور</label>
                                    <Link
                                        href="/agent-forgot-password"
                                        className="text-xs font-semibold text-secondary hover:underline"
                                    >
                                        نسيت كلمة المرور؟
                                    </Link>
                                </div>
                                <input
                                    type="password"
                                    {...register("password")}
                                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-primary focus:ring-primary transition-colors"
                                    placeholder="******"
                                />
                                {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password.message}</p>}
                            </div>

                            {error && (
                                <div className="bg-red-50 text-red-600 p-4 rounded-xl flex items-center gap-2">
                                    <AlertCircle className="h-5 w-5" />
                                    {error}
                                </div>
                            )}

                            <button
                                type="submit"
                                disabled={isSubmitting}
                                className="w-full bg-primary text-white font-bold py-4 rounded-xl hover:bg-primary-dark transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg flex justify-center items-center gap-2 disabled:opacity-70"
                            >
                                <LogIn className="h-5 w-5" />
                                {isSubmitting ? "جاري الدخول..." : "تسجيل الدخول"}
                            </button>

                            <div className="text-center text-sm text-gray-600 mt-6">
                                ليس لديك حساب وكيل؟{" "}
                                <Link href="/agent-register" className="text-secondary font-bold hover:underline">
                                    سجل الآن كوكيل
                                </Link>
                            </div>
                        </form>
                    </div>
                </FadeIn>
            </div>
        </div>
    );
}

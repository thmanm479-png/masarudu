"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { CheckCircle, AlertCircle, TrendingUp, Users, DollarSign, Briefcase } from "lucide-react";
import FadeIn from "@/components/FadeIn";

const schema = z.object({
    fullName: z.string().min(3, { message: "الاسم الكامل مطلوب (3 أحرف على الأقل)" }),
    phone: z.string().min(10, { message: "رقم الهاتف غير صالح" }),
    email: z.string().email({ message: "البريد الإلكتروني غير صالح" }),
    password: z.string().min(6, { message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" }),
    confirmPassword: z.string(),
    studentCount: z.string().min(1, { message: "توقع عدد الطلاب مطلوب" }),
    paymentMethod: z.string().min(1, { message: "يرجى اختيار وسيلة الدفع" }),
    experience: z.string().min(10, { message: "يرجى ذكر نبذة عن خبرتك التعليمية" }),
}).refine((data) => data.password === data.confirmPassword, {
    message: "كلمات المرور غير متطابقة",
    path: ["confirmPassword"],
});

type FormData = z.infer<typeof schema>;

export default function AgentRegister() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState("");

    const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({
        resolver: zodResolver(schema),
    });

    const onSubmit = async (data: FormData) => {
        setIsSubmitting(true);
        setError("");

        try {
            const response = await fetch('/api/agents', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || "حدث خطأ أثناء إرسال الطلب");
            }

            setIsSuccess(true);
            reset();
        } catch (err: any) {
            setError(err.message || "حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى.");
        } finally {
            setIsSubmitting(false);
        }
    };

    if (isSuccess) {
        return (
            <div className="min-h-screen pt-24 pb-12 flex items-center justify-center bg-gray-50 px-4">
                <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-white p-8 rounded-2xl shadow-xl max-w-lg w-full text-center border-t-4 border-secondary"
                >
                    <div className="mx-auto w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6">
                        <CheckCircle className="w-10 h-10 text-green-600" />
                    </div>
                    <h2 className="text-3xl font-bold text-gray-900 mb-4">تم استلام طلبك بنجاح!</h2>
                    <p className="text-gray-600 text-lg mb-8">
                        شكراً لاهتمامك بالانضمام إلى فريق وكلائنا. سيقوم فريقنا بمراجعة طلبك والتواصل معك قريباً لمناقشة التفاصيل وبدء رحلة النجاح معاً.
                    </p>
                    <button
                        onClick={() => setIsSuccess(false)}
                        className="bg-primary text-white px-8 py-3 rounded-xl font-bold hover:bg-primary-dark transition-colors w-full"
                    >
                        عودة للصفحة الرئيسية
                    </button>
                </motion.div>
            </div>
        );
    }

    return (
        <div className="min-h-screen pt-24 pb-12 bg-gray-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-16">
                    <FadeIn>
                        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">كن شريكاً في النجاح</h1>
                        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                            انضم إلى شبكة وكلائنا المعتمدين وابدأ بتحقيق عوائد مجزية من خلال توجيه الطلاب نحو مستقبل تعليمي أفضل في تركيا.
                        </p>
                    </FadeIn>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
                    {/* Benefits Section */}
                    <FadeIn direction="right" delay={0.2}>
                        <div className="bg-white p-8 rounded-2xl shadow-md border border-gray-100 mb-8">
                            <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
                                <TrendingUp className="text-secondary h-8 w-8" />
                                لماذا تنضم إلينا؟
                            </h3>

                            <div className="space-y-6">
                                <div className="flex gap-4">
                                    <div className="bg-primary/10 p-3 rounded-lg h-fit">
                                        <DollarSign className="text-primary h-6 w-6" />
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-lg text-gray-900 mb-1">عمولات مجزية وتصاعدية</h4>
                                        <p className="text-gray-600">نبدأ معك بعمولة <span className="text-secondary font-bold">50$</span> لكل طالب، وتتضاعف النسبة كلما زاد عدد طلابك المسجلين.</p>
                                    </div>
                                </div>

                                <div className="flex gap-4">
                                    <div className="bg-primary/10 p-3 rounded-lg h-fit">
                                        <Briefcase className="text-primary h-6 w-6" />
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-lg text-gray-900 mb-1">لوحة تحكم خاصة</h4>
                                        <p className="text-gray-600">احصل على وصول كامل للوحة تحكم تمكنك من متابعة طلبات طلابك وحالة قبولاتهم وعمولاتك بشكل لحظي.</p>
                                    </div>
                                </div>

                                <div className="flex gap-4">
                                    <div className="bg-primary/10 p-3 rounded-lg h-fit">
                                        <Users className="text-primary h-6 w-6" />
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-lg text-gray-900 mb-1">دعم مستمر</h4>
                                        <p className="text-gray-600">فريقنا متواجد دائماً لدعمك وتزويدك بالمواد التسويقية والإرشادات اللازمة لنجاحك.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="bg-gradient-to-br from-primary to-primary-dark p-8 rounded-2xl shadow-lg text-white">
                            <h3 className="text-2xl font-bold mb-4">نظام المستويات</h3>
                            <div className="space-y-4">
                                <div className="flex items-center justify-between border-b border-white/20 pb-2">
                                    <span>المستوى البرونزي (1-5 طلاب)</span>
                                    <span className="font-bold text-secondary">50$ / طالب</span>
                                </div>
                                <div className="flex items-center justify-between border-b border-white/20 pb-2">
                                    <span>المستوى الفضي (6-15 طالب)</span>
                                    <span className="font-bold text-secondary">75$ / طالب</span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span>المستوى الذهبي (+16 طالب)</span>
                                    <span className="font-bold text-secondary">100$ / طالب</span>
                                </div>
                            </div>
                        </div>
                    </FadeIn>

                    {/* Form Section */}
                    <FadeIn direction="left" delay={0.4}>
                        <div className="bg-white p-8 rounded-2xl shadow-xl border-t-4 border-secondary">
                            <h3 className="text-2xl font-bold text-gray-900 mb-6">نموذج التسجيل</h3>
                            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">الاسم الكامل</label>
                                    <input
                                        type="text"
                                        {...register("fullName")}
                                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-secondary focus:ring-secondary transition-colors"
                                        placeholder="الاسم الثلاثي"
                                    />
                                    {errors.fullName && <p className="text-red-500 text-sm mt-1">{errors.fullName.message}</p>}
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">رقم الهاتف (مع الرمز الدولي)</label>
                                        <input
                                            type="text"
                                            {...register("phone")}
                                            className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-secondary focus:ring-secondary transition-colors"
                                            placeholder="+90 555 ..."
                                            dir="ltr"
                                        />
                                        {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone.message}</p>}
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
                                        <input
                                            type="email"
                                            {...register("email")}
                                            className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-secondary focus:ring-secondary transition-colors"
                                            placeholder="example@email.com"
                                        />
                                        {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">كلمة المرور</label>
                                        <input
                                            type="password"
                                            {...register("password")}
                                            className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-secondary focus:ring-secondary transition-colors"
                                            placeholder="******"
                                        />
                                        {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password.message}</p>}
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">تأكيد كلمة المرور</label>
                                        <input
                                            type="password"
                                            {...register("confirmPassword")}
                                            className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-secondary focus:ring-secondary transition-colors"
                                            placeholder="******"
                                        />
                                        {errors.confirmPassword && <p className="text-red-500 text-sm mt-1">{errors.confirmPassword.message}</p>}
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">الطلاب المتوقعين سنوياً</label>
                                        <select
                                            {...register("studentCount")}
                                            className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-secondary focus:ring-secondary transition-colors"
                                        >
                                            <option value="">اختر العدد</option>
                                            <option value="1-5">1 - 5 طلاب</option>
                                            <option value="6-20">6 - 20 طالب</option>
                                            <option value="21-50">21 - 50 طالب</option>
                                            <option value="+50">أكثر من 50 طالب</option>
                                        </select>
                                        {errors.studentCount && <p className="text-red-500 text-sm mt-1">{errors.studentCount.message}</p>}
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">وسيلة استلام الأرباح</label>
                                        <select
                                            {...register("paymentMethod")}
                                            className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-secondary focus:ring-secondary transition-colors"
                                        >
                                            <option value="">اختر الوسيلة</option>
                                            <option value="Bank Transfer">حوالة بنكية</option>
                                            <option value="USDT">USDT (Crypto)</option>
                                            <option value="Western Union">Western Union</option>
                                            <option value="Cash">استلام نقدي من المكتب</option>
                                        </select>
                                        {errors.paymentMethod && <p className="text-red-500 text-sm mt-1">{errors.paymentMethod.message}</p>}
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">الخبرة التعليمية</label>
                                    <textarea
                                        {...register("experience")}
                                        rows={4}
                                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-secondary focus:ring-secondary transition-colors resize-none"
                                        placeholder="حدثنا عن خبرتك في مجال التعليم أو الخدمات الطلابية..."
                                    ></textarea>
                                    {errors.experience && <p className="text-red-500 text-sm mt-1">{errors.experience.message}</p>}
                                </div>

                                {error && (
                                    <div className="bg-red-50 text-red-600 p-4 rounded-xl flex items-center gap-2">
                                        <AlertCircle className="h-5 w-5" />
                                        {error}
                                    </div>
                                )}

                                <button
                                    type="submit"
                                    disabled={isSubmitting}
                                    className="w-full bg-secondary text-white font-bold py-4 rounded-xl hover:bg-secondary-dark transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-secondary/20 disabled:opacity-70 disabled:cursor-not-allowed"
                                >
                                    {isSubmitting ? "جاري الإرسال..." : "تقديم طلب انضمام"}
                                </button>
                            </form>
                        </div>
                    </FadeIn>
                </div>
            </div>
        </div>
    );
}

"use client";

import { useState, Suspense } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSearchParams } from "next/navigation";
import { KeyRound, AlertCircle, CheckCircle, ArrowRight } from "lucide-react";
import Link from "next/link";
import FadeIn from "@/components/FadeIn";

const schema = z.object({
    password: z.string().min(6, { message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" }),
    confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
    message: "كلمات المرور غير متطابقة",
    path: ["confirmPassword"],
});

type FormData = z.infer<typeof schema>;

function ResetPasswordForm() {
    const searchParams = useSearchParams();
    const token = searchParams.get("token");

    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState("");

    const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
        resolver: zodResolver(schema),
    });

    const onSubmit = async (data: FormData) => {
        if (!token) {
            setError("رمز التحقق مفقود. يرجى استخدام الرابط المرسل لبريدك الإلكتروني.");
            return;
        }

        setIsSubmitting(true);
        setError("");

        try {
            const response = await fetch('/api/agents/reset-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token, password: data.password }),
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || "حدث خطأ أثناء تحديث كلمة المرور");
            }

            setIsSuccess(true);
        } catch (err: any) {
            setError(err.message || "فشل تحديث كلمة المرور. قد يكون الرابط قد انتهى.");
        } finally {
            setIsSubmitting(false);
        }
    };

    if (!token) {
        return (
            <div className="bg-white p-8 rounded-2xl shadow-xl border-t-4 border-red-500 text-center">
                <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-2">رابط غير صالح</h3>
                <p className="text-gray-600 mb-6">يرجى طلب رابط جديد لإعادة تعيين كلمة المرور.</p>
                <Link href="/agent-forgot-password" className="text-primary font-bold hover:underline">
                    اطلب رابطاً جديداً
                </Link>
            </div>
        );
    }

    return (
        <div className="bg-white p-8 rounded-2xl shadow-xl border-t-4 border-primary">
            {isSuccess ? (
                <div className="text-center">
                    <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                        <CheckCircle className="w-8 h-8 text-green-600" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">تم التحديث بنجاح</h3>
                    <p className="text-gray-600 mb-6">تم تغيير كلمة المرور الخاصة بك بنجاح. يمكنك الآن تسجيل الدخول باستخدام كلمة المرور الجديدة.</p>
                    <Link href="/agent-login" className="bg-primary text-white px-8 py-3 rounded-xl font-bold hover:bg-primary-dark transition-colors inline-block w-full">
                        تسجيل الدخول
                    </Link>
                </div>
            ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">كلمة المرور الجديدة</label>
                        <input
                            type="password"
                            {...register("password")}
                            className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-primary focus:ring-primary transition-colors"
                            placeholder="******"
                        />
                        {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password.message}</p>}
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">تأكيد كلمة المرور الجديدة</label>
                        <input
                            type="password"
                            {...register("confirmPassword")}
                            className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-primary focus:ring-primary transition-colors"
                            placeholder="******"
                        />
                        {errors.confirmPassword && <p className="text-red-500 text-sm mt-1">{errors.confirmPassword.message}</p>}
                    </div>

                    {error && (
                        <div className="bg-red-50 text-red-600 p-4 rounded-xl flex items-center gap-2">
                            <AlertCircle className="h-5 w-5" />
                            {error}
                        </div>
                    )}

                    <button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-primary text-white font-bold py-4 rounded-xl hover:bg-primary-dark transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg flex justify-center items-center gap-2 disabled:opacity-70"
                    >
                        <KeyRound className="h-5 w-5" />
                        {isSubmitting ? "جاري التحديث..." : "تحديث كلمة المرور"}
                    </button>
                </form>
            )}
        </div>
    );
}

export default function AgentResetPassword() {
    return (
        <div className="min-h-screen pt-24 pb-12 bg-gray-50 flex items-center justify-center px-4">
            <div className="max-w-md w-full">
                <div className="text-center mb-8">
                    <h1 className="text-3xl font-bold text-gray-900">إعادة تعيين كلمة المرور</h1>
                    <p className="text-gray-600 mt-2">يرجى إدخال كلمة المرور الجديدة الخاصة بك أدناه.</p>
                </div>

                <FadeIn>
                    <Suspense fallback={<div className="text-center p-8">جاري التحميل...</div>}>
                        <ResetPasswordForm />
                    </Suspense>
                </FadeIn>
            </div>
        </div>
    );
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function DELETE(
    request: Request,
    { params }: { params: { id: string } }
) {
    try {
        const id = parseInt(params.id);

        // Check if it's the last admin
        const adminCount = await prisma.admin.count();
        if (adminCount <= 1) {
            return NextResponse.json({ error: "Cannot delete the last admin" }, { status: 400 });
        }

        await prisma.admin.delete({
            where: { id },
        });

        return NextResponse.json({ message: "Admin deleted successfully" });
    } catch (error) {
        console.error("Failed to delete admin:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";

export async function GET() {
    try {
        const admins = await prisma.admin.findMany({
            select: {
                id: true,
                username: true,
            },
        });
        return NextResponse.json(admins);
    } catch (error) {
        console.error("Failed to fetch admins:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const { username, password } = await request.json();

        if (!username || !password) {
            return NextResponse.json({ error: "Username and password are required" }, { status: 400 });
        }

        const existingAdmin = await prisma.admin.findUnique({
            where: { username },
        });

        if (existingAdmin) {
            return NextResponse.json({ error: "Admin already exists" }, { status: 400 });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const admin = await prisma.admin.create({
            data: {
                username,
                password: hashedPassword,
            },
        });

        return NextResponse.json({ id: admin.id, username: admin.username });
    } catch (error) {
        console.error("Failed to create admin:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

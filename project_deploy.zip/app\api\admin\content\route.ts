import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
    try {
        const content = await prisma.siteContent.findMany({
            orderBy: { key: "asc" },
        });
        return NextResponse.json(content);
    } catch (error) {
        console.error("Failed to fetch site content:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

export async function PUT(request: Request) {
    try {
        const body = await request.json();
        const { key, value, group } = body;

        if (!key) {
            return NextResponse.json({ error: "Key is required" }, { status: 400 });
        }

        const content = await prisma.siteContent.upsert({
            where: { key: key },
            update: { value, group },
            create: { key, value, group },
        });

        return NextResponse.json(content);
    } catch (error) {
        console.error("Failed to update site content:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

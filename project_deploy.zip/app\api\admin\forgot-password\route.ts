import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import crypto from "crypto";
import { sendEmail } from "@/lib/mail";

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { email } = body;

        if (!email) {
            return NextResponse.json({ error: "البريد الإلكتروني مطلوب" }, { status: 400 });
        }

        const admin = await prisma.admin.findFirst({
            where: { email },
        });

        if (!admin) {
            // For security reasons, don't reveal if the admin exists
            return NextResponse.json({ success: true });
        }

        // Generate reset token
        const resetToken = crypto.randomBytes(32).toString("hex");
        const resetTokenExpires = new Date(Date.now() + 3600000); // 1 hour

        await prisma.admin.update({
            where: { id: admin.id },
            data: {
                resetToken,
                resetTokenExpires,
            },
        });

        // Send email
        const resetUrl = `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/admin/reset-password?token=${resetToken}`;

        const emailResult = await sendEmail({
            to: email,
            subject: "إعادة تعيين كلمة المرور - Masar Education",
            html: `
                <div dir="rtl">
                    <h1>طلب إعادة تعيين كلمة المرور</h1>
                    <p>لقد طلبت إعادة تعيين كلمة المرور الخاصة بحسابك المسؤول.</p>
                    <p>اضغط على الرابط أدناه لتعيين كلمة مرور جديدة:</p>
                    <a href="${resetUrl}" style="padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">إعادة تعيين كلمة المرور</a>
                    <p>هذا الرابط صالح لمدة ساعة واحدة.</p>
                    <p>إذا لم تطلب هذا التغيير، يرجى تجاهل هذا البريد.</p>
                </div>
            `
        });

        if (!emailResult.success) {
            console.error("Failed to send email:", emailResult.error);
            // In dev/demo mode, we might want to return the link
            if (process.env.NODE_ENV === 'development') {
                return NextResponse.json({ success: true, message: "Email simulation", debugLink: resetUrl });
            }
        }

        return NextResponse.json({ success: true });

    } catch (error) {
        console.error("Admin forgot password error:", error);
        return NextResponse.json({ error: "حدث خطأ في الخادم" }, { status: 500 });
    }
}

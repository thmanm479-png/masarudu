import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { token, password } = body;

        if (!token || !password) {
            return NextResponse.json({ error: "البيانات المطلوبة ناقصة" }, { status: 400 });
        }

        const admin = await prisma.admin.findFirst({
            where: {
                resetToken: token,
                resetTokenExpires: {
                    gt: new Date(),
                },
            },
        });

        if (!admin) {
            return NextResponse.json({ error: "رابط إعادة التعيين غير صالح أو منتهي الصلاحية" }, { status: 400 });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        await prisma.admin.update({
            where: { id: admin.id },
            data: {
                password: hashedPassword,
                resetToken: null,
                resetTokenExpires: null,
            },
        });

        return NextResponse.json({ success: true, message: "تم تحديث كلمة المرور بنجاح" });

    } catch (error) {
        console.error("Admin reset password error:", error);
        return NextResponse.json({ error: "حدث خطأ في الخادم" }, { status: 500 });
    }
}

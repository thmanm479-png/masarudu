import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";

export async function GET() {
    try {
        const adminCount = await prisma.admin.count();
        if (adminCount > 0) {
            return NextResponse.json({ message: "Admin already exists" });
        }

        const hashedPassword = await bcrypt.hash("Admin@Masar2024", 10);
        const admin = await prisma.admin.create({
            data: {
                username: "admin",
                password: hashedPassword,
            },
        });

        return NextResponse.json({ success: true, message: "Admin created", admin: { username: admin.username } });
    } catch (error) {
        console.error("Seed error:", error);
        return NextResponse.json({ error: "Seed failed" }, { status: 500 });
    }
}

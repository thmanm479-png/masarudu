import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { jwtVerify } from "jose";

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
    try {
        const authHeader = request.headers.get("authorization");
        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            return NextResponse.json({ error: "غير مصرح لك بالوصول" }, { status: 401 });
        }

        const token = authHeader.split(" ")[1];
        const secret = new TextEncoder().encode(process.env.JWT_SECRET || "default_secret_key");

        const { payload } = await jwtVerify(token, secret);
        const agentId = payload.id as number;

        const agent = await prisma.agent.findUnique({
            where: { id: agentId },
            include: {
                clients: true, // Assuming students are stored as 'clients' associated with agent
            }
        });

        if (!agent) {
            return NextResponse.json({ error: "الوكيل غير موجود" }, { status: 404 });
        }

        const studentsCount = agent.clients.length;
        let tier = "برونزي";
        let rate = 50;

        if (studentsCount > 15) {
            tier = "ذهبي";
            rate = 100;
        } else if (studentsCount > 5) {
            tier = "فضي";
            rate = 75;
        }

        const totalEarnings = studentsCount * rate;

        return NextResponse.json({
            agentName: agent.fullName,
            totalStudents: studentsCount,
            totalEarnings: totalEarnings,
            currentTier: tier,
            paymentMethod: agent.paymentMethod,
            paymentDetails: agent.paymentDetails,
            students: agent.clients.map(c => ({
                id: c.id,
                fullName: c.fullName,
                desiredMajor: c.desiredMajor || "غير محدد",
                status: c.status || "جديد",
                createdAt: c.createdAt.toISOString().split('T')[0],
            }))
        });

    } catch (error) {
        console.error("Dashboard API error:", error);
        return NextResponse.json({ error: "حدث خطأ أثناء جلب البيانات" }, { status: 500 });
    }
}

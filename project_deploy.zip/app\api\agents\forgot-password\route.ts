import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import crypto from "crypto";
import { sendEmail } from "@/lib/mail";

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { email } = body;

        if (!email) {
            return NextResponse.json({ error: "البريد الإلكتروني مطلوب" }, { status: 400 });
        }

        const agent = await prisma.agent.findUnique({
            where: { email },
        });

        if (!agent) {
            // For security reasons, don't reveal if the agent exists or not
            return NextResponse.json({ success: true, message: "إذا كان البريد مسجلاً، فستصلك رسالة لإعادة تعيين كلمة المرور." });
        }

        // Generate reset token
        const resetToken = crypto.randomBytes(32).toString("hex");
        const resetTokenExpires = new Date(Date.now() + 3600000); // 1 hour from now

        await prisma.agent.update({
            where: { id: agent.id },
            data: {
                resetToken,
                resetTokenExpires,
            },
        });

        // Send email
        const resetUrl = `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/agent-reset-password?token=${resetToken}`;

        const emailResult = await sendEmail({
            to: email,
            subject: "إعادة تعيين كلمة المرور - Masar Education",
            html: `
                <div dir="rtl">
                    <h1>طلب إعادة تعيين كلمة المرور</h1>
                    <p>مرحباً ${agent.fullName || ''}،</p>
                    <p>لقد طلبت إعادة تعيين كلمة المرور الخاصة بحساب الوكيل.</p>
                    <p>اضغط على الرابط أدناه لتعيين كلمة مرور جديدة:</p>
                    <a href="${resetUrl}" style="padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">إعادة تعيين كلمة المرور</a>
                    <p>هذا الرابط صالح لمدة ساعة واحدة.</p>
                </div>
            `
        });

        return NextResponse.json({
            success: true,
            message: "تم إرسال تعليمات إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.",
            // In dev mode, help the user
            debugLink: process.env.NODE_ENV === 'development' ? resetUrl : undefined
        });

    } catch (error) {
        console.error("Forgot password API error:", error);
        return NextResponse.json({ error: "حدث خطأ أثناء معالجة الطلب" }, { status: 500 });
    }
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";
import { SignJWT } from "jose";

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { email, password } = body;

        if (!email || !password) {
            return NextResponse.json(
                { error: "البريد الإلكتروني وكلمة المرور مطلوبان" },
                { status: 400 }
            );
        }

        const agent = await prisma.agent.findUnique({
            where: { email },
        });

        if (!agent) {
            return NextResponse.json(
                { error: "بيانات الاعتماد غير صالحة" },
                { status: 401 }
            );
        }

        if (agent.status !== "نشط") {
            return NextResponse.json(
                { error: "حسابك لا يزال قيد المراجعة من قبل الإدارة. سيتم تفعيله قريباً." },
                { status: 403 }
            );
        }

        const isPasswordValid = await bcrypt.compare(password, agent.password);

        if (!isPasswordValid) {
            return NextResponse.json(
                { error: "بيانات الاعتماد غير صالحة" },
                { status: 401 }
            );
        }

        // Create a simple JWT token
        const secret = new TextEncoder().encode(process.env.JWT_SECRET || "default_secret_key");
        const token = await new SignJWT({
            id: agent.id,
            email: agent.email,
            role: "agent"
        })
            .setProtectedHeader({ alg: "HS256" })
            .setIssuedAt()
            .setExpirationTime("24h")
            .sign(secret);

        return NextResponse.json({
            success: true,
            token,
            agent: {
                id: agent.id,
                fullName: agent.fullName,
                email: agent.email
            }
        });
    } catch (error) {
        console.error("Agent login error:", error);
        return NextResponse.json(
            { error: "حدث خطأ أثناء تسجيل الدخول" },
            { status: 500 }
        );
    }
}

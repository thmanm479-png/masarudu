import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { token, password } = body;

        if (!token || !password) {
            return NextResponse.json({ error: "الرمز وكلمة المرور الجديدة مطلوبان" }, { status: 400 });
        }

        const agent = await prisma.agent.findFirst({
            where: {
                resetToken: token,
                resetTokenExpires: {
                    gt: new Date(), // Check if not expired
                },
            },
        });

        if (!agent) {
            return NextResponse.json({ error: "رمز إعادة التعيين غير صالح أو انتهت صلاحيته" }, { status: 400 });
        }

        // Hash new password
        const hashedPassword = await bcrypt.hash(password, 10);

        await prisma.agent.update({
            where: { id: agent.id },
            data: {
                password: hashedPassword,
                resetToken: null,
                resetTokenExpires: null,
            },
        });

        return NextResponse.json({
            success: true,
            message: "تم تحديث كلمة المرور بنجاح. يمكنك الآن تسجيل الدخول."
        });

    } catch (error) {
        console.error("Reset password API error:", error);
        return NextResponse.json({ error: "حدث خطأ أثناء تحديث كلمة المرور" }, { status: 500 });
    }
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { fullName, phone, email, studentCount, experience, password, paymentMethod } = body;

        // Validation
        if (!fullName || !phone || !email || !studentCount || !experience || !password) {
            return NextResponse.json(
                { error: "جميع الحقول المطلوبة يجب إكمالها" },
                { status: 400 }
            );
        }

        // Check if email already exists
        const existingAgent = await prisma.agent.findUnique({
            where: { email },
        });

        if (existingAgent) {
            return NextResponse.json(
                { error: "البريد الإلكتروني مسجل بالفعل" },
                { status: 400 }
            );
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        const agent = await prisma.agent.create({
            data: {
                fullName,
                phone,
                email,
                studentCount,
                experience,
                password: hashedPassword,
                paymentMethod: paymentMethod || "غير محدد",
                status: "قيد المراجعة",
            },
        });

        // Send notification email to admin
        const adminEmail = process.env.ADMIN_EMAIL || "admin@masar-edu.com";
        const emailContent = `
            <div dir="rtl" style="font-family: Arial, sans-serif; padding: 20px;">
                <h2>طلب تسجيل وكيل جديد</h2>
                <p>تم استلام طلب تسجيل جديد من <strong>${fullName}</strong>.</p>
                <ul>
                    <li><strong>الاسم:</strong> ${fullName}</li>
                    <li><strong>البريد الإلكتروني:</strong> ${email}</li>
                    <li><strong>الهاتف:</strong> ${phone}</li>
                    <li><strong>عدد الطلاب المتوقع:</strong> ${studentCount}</li>
                    <li><strong>الخبرة:</strong> ${experience}</li>
                </ul>
                <p>يرجى مراجعة الطلب في لوحة التحكم واتخاذ الإجراء المناسب.</p>
                <a href="${process.env.NEXT_PUBLIC_APP_URL || "https://masar-osman.vercel.app"}/admin/agents" style="background-color: #004d40; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">الذهاب للوحة التحكم</a>
            </div>
        `;

        // Don't await this to keep response fast, or await if critical?
        // Better to not block response too much, but for registration reliability is good.
        try {
            const { sendEmail } = await import("@/lib/mail");
            await sendEmail({
                to: adminEmail,
                subject: `طلب وكيل جديد: ${fullName}`,
                html: emailContent,
            });
        } catch (emailError) {
            console.error("Failed to send notification email:", emailError);
            // Continue even if email fails
        }


        return NextResponse.json({ success: true, agent: { id: agent.id, fullName: agent.fullName } });
    } catch (error) {
        console.error("Agent registration error:", error);
        return NextResponse.json(
            { error: "حدث خطأ أثناء التسجيل. يرجى المحاولة لاحقاً." },
            { status: 500 }
        );
    }
}


import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { jwtVerify } from "jose";

export async function POST(request: Request) {
    try {
        const authHeader = request.headers.get("authorization");
        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            return NextResponse.json({ error: "غير مصرح لك بالوصول" }, { status: 401 });
        }

        const token = authHeader.split(" ")[1];
        const secret = new TextEncoder().encode(process.env.JWT_SECRET || "default_secret_key");

        const { payload } = await jwtVerify(token, secret);
        const agentId = payload.id as number;

        const body = await request.json();
        const { paymentMethod, paymentDetails } = body;

        if (!paymentMethod) {
            return NextResponse.json({ error: "وسيلة الدفع مطلوبة" }, { status: 400 });
        }

        const agent = await prisma.agent.update({
            where: { id: agentId },
            data: {
                paymentMethod,
                paymentDetails: paymentDetails || "",
            },
        });

        return NextResponse.json({
            success: true,
            message: "تم تحديث بيانات الدفع بنجاح",
            agent: {
                paymentMethod: agent.paymentMethod,
                paymentDetails: agent.paymentDetails
            }
        });

    } catch (error) {
        console.error("Update payment API error:", error);
        return NextResponse.json({ error: "حدث خطأ أثناء تحديث بيانات الدفع" }, { status: 500 });
    }
}

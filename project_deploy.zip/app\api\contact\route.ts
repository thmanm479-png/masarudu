import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { sendEmail } from "@/lib/mail";

export async function POST(req: Request) {
    try {
        const body = await req.json();
        const { name, email, phone, message } = body;

        if (!name || !phone || !message) {
            return NextResponse.json(
                { error: "الرجاء ملء جميع الحقول المطلوبة" },
                { status: 400 }
            );
        }

        // Rate Limiting: Check for previous submissions from the same email in the last 5 minutes
        if (email) {
            const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
            const recentSubmission = await prisma.contactSubmission.findFirst({
                where: {
                    email: email,
                    createdAt: {
                        gte: fiveMinutesAgo,
                    },
                },
            });

            if (recentSubmission) {
                return NextResponse.json(
                    { error: "لقد قمت بإرسال رسالة مؤخراً. يرجى الانتظار قليلاً قبل المحاولة مرة أخرى." },
                    { status: 429 }
                );
            }
        }

        const submission = await prisma.contactSubmission.create({
            data: {
                name,
                email,
                phone,
                message,
            },
        });

        // Notify Admin
        await sendEmail({
            to: process.env.ADMIN_EMAIL || "admin@masar-edu.com", // Fallback or env
            subject: `رسالة جديدة من: ${name}`,
            html: `
                <div dir="rtl">
                    <h2>رسالة تواصل جديدة</h2>
                    <p><strong>الاسم:</strong> ${name}</p>
                    <p><strong>البريد:</strong> ${email}</p>
                    <p><strong>الهاتف:</strong> ${phone}</p>
                    <p><strong>الرسالة:</strong></p>
                    <p>${message}</p>
                </div>
            `
        });

        return NextResponse.json(submission, { status: 201 });
    } catch (error) {
        console.error("Contact form error:", error);
        return NextResponse.json(
            { error: "حدث خطأ أثناء إرسال الرسالة. يرجى المحاولة لاحقاً." },
            { status: 500 }
        );
    }
}

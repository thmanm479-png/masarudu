import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
    const { searchParams } = new URL(request.url);
    const username = searchParams.get("username") || "admin";
    const checkPassword = searchParams.get("password");

    const logs = [];
    logs.push(`🔍 Checking user: ${username}`);

    try {
        // 1. Test Cluster Connection
        logs.push("⏳ Connecting to DB...");
        await prisma.$connect();
        logs.push("✅ DB Connected");

        // 2. Find User
        logs.push("⏳ Finding user...");
        const admin = await prisma.admin.findUnique({
            where: { username },
        });

        if (!admin) {
            logs.push("❌ User NOT found in DB");
            return NextResponse.json({ success: false, logs }, { status: 404 });
        }
        logs.push(`✅ User found: ID=${admin.id}, Email=${admin.email}`);
        logs.push(`🔒 Stored Hash start: ${admin.password.substring(0, 10)}...`);

        // 3. Check Password (if provided)
        if (checkPassword) {
            logs.push(`⏳ Comparing password: '${checkPassword}'`);
            const isMatch = await bcrypt.compare(checkPassword, admin.password);
            logs.push(isMatch ? "✅ Password MATCHES!" : "❌ Password does NOT match");

            // Debug hash generation
            const newHash = await bcrypt.hash(checkPassword, 10);
            logs.push(`ℹ️ Test Hash would be: ${newHash.substring(0, 10)}...`);
        }

        return NextResponse.json({ success: true, logs, admin: { ...admin, password: "HIDDEN" } });

    } catch (error: any) {
        logs.push(`💥 ERROR: ${error.message}`);
        console.error(error);
        return NextResponse.json({ success: false, logs, error: error.message, stack: error.stack }, { status: 500 });
    } finally {
        await prisma.$disconnect();
    }
}

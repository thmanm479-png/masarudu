import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { fullName, phone, email, nationality, certificateType, gpa, desiredMajor, universityType, notes } = body;

        if (!fullName || !phone) {
            return NextResponse.json(
                { error: "الاسم ورقم الهاتف حقول مطلوبة" },
                { status: 400 }
            );
        }

        const client = await prisma.client.create({
            data: {
                fullName,
                phone,
                email,
                nationality,
                certificateType,
                gpa,
                desiredMajor,
                universityType,
                notes,
                status: "جديد",
            },
        });

        // Send notification email
        const adminEmail = process.env.ADMIN_EMAIL || "admin@masar-edu.com";
        const emailContent = `
            <div dir="rtl" style="font-family: Arial, sans-serif; padding: 20px;">
                <h2>تسجيل طالب جديد</h2>
                <p>تم استلام طلب تسجيل طالب جديد من <strong>${fullName}</strong>.</p>
                <ul>
                    <li><strong>الاسم:</strong> ${fullName}</li>
                    <li><strong>الهاتف:</strong> ${phone}</li>
                    <li><strong>الجنسية:</strong> ${nationality || "غير محدد"}</li>
                    <li><strong>التخصص المرغوب:</strong> ${desiredMajor || "غير محدد"}</li>
                    <li><strong>المعدل:</strong> ${gpa || "غير محدد"}</li>
                </ul>
                <p>يرجى مراجعة الطلب في لوحة التحكم.</p>
                <a href="${process.env.NEXT_PUBLIC_APP_URL || "https://masar-osman.vercel.app"}/admin/clients" style="background-color: #004d40; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">الذهاب للوحة التحكم</a>
            </div>
        `;

        try {
            const { sendEmail } = await import("@/lib/mail");
            await sendEmail({
                to: adminEmail,
                subject: `تسجيل طالب جديد: ${fullName}`,
                html: emailContent,
            });
        } catch (emailError) {
            console.error("Failed to send notification email:", emailError);
        }

        return NextResponse.json({ success: true, client });
    } catch (error: any) {
        console.error("Registration error:", error);

        // Handle Prism unique constraint violation
        if (error.code === 'P2002') {
            return NextResponse.json(
                { error: "البريد الإلكتروني أو رقم الهاتف مسجل بالفعل" },
                { status: 400 }
            );
        }

        return NextResponse.json(
            { error: "حدث خطأ في الخادم" },
            { status: 500 }
        );
    }
}

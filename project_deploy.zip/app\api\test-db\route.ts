import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
    try {
        await prisma.$connect();
        const count = await prisma.admin.count();
        return NextResponse.json({ success: true, count, message: "Database connected successfully" });
    } catch (error) {
        console.error("DB Test Error:", error);
        return NextResponse.json(
            { error: error instanceof Error ? error.message : "Database connection failed", details: error },
            { status: 500 }
        );
    } finally {
        await prisma.$disconnect();
    }
}

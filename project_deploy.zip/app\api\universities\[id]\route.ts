import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// DELETE: Delete a university
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
    try {
        const id = parseInt(params.id);
        await prisma.university.delete({
            where: { id },
        });
        return NextResponse.json({ success: true });
    } catch (error) {
        return NextResponse.json({ error: "Failed to delete university" }, { status: 500 });
    }
}

// PUT: Update a university
export async function PUT(request: Request, { params }: { params: { id: string } }) {
    try {
        const id = parseInt(params.id);
        const body = await request.json();
        const university = await prisma.university.update({
            where: { id },
            data: body,
        });
        return NextResponse.json(university);
    } catch (error) {
        return NextResponse.json({ error: "Failed to update university" }, { status: 500 });
    }
}

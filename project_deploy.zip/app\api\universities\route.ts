import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET: Fetch all universities
export async function GET() {
    try {
        const universities = await prisma.university.findMany({
            orderBy: { name: "asc" },
        });
        return NextResponse.json(universities);
    } catch (error) {
        return NextResponse.json({ error: "Failed to fetch universities" }, { status: 500 });
    }
}

// POST: Create a new university
export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { name, city, type, applicationFee, tuitionFee, admissionReqs, language, scholarship, description } = body;

        const university = await prisma.university.create({
            data: {
                name,
                city,
                type,
                applicationFee,
                tuitionFee,
                admissionReqs,
                language,
                scholarship,
                description,
            },
        });

        return NextResponse.json(university);
    } catch (error) {
        return NextResponse.json({ error: "Failed to create university" }, { status: 500 });
    }
}

import Contact from "@/components/Contact";

export const metadata = {
    title: "اتصل بنا",
    description: "تواصل مع فريق مسار للخدمات التعليمية للحصول على استشارة مجانية حول الدراسة في تركيا.",
};

export default function ContactPage() {
    return (
        <div className="pt-20">
            <Contact />
        </div>
    );
}

import type { Metadata } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import FloatingWhatsapp from "@/components/FloatingWhatsapp";
import FloatingAgentButton from "@/components/FloatingAgentButton";
import MarketingBanner from "@/components/MarketingBanner";
import ScrollProgress from "@/components/ScrollProgress";

const cairo = Cairo({
    subsets: ["arabic"],
    variable: "--font-cairo",
});

export const metadata: Metadata = {
    metadataBase: new URL('https://masar-edu.com'), // Replace with actual domain
    title: {
        default: "مسار للخدمات التعليمية | بوابتك للدراسة في تركيا",
        template: "%s | مسار للخدمات التعليمية"
    },
    icons: {
        icon: '/favicon.svg',
    },
    description: "نرافقك في مسارك للدراسة في الجامعات التركية بثقة واحترافية. خدمات قبول جامعي، استشارات تعليمية، وسكن طلابي بأفضل الأسعار.",
    keywords: ["دراسة في تركيا", "جامعات تركية", "قبول جامعي", "منح دراسية", "تعليم في تركيا", "إقامة طلابية", "مسار التعليمية"],
    authors: [{ name: "Masar Education Team" }],
    creator: "Masar Education",
    openGraph: {
        type: 'website',
        locale: 'ar_TR',
        url: 'https://masar-edu.com',
        title: 'مسار للخدمات التعليمية - مستقبلك يبدأ من هنا',
        description: 'شريكك الموثوق للدراسة في تركيا. نقدم خدمات متكاملة من القبول حتى التخرج.',
        siteName: 'Masar Education',
        images: [
            {
                url: '/og-image.jpg', // Make sure to add this image
                width: 1200,
                height: 630,
                alt: 'Masar Education - Study in Turkey',
            },
        ],
    },
    twitter: {
        card: 'summary_large_image',
        title: 'مسار للخدمات التعليمية | الدراسة في تركيا',
        description: 'احصل على قبولك الجامعي في أفضل الجامعات التركية مع مسار.',
        images: ['/twitter-image.jpg'], // Make sure to add this image
    },
    robots: {
        index: true,
        follow: true,
        googleBot: {
            index: true,
            follow: true,
            'max-video-preview': -1,
            'max-image-preview': 'large',
            'max-snippet': -1,
        },
    },
};



export default function RootLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <html lang="ar" dir="rtl">
            <body className={`${cairo.variable} font-sans`}>
                <ScrollProgress />
                <MarketingBanner />
                <Navbar />
                {children}
                <FloatingWhatsapp />
                <FloatingAgentButton />
                <Footer />
            </body>
        </html>
    );
}

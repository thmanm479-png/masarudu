import Hero from "@/components/Hero";
import Services from "@/components/Services";
import Universities from "@/components/Universities";
import FAQ from "@/components/FAQ";
import Documents from "@/components/Documents";
import About from "@/components/About";
import Contact from "@/components/Contact";
import Partners from "@/components/Partners";
import Stats from "@/components/Stats";
import { prisma } from "@/lib/prisma";

async function getContent() {
    try {
        const content = await prisma.siteContent.findMany();
        return content.reduce((acc: any, item: any) => {
            acc[item.key] = item.value;
            return acc;
        }, {});
    } catch (error) {
        return {};
    }
}

export default async function Home() {
    const content = await getContent();

    return (
        <main>
            <Hero content={content} />
            <Stats />
            <Partners />
            <Services />
            <Universities />
            <Documents />
            <FAQ />
            <About />
            <Contact />
        </main>
    );
}

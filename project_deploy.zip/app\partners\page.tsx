'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, Building2, Handshake, ChevronRight } from 'lucide-react';
import Link from 'next/link';

export default function PartnersPage() {
    const categories = [
        {
            title: 'الجامعات الشريكة',
            items: [
                { name: 'جامعة توكات', desc: 'تخصصات طبية وزراعية عريقة' },
                { name: 'جامعة كارابوك', desc: 'أكبر عدد من الطلاب الدوليين' },
                { name: 'جامعة بولو أبانت عزت بايسال', desc: 'موقع جغرافي خلاب وتكاليف منخفضة' },
                { name: 'جامعة باتمان', desc: 'تركيز على الأبحاث التقنية' },
                { name: 'جامعة بيلجيك شيخ أديبالي', desc: 'في قلب منطقة مرمرة التاريخية' },
                { name: 'جامعة سيواس جمهوريات', desc: 'من أكبر الجامعات مساحةً' },
                { name: 'جامعة غوموش خانة', desc: 'بيئة دراسية هادئة' },
                { name: 'جامعة صكاريا', desc: 'من أفضل الجامعات الحكومية' },
                { name: 'جامعة كوجالي', desc: 'ارتباط قوي بالقطاع الصناعي' },
                { name: 'جامعة دوزجه', desc: 'تميز في البحوث الطبية' },
            ]
        },
        {
            title: 'شركاء الخدمات',
            items: [
                { name: 'مكتب الترجمة المعتمد', desc: 'خدمات ترجمة وثائق فورية' },
                { name: 'سكن الطلاب المميز', desc: 'إقامة مريحة وآمنة' },
                { name: 'مكتب الاستشارات القانونية', desc: 'دعم قانوني شامل' },
            ]
        }
    ];

    const benefits = [
        {
            icon: <Handshake className="w-8 h-8 text-secondary" />,
            title: 'شراكة استراتيجية',
            desc: 'بناء علاقات طويلة الأمد تعود بالنفع المتبادل'
        },
        {
            icon: <Building2 className="w-8 h-8 text-secondary" />,
            title: 'توسع وانتشار',
            desc: 'الوصول إلى شريحة أوسع من الطلاب والعملاء'
        },
        {
            icon: <Briefcase className="w-8 h-8 text-secondary" />,
            title: 'دعم تسويقي',
            desc: 'نروج لخدماتك عبر منصاتنا المتعددة'
        }
    ];

    return (
        <main className="min-h-screen bg-background font-sans">
            {/* Hero Section */}
            <section className="relative py-24 bg-primary text-white overflow-hidden">
                <div className="absolute inset-0 bg-[linear-gradient(45deg,#0F3D39,#082926)] opacity-90"></div>
                <div className="container mx-auto px-4 relative z-10 text-center">
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                    >
                        <h1 className="text-4xl md:text-6xl font-bold mb-6">شركاء النجاح</h1>
                        <p className="text-xl md:text-2xl text-gray-200 max-w-3xl mx-auto mb-10 leading-relaxed">
                            نؤمن بأن النجاح الحقيقي يصنعه التعاون المثمر. انضم إلى شبكة شركائنا المتميزة
                            لنصنع مستقبلاً تعليمياً أفضل معاً.
                        </p>
                        <Link
                            href="/partners/register"
                            className="inline-flex items-center gap-3 bg-secondary hover:bg-secondary-light text-primary-dark font-bold py-4 px-8 rounded-full transition-all hover:scale-105 hover:shadow-gold shadow-lg"
                        >
                            <span>سجل كشريك الآن</span>
                            <ChevronRight className="w-5 h-5 rtl:rotate-180" />
                        </Link>
                    </motion.div>
                </div>
            </section>

            {/* Benefits Section */}
            <section className="py-20 bg-white">
                <div className="container mx-auto px-4">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl font-bold text-primary mb-4">لماذا تختار الشراكة معنا؟</h2>
                        <div className="w-20 h-1 bg-secondary mx-auto rounded-full"></div>
                    </div>
                    <div className="grid md:grid-cols-3 gap-10">
                        {benefits.map((benefit, idx) => (
                            <motion.div
                                key={idx}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: idx * 0.2 }}
                                className="bg-gray-50 p-8 rounded-2xl hover:shadow-premium transition-all duration-300 transform hover:-translate-y-2 border border-gray-100"
                            >
                                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm mb-6 mx-auto">
                                    {benefit.icon}
                                </div>
                                <h3 className="text-xl font-bold text-primary mb-3 text-center">{benefit.title}</h3>
                                <p className="text-gray-600 text-center">{benefit.desc}</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Partners Display */}
            {categories.map((cat, idx) => (
                <section key={idx} className={`py-20 ${idx % 2 === 0 ? 'bg-background' : 'bg-white'}`}>
                    <div className="container mx-auto px-4">
                        <h2 className="text-3xl font-bold text-primary mb-12 border-r-4 border-secondary pr-4">
                            {cat.title}
                        </h2>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                            {cat.items.map((item, itemIdx) => (
                                <motion.div
                                    key={itemIdx}
                                    initial={{ opacity: 0, scale: 0.95 }}
                                    whileInView={{ opacity: 1, scale: 1 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: itemIdx * 0.1 }}
                                    className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-all border border-gray-100 group"
                                >
                                    <div className="aspect-video bg-gray-50 rounded-lg mb-4 flex items-center justify-center group-hover:bg-primary/5 transition-colors">
                                        <Building2 className="w-12 h-12 text-gray-300 group-hover:text-primary transition-colors" />
                                    </div>
                                    <h3 className="font-bold text-lg text-gray-800 mb-1">{item.name}</h3>
                                    <p className="text-sm text-gray-500">{item.desc}</p>
                                </motion.div>
                            ))}
                        </div>
                    </div>
                </section>
            ))}

            {/* Bottom CTA */}
            <section className="py-24 bg-primary text-white text-center relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('/pattern.svg')] opacity-5"></div>
                <div className="container mx-auto px-4 relative z-10">
                    <h2 className="text-3xl md:text-5xl font-bold mb-8">جاهز لتوسيع آفاق عملك؟</h2>
                    <p className="text-xl text-primary-100 mb-10 max-w-2xl mx-auto">
                        تواصل معنا اليوم وانضم لنخبة من المؤسسات التعليمية والخدمية الرائدة
                    </p>
                    <Link
                        href="/partners/register"
                        className="inline-flex items-center gap-3 bg-white text-primary font-bold py-4 px-10 rounded-full hover:bg-gray-100 transition-colors shadow-2xl hover:scale-105 transform duration-300"
                    >
                        ابدأ الشراكة الآن
                    </Link>
                </div>
            </section>
        </main>
    );
}

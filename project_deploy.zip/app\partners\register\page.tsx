'use client';

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { Send, CheckCircle2, User, Building, Mail, Phone, Globe, MessageSquare, Briefcase } from 'lucide-react';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';

const schema = z.object({
    orgName: z.string().min(2, { message: 'اسم المؤسسة مطلوب' }),
    repName: z.string().min(2, { message: 'اسم الممثل مطلوب' }),
    email: z.string().email({ message: 'البريد الإلكتروني غير صالح' }),
    phone: z.string().min(10, { message: 'رقم الهاتف مطلوب' }),
    website: z.string().optional(),
    type: z.enum(['university', 'service', 'agent', 'other'] as const),
    message: z.string().min(10, { message: 'الرسالة قصيرة جداً' }),
});

type FormData = z.infer<typeof schema>;

export default function PartnerRegisterPage() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);

    const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
        resolver: zodResolver(schema),
    });

    const onSubmit = async (data: FormData) => {
        setIsSubmitting(true);
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 2000));
        console.log(data);
        setIsSubmitting(false);
        setIsSuccess(true);
    };

    if (isSuccess) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
                <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full text-center border-t-4 border-secondary"
                >
                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                        <CheckCircle2 className="w-10 h-10 text-green-600" />
                    </div>
                    <h2 className="text-2xl font-bold text-primary mb-4">تم استلام طلبك بنجاح!</h2>
                    <p className="text-gray-600 mb-8">
                        شكراً لاهتمامك بالشراكة معنا. سيقوم فريقنا بمراجعة طلبك والتواصل معك في أقرب وقت ممكن.
                    </p>
                    <button
                        onClick={() => setIsSuccess(false)}
                        className="w-full bg-primary text-white py-3 rounded-xl font-bold hover:bg-primary-light transition-colors"
                    >
                        العودة
                    </button>
                </motion.div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-background py-16 px-4">
            <div className="max-w-4xl mx-auto">
                <div className="text-center mb-12">
                    <motion.h1
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-3xl md:text-5xl font-bold text-primary mb-4"
                    >
                        نموذج تسجيل الشركاء
                    </motion.h1>
                    <p className="text-gray-600 max-w-2xl mx-auto">
                        انضم إلينا اليوم وابدأ رحلة جديدة من النجاح والتعاون المثمر.
                    </p>
                </div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="bg-white rounded-3xl shadow-premium p-8 md:p-12 overflow-hidden relative"
                >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-secondary/10 rounded-bl-full -z-10"></div>

                    <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
                        <div className="grid md:grid-cols-2 gap-8">

                            {/* Organization Name */}
                            <div className="space-y-2">
                                <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                                    <Building className="w-4 h-4 text-secondary" />
                                    اسم المؤسسة
                                </label>
                                <input
                                    {...register('orgName')}
                                    className={`w-full px-4 py-3 rounded-xl border ${errors.orgName ? 'border-red-500 ring-2 ring-red-100' : 'border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20'} outline-none transition-all`}
                                    placeholder="أدخل اسم المؤسسة"
                                />
                                {errors.orgName && <p className="text-red-500 text-xs mt-1">{errors.orgName.message}</p>}
                            </div>

                            {/* Representative Name */}
                            <div className="space-y-2">
                                <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                                    <User className="w-4 h-4 text-secondary" />
                                    اسم الممثل
                                </label>
                                <input
                                    {...register('repName')}
                                    className={`w-full px-4 py-3 rounded-xl border ${errors.repName ? 'border-red-500 ring-2 ring-red-100' : 'border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20'} outline-none transition-all`}
                                    placeholder="الاسم الكامل"
                                />
                                {errors.repName && <p className="text-red-500 text-xs mt-1">{errors.repName.message}</p>}
                            </div>

                            {/* Email */}
                            <div className="space-y-2">
                                <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                                    <Mail className="w-4 h-4 text-secondary" />
                                    البريد الإلكتروني
                                </label>
                                <input
                                    type="email"
                                    {...register('email')}
                                    className={`w-full px-4 py-3 rounded-xl border ${errors.email ? 'border-red-500 ring-2 ring-red-100' : 'border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20'} outline-none transition-all`}
                                    placeholder="example@domain.com"
                                />
                                {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email.message}</p>}
                            </div>

                            {/* Phone */}
                            <div className="space-y-2">
                                <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                                    <Phone className="w-4 h-4 text-secondary" />
                                    رقم الهاتف
                                </label>
                                <input
                                    type="tel"
                                    {...register('phone')}
                                    className={`w-full px-4 py-3 rounded-xl border ${errors.phone ? 'border-red-500 ring-2 ring-red-100' : 'border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20'} outline-none transition-all`}
                                    placeholder="+90 555 000 0000"
                                    dir="ltr"
                                />
                                {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone.message}</p>}
                            </div>

                            {/* Website */}
                            <div className="space-y-2">
                                <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                                    <Globe className="w-4 h-4 text-secondary" />
                                    الموقع الإلكتروني (اختياري)
                                </label>
                                <input
                                    {...register('website')}
                                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                    placeholder="https://www.example.com"
                                    dir="ltr"
                                />
                            </div>

                            {/* Type */}
                            <div className="space-y-2">
                                <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                                    <Briefcase className="w-4 h-4 text-secondary" />
                                    نوع الشراكة
                                </label>
                                <select
                                    {...register('type')}
                                    className={`w-full px-4 py-3 rounded-xl border ${errors.type ? 'border-red-500 ring-2 ring-red-100' : 'border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20'} outline-none transition-all appearance-none bg-white`}
                                >
                                    <option value="">اختر نوع الشراكة...</option>
                                    <option value="university">جامعة / مؤسسة تعليمية</option>
                                    <option value="service">مزود خدمات</option>
                                    <option value="agent">وكيل تعليمي</option>
                                    <option value="other">أخرى</option>
                                </select>
                                {errors.type && <p className="text-red-500 text-xs mt-1">{errors.type.message}</p>}
                            </div>
                        </div>

                        {/* Message */}
                        <div className="space-y-2">
                            <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                                <MessageSquare className="w-4 h-4 text-secondary" />
                                رسالة إضافية / نبذة عن التعاون المقترح
                            </label>
                            <textarea
                                {...register('message')}
                                rows={4}
                                className={`w-full px-4 py-3 rounded-xl border ${errors.message ? 'border-red-500 ring-2 ring-red-100' : 'border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20'} outline-none transition-all resize-none`}
                                placeholder="اكتب رسالتك هنا..."
                            ></textarea>
                            {errors.message && <p className="text-red-500 text-xs mt-1">{errors.message.message}</p>}
                        </div>

                        <button
                            type="submit"
                            disabled={isSubmitting}
                            className="w-full bg-primary hover:bg-primary-dark text-white font-bold py-4 rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                        >
                            {isSubmitting ? (
                                <span className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                            ) : (
                                <>
                                    <Send className="w-5 h-5 rtl:rotate-180" />
                                    <span>إرسال طلب الشراكة</span>
                                </>
                            )}
                        </button>
                    </form>
                </motion.div>
            </div>
        </div>
    );
}



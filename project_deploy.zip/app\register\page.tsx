"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { GraduationCap, CheckCircle, AlertCircle, User, Phone, Mail, FileText, BookOpen, School, Globe } from "lucide-react";
import Link from "next/link";
import FadeIn from "@/components/FadeIn";

import Logo from "@/components/Logo";

type FormData = {
    fullName: string;
    phone: string;
    email: string;
    nationality: string;
    certificateType: string;
    gpa: string;
    desiredMajor: string;
    universityType: string;
    notes: string;
};

export default function RegisterConfirm() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState("");

    const {
        register,
        handleSubmit,
        reset,
        formState: { errors },
    } = useForm<FormData>();

    const onSubmit = async (data: FormData) => {
        setIsSubmitting(true);
        setError("");

        try {
            const response = await fetch("/api/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "حدث خطأ أثناء إرسال البيانات");
            }

            setIsSuccess(true);
            reset();
        } catch (err) {
            setError("تعذر إرسال الطلب. يرجى المحاولة مرة أخرى أو التواصل معنا عبر واتساب.");
        } finally {
            setIsSubmitting(false);
        }
    };

    if (isSuccess) {
        return (
            <div className="min-h-screen bg-gray-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
                <div className="absolute inset-0 overflow-hidden">
                    <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[100px]" />
                    <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-[100px]" />
                </div>
                <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md relative z-10">
                    <FadeIn className="bg-white/5 backdrop-blur-lg py-12 px-4 shadow-2xl ring-1 ring-white/10 sm:rounded-2xl sm:px-10 text-center border border-white/10">
                        <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-green-500/10 mb-6 ring-1 ring-green-500/20">
                            <CheckCircle className="h-10 w-10 text-green-500" />
                        </div>
                        <h3 className="text-2xl font-bold leading-9 text-white mb-2">تم استلام طلبك بنجاح!</h3>
                        <p className="mt-2 text-base text-gray-300">
                            شكراً لثقتك في مسار. سيقوم مستشارك التعليمي بمراجعة ملفك والتواصل معك عبر الواتساب قريباً جداً.
                        </p>
                        <div className="mt-8">
                            <Link href="/" className="inline-flex items-center justify-center rounded-xl bg-secondary px-8 py-3 text-sm font-semibold text-white shadow-sm hover:bg-secondary-dark focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-secondary transition-all hover:scale-105">
                                العودة للرئيسية &larr;
                            </Link>
                        </div>
                    </FadeIn>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-900 flex flex-col justify-center py-12 sm:py-24 sm:px-6 lg:px-8 relative overflow-hidden">
            {/* Background elements */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className="absolute top-[-10%] left-[-10%] w-[600px] h-[600px] bg-primary/20 rounded-full blur-[120px] opacity-40" />
                <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-secondary/10 rounded-full blur-[120px] opacity-40" />
            </div>

            <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10 px-4">
                <Link href="/" className="flex justify-center items-center gap-3 mb-6 group">
                    <Logo className="h-10 sm:h-14" />
                </Link>
                <div className="text-center mb-8">
                    <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-2">
                        سجّل طلبك الآن
                    </h1>
                    <p className="text-xs sm:text-sm text-gray-400">
                        ابدأ أولى خطواتك نحو مستقبلك الجامعي في تركيا معنا
                    </p>
                </div>
            </div>

            <div className="sm:mt-8 sm:mx-auto sm:w-full sm:max-w-xl relative z-10 px-4">
                <FadeIn className="bg-white/5 backdrop-blur-xl py-6 px-4 sm:py-8 shadow-2xl ring-1 ring-white/10 sm:rounded-3xl sm:px-10 border border-white/5">
                    <form className="space-y-6" onSubmit={handleSubmit(onSubmit)}>

                        {error && (
                            <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl flex items-center gap-3 text-red-400 text-sm">
                                <AlertCircle className="h-5 w-5 flex-shrink-0" />
                                {error}
                            </div>
                        )}

                        <div>
                            <label htmlFor="fullName" className="block text-sm font-medium text-gray-300 mb-2">
                                الاسم الكامل
                            </label>
                            <div className="relative group">
                                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                                    <User className="h-5 w-5 text-gray-500 group-focus-within:text-secondary transition-colors" />
                                </div>
                                <input
                                    id="fullName"
                                    type="text"
                                    required
                                    placeholder="الاسم الثلاثي"
                                    {...register("fullName", { required: true })}
                                    className="block w-full rounded-xl border-0 bg-white/5 py-3.5 pr-10 pl-4 text-white shadow-sm ring-1 ring-inset ring-white/10 placeholder:text-gray-500 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 transition-all hover:bg-white/10 focus:bg-white/10"
                                />
                            </div>
                            {errors.fullName && <span className="text-xs text-red-400 mt-1 block">هذا الحقل مطلوب</span>}
                        </div>

                        <div>
                            <label htmlFor="phone" className="block text-sm font-medium text-gray-300 mb-2">
                                رقم الهاتف (مع الرمز الدولي)
                            </label>
                            <div className="relative group">
                                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                                    <Phone className="h-5 w-5 text-gray-500 group-focus-within:text-secondary transition-colors" />
                                </div>
                                <input
                                    id="phone"
                                    type="tel"
                                    required
                                    placeholder="+90 555 000 0000"
                                    {...register("phone", { required: true })}
                                    className="block w-full rounded-xl border-0 bg-white/5 py-3.5 pr-10 pl-4 text-white shadow-sm ring-1 ring-inset ring-white/10 placeholder:text-gray-500 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 transition-all hover:bg-white/10 focus:bg-white/10 text-left"
                                    dir="ltr"
                                />
                            </div>
                            {errors.phone && <span className="text-xs text-red-400 mt-1 block">هذا الحقل مطلوب</span>}
                        </div>

                        <div>
                            <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                                البريد الإلكتروني (اختياري)
                            </label>
                            <div className="relative group">
                                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                                    <Mail className="h-5 w-5 text-gray-500 group-focus-within:text-secondary transition-colors" />
                                </div>
                                <input
                                    id="email"
                                    type="email"
                                    placeholder="example@email.com"
                                    {...register("email")}
                                    className="block w-full rounded-xl border-0 bg-white/5 py-3.5 pr-10 pl-4 text-white shadow-sm ring-1 ring-inset ring-white/10 placeholder:text-gray-500 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 transition-all hover:bg-white/10 focus:bg-white/10"
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <div>
                                <label htmlFor="nationality" className="block text-sm font-medium text-gray-300 mb-2">
                                    الجنسية
                                </label>
                                <div className="relative group">
                                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                                        <Globe className="h-5 w-5 text-gray-500 group-focus-within:text-secondary transition-colors" />
                                    </div>
                                    <input
                                        id="nationality"
                                        type="text"
                                        placeholder="جنسيتك"
                                        {...register("nationality")}
                                        className="block w-full rounded-xl border-0 bg-white/5 py-3.5 pr-10 pl-4 text-white shadow-sm ring-1 ring-inset ring-white/10 placeholder:text-gray-500 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 transition-all hover:bg-white/10 focus:bg-white/10"
                                    />
                                </div>
                            </div>
                            <div>
                                <label htmlFor="gpa" className="block text-sm font-medium text-gray-300 mb-2">
                                    المعدل الدراسي
                                </label>
                                <div className="relative group">
                                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                                        <FileText className="h-5 w-5 text-gray-500 group-focus-within:text-secondary transition-colors" />
                                    </div>
                                    <input
                                        id="gpa"
                                        type="text"
                                        placeholder="مثلاً: 95%"
                                        {...register("gpa")}
                                        className="block w-full rounded-xl border-0 bg-white/5 py-3.5 pr-10 pl-4 text-white shadow-sm ring-1 ring-inset ring-white/10 placeholder:text-gray-500 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 transition-all hover:bg-white/10 focus:bg-white/10"
                                    />
                                </div>
                            </div>
                        </div>

                        <div>
                            <label htmlFor="certificateType" className="block text-sm font-medium text-gray-300 mb-2">
                                نــوع الشــهادة
                            </label>
                            <div className="relative">
                                <select
                                    id="certificateType"
                                    {...register("certificateType")}
                                    className="block w-full rounded-xl border-0 bg-white/5 py-3.5 pl-4 pr-10 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 transition-all hover:bg-white/10 focus:bg-white/10 [&>option]:text-gray-900"
                                >
                                    <option value="">اختر الشهادة...</option>
                                    <option value="ثانوي عام">ثانوي عام</option>
                                    <option value="أزهري">أزهري</option>
                                    <option value="يوس">يوس (YÖS)</option>
                                    <option value="SAT">SAT</option>
                                    <option value="أخرى">أخرى</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label htmlFor="desiredMajor" className="block text-sm font-medium text-gray-300 mb-2">
                                التخصص المرغوب
                            </label>
                            <div className="relative group">
                                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                                    <BookOpen className="h-5 w-5 text-gray-500 group-focus-within:text-secondary transition-colors" />
                                </div>
                                <input
                                    id="desiredMajor"
                                    type="text"
                                    placeholder="مثلاً: طب بشري، هندسة..."
                                    {...register("desiredMajor")}
                                    className="block w-full rounded-xl border-0 bg-white/5 py-3.5 pr-10 pl-4 text-white shadow-sm ring-1 ring-inset ring-white/10 placeholder:text-gray-500 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 transition-all hover:bg-white/10 focus:bg-white/10"
                                    required
                                />
                            </div>
                        </div>

                        <div>
                            <label htmlFor="universityType" className="block text-sm font-medium text-gray-300 mb-2">
                                نــوع الجــامعة المفضل
                            </label>
                            <div className="relative">
                                <select
                                    id="universityType"
                                    {...register("universityType")}
                                    className="block w-full rounded-xl border-0 bg-white/5 py-3.5 pl-4 pr-10 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 transition-all hover:bg-white/10 focus:bg-white/10 [&>option]:text-gray-900"
                                >
                                    <option value="">اختر النوع...</option>
                                    <option value="حكومية">حكومية</option>
                                    <option value="خاصة">خاصة</option>
                                    <option value="كلاهما">كلاهما</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label htmlFor="notes" className="block text-sm font-medium text-gray-300 mb-2">
                                ملاحظات إضافية
                            </label>
                            <div className="mt-1">
                                <textarea
                                    id="notes"
                                    rows={3}
                                    placeholder="أي تفاصيل أخرى تود إخبارنا بها..."
                                    {...register("notes")}
                                    className="block w-full rounded-xl border-0 bg-white/5 py-3.5 text-white shadow-sm ring-1 ring-inset ring-white/10 placeholder:text-gray-500 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 transition-all hover:bg-white/10 focus:bg-white/10 resize-none px-4"
                                />
                            </div>
                        </div>

                        <div className="pt-4">
                            <button
                                type="submit"
                                disabled={isSubmitting}
                                className="w-full flex justify-center items-center gap-2 py-4 px-4 border border-transparent rounded-xl shadow-lg text-lg font-bold text-white bg-secondary hover:bg-secondary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary disabled:opacity-70 disabled:cursor-not-allowed transition-all transform hover:scale-[1.02] active:scale-[0.98]"
                            >
                                {isSubmitting ? (
                                    <>
                                        <div className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                        جاري الإرسال...
                                    </>
                                ) : (
                                    "تسجيل الطلب الآن"
                                )}
                            </button>
                        </div>
                    </form>
                </FadeIn>
            </div>
        </div>
    );
}

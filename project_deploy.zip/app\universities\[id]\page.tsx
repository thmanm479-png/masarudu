import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { Building2, GraduationCap, MapPin, Globe, BookOpen, CheckCircle, ArrowRight } from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { Metadata } from "next";

export const dynamic = "force-dynamic";

async function getUniversity(id: number) {
    try {
        const university = await prisma.university.findUnique({
            where: { id },
        });
        return university;
    } catch (error) {
        return null;
    }
}

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
    const university = await getUniversity(parseInt(params.id));

    if (!university) {
        return {
            title: "الجامعة غير موجودة",
        };
    }

    return {
        title: `${university.name} | مسار للخدمات التعليمية`,
        description: (university.description || "").substring(0, 160),
    };
}

export default async function UniversityDetailsPage({ params }: { params: { id: string } }) {
    const university = await getUniversity(parseInt(params.id));

    if (!university) {
        notFound();
    }

    return (
        <div className="min-h-screen bg-gray-50 pb-20">
            {/* Header / Hero */}
            <div className="bg-white border-b border-gray-100">
                <div className="max-w-7xl mx-auto px-6 lg:px-8 py-12">
                    <Link href="/#universities" className="inline-flex items-center gap-2 text-gray-500 hover:text-secondary mb-8 transition-colors">
                        <ArrowRight className="h-4 w-4" />
                        <span>عودة إلى القائمة</span>
                    </Link>

                    <div className="flex flex-col lg:flex-row items-start gap-8">
                        {/* Icon / Logo Placeholder */}
                        <div className={cn("p-6 rounded-3xl", university.type === "Government" ? "bg-primary/10 text-primary" : "bg-secondary/10 text-secondary")}>
                            {university.type === "Government" ? <Building2 className="h-16 w-16" /> : <GraduationCap className="h-16 w-16" />}
                        </div>

                        <div className="flex-1">
                            <div className="flex flex-wrap items-center gap-3 mb-4">
                                <span className={cn("px-3 py-1 rounded-full text-xs font-bold", university.type === "Government" ? "bg-primary/10 text-primary" : "bg-secondary/10 text-secondary")}>
                                    {university.type === "Government" ? "جامعة حكومية" : "جامعة خاصة"}
                                </span>
                                <span className="flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-gray-100 text-gray-600">
                                    <MapPin className="h-3 w-3" />
                                    {university.city}
                                </span>
                                {university.language && (
                                    <span className="flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-600">
                                        <Globe className="h-3 w-3" />
                                        {university.language}
                                    </span>
                                )}
                            </div>

                            <h1 className="text-4xl font-bold text-gray-900 mb-6">{university.name}</h1>
                            <p className="text-lg text-gray-600 leading-relaxed max-w-4xl">
                                {university.description}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="max-w-7xl mx-auto px-6 lg:px-8 py-12">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Main Content */}
                    <div className="lg:col-span-2 space-y-8">
                        {/* Admission Requirements */}
                        <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
                            <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
                                <CheckCircle className="h-6 w-6 text-secondary" />
                                شروط القبول والتسجيل
                            </h2>
                            <div className="prose prose-lg text-gray-600 max-w-none">
                                {university.admissionReqs ? (
                                    <div className="whitespace-pre-line leading-relaxed">
                                        {university.admissionReqs}
                                    </div>
                                ) : (
                                    <p className="text-gray-400 italic">لا توجد شروط محددة حالياً.</p>
                                )}
                            </div>
                        </div>

                        {/* CTA */}
                        <div className="bg-primary rounded-3xl p-8 text-white relative overflow-hidden">
                            <div className="absolute top-0 left-0 w-full h-full bg-[url('/pattern.png')] opacity-10" />
                            <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-6">
                                <div>
                                    <h3 className="text-2xl font-bold mb-2">هل ترغب بالدراسة في هذه الجامعة؟</h3>
                                    <p className="text-blue-100">سجل الآن وسنقوم بتأمين قبولك بأسرع وقت.</p>
                                </div>
                                <Link
                                    href="/#contact"
                                    className="bg-secondary text-primary-dark px-8 py-4 rounded-xl font-bold hover:bg-white hover:text-primary transition-colors shadow-lg"
                                >
                                    سجل الآن
                                </Link>
                            </div>
                        </div>
                    </div>

                    {/* Sidebar */}
                    <div className="space-y-6">
                        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 sticky top-24">
                            <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                                <BookOpen className="h-5 w-5 text-gray-400" />
                                روابط سريعة
                            </h3>
                            <ul className="space-y-3">
                                <li>
                                    <Link href="/#contact" className="block p-3 rounded-xl bg-gray-50 hover:bg-secondary/10 hover:text-secondary transition-colors text-sm font-medium">
                                        تواصل معنا للتسجيل
                                    </Link>
                                </li>
                                <li>
                                    <Link href="/partners" className="block p-3 rounded-xl bg-gray-50 hover:bg-secondary/10 hover:text-secondary transition-colors text-sm font-medium">
                                        شركاؤنا
                                    </Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

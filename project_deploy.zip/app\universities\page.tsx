import Link from "next/link";
import { prisma } from "@/lib/prisma";
import FadeIn from "@/components/FadeIn";

async function getUniversities() {
    try {
        return await prisma.university.findMany({
            orderBy: { name: 'asc' }
        });
    } catch (error) {
        return [];
    }
}

export default async function UniversitiesPage() {
    const universities = await getUniversities();

    return (
        <div className="min-h-screen pt-24 pb-12 bg-gray-50 direction-rtl" dir="rtl">
            <div className="container mx-auto px-4">
                <FadeIn>
                    <div className="text-center mb-12">
                        <h1 className="text-3xl font-bold text-gray-900 mb-4">الجامعات التركية</h1>
                        <p className="text-gray-600 max-w-2xl mx-auto">
                            تصفح قائمة الجامعات المتميزة التي نتعاون معها لتحقيق حلمك الدراسي
                        </p>
                    </div>
                </FadeIn>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {universities.length > 0 ? (
                        universities.map((uni) => (
                            <FadeIn key={uni.id}>
                                <Link
                                    href={`/universities/${uni.id}`}
                                    className="block bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300"
                                >
                                    <div className="h-48 bg-gray-200 relative">
                                        {/* Placeholder for image */}
                                        <div className="absolute inset-0 flex items-center justify-center text-gray-400">
                                            <span className="text-4xl">🎓</span>
                                        </div>
                                    </div>
                                    <div className="p-6">
                                        <h3 className="text-xl font-bold text-gray-900 mb-2">{uni.name}</h3>
                                        <div className="space-y-2 text-gray-600 text-sm">
                                            <p>📍 {uni.city}</p>
                                            <p>🏫 {uni.type}</p>
                                        </div>
                                    </div>
                                </Link>
                            </FadeIn>
                        ))
                    ) : (
                        <div className="col-span-full text-center py-12">
                            <p className="text-gray-500">لا توجد جامعات مضافة حالياً</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

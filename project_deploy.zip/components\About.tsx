import { Star, Quote } from "lucide-react";

export default function About() {
    return (
        <div id="about" className="bg-white py-24 sm:py-32">
            <div className="mx-auto max-w-7xl px-6 lg:px-8">
                <div className="grid grid-cols-1 gap-x-8 gap-y-16 lg:grid-cols-2 lg:items-start">
                    {/* About Text */}
                    <div>
                        <h2 className="text-base font-semibold leading-7 text-secondary">من نحن</h2>
                        <p className="mt-2 text-3xl font-bold tracking-tight text-primary sm:text-4xl">
                            مسار للخدمات التعليمية
                        </p>
                        <div className="mt-6 space-y-6 text-lg leading-8 text-gray-600">
                            <p>
                                نحن مؤسسة تعليمية متخصصة في تأمين القبولات الجامعية في تركيا. نهدف إلى تذليل العقبات أمام الطالب العربي وتوفير أفضل الفرص التعليمية بما يتناسب مع طموحاته وإمكانياته.
                            </p>
                            <div className="border-r-4 border-secondary pr-4">
                                <h3 className="font-bold text-gray-900">رؤيتنا</h3>
                                <p>أن نكون الخيار الأول والموثوق لكل طالب يطمح للدراسة في تركيا.</p>
                            </div>
                            <div className="border-r-4 border-secondary pr-4">
                                <h3 className="font-bold text-gray-900">لماذا تختار مسار؟</h3>
                                <ul className="list-disc list-inside space-y-1 marker:text-secondary">
                                    <li>شفافية ومصداقية في التعامل.</li>
                                    <li>خبرة طويلة في الميدان التعليمي التركي.</li>
                                    <li>متابعة مستمرة حتى ما بعد التسجيل.</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    {/* Reviews / Image */}
                    <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100">
                        <h3 className="text-2xl font-bold text-gray-900 mb-6">ماذا يقول طلابنا؟</h3>
                        <div className="space-y-6">
                            <div className="bg-white p-6 rounded-xl shadow-sm">
                                <div className="flex gap-1 text-yellow-400 mb-2">
                                    {[1, 2, 3, 4, 5].map(i => <Star key={i} className="h-4 w-4 fill-current" />)}
                                </div>
                                <p className="text-gray-600 italic mb-4">&quot;خدمة ممتازة وفريق عمل متعاون جداً. ساعدوني في الحصول على قبول الطب البشري في جامعة اسطنبول.&quot;</p>
                                <div className="flex items-center gap-3">
                                    <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 font-bold">أ</div>
                                    <div>
                                        <p className="font-semibold text-gray-900">أحمد محمد</p>
                                        <p className="text-xs text-gray-500">طالب طب بشري</p>
                                    </div>
                                </div>
                            </div>
                            <div className="bg-white p-6 rounded-xl shadow-sm">
                                <div className="flex gap-1 text-yellow-400 mb-2">
                                    {[1, 2, 3, 4, 5].map(i => <Star key={i} className="h-4 w-4 fill-current" />)}
                                </div>
                                <p className="text-gray-600 italic mb-4">&quot;شكراً جزيلاً لمكتب مسار على الاهتمام والمتابعة الدقيقة لملفي.&quot;</p>
                                <div className="flex items-center gap-3">
                                    <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 font-bold">س</div>
                                    <div>
                                        <p className="font-semibold text-gray-900">سارة علي</p>
                                        <p className="text-xs text-gray-500">طالبة هندسة</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

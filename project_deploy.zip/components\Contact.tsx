"use client";

import { useState } from "react";
import { Phone, Mail, MapPin, Facebook, Send, User, MessageCircle } from "lucide-react";
import FadeIn from "./FadeIn";

export default function Contact() {
    const [formState, setFormState] = useState({
        name: "",
        email: "",
        phone: "",
        message: ""
    });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSent, setIsSent] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);

        try {
            const response = await fetch("/api/contact", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(formState),
            });

            if (!response.ok) {
                throw new Error("Failed to send message");
            }

            setIsSent(true);
            setFormState({ name: "", email: "", phone: "", message: "" });
            setTimeout(() => setIsSent(false), 5000);
        } catch (error) {
            console.error(error);
            alert("تعذر إرسال الرسالة. يرجى المحاولة مرة أخرى.");
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormState(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    return (
        <div id="contact" className="relative isolate bg-gray-900 py-24 sm:py-32 overflow-hidden">
            {/* Background effects */}
            <div className="absolute top-1/2 left-0 -translate-y-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-secondary/10 rounded-full blur-[100px] opacity-50 pointer-events-none" />
            <div className="absolute bottom-0 right-0 translate-x-1/3 translate-y-1/3 w-[600px] h-[600px] bg-primary/20 rounded-full blur-[120px] opacity-40 pointer-events-none" />

            <div className="mx-auto max-w-7xl px-6 lg:px-8 relative z-10">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
                    {/* Contact Info */}
                    <FadeIn delay={0.1}>
                        <div>
                            <h2 className="text-base font-semibold leading-7 text-secondary">تواصل معنا</h2>
                            <p className="mt-2 text-4xl font-bold tracking-tight text-white sm:text-5xl">
                                ابدأ رحلتك التعليمية اليوم
                            </p>
                            <p className="mt-6 text-lg leading-8 text-gray-300">
                                فريق مسار جاهز للإجابة على جميع استفساراتكم. سواء كنت بحاجة إلى استشارة حول الجامعات أو المساعدة في التسجيل، نحن هنا لخدمتك.
                            </p>

                            <dl className="mt-12 space-y-8 text-base leading-7 text-gray-300">
                                <div className="flex gap-4 items-center group">
                                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white/5 ring-1 ring-white/10 group-hover:bg-secondary/10 group-hover:ring-secondary/50 transition-all duration-300">
                                        <Phone className="h-6 w-6 text-secondary" aria-hidden="true" />
                                    </div>
                                    <div>
                                        <dt className="sr-only">رقم الهاتف</dt>
                                        <dd className="font-semibold text-white">اتصل بنا</dd>
                                        <dd><a href="tel:+905054954299" className="hover:text-secondary transition-colors" dir="ltr">+90 505 495 42 99</a></dd>
                                    </div>
                                </div>
                                <div className="flex gap-4 items-center group">
                                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white/5 ring-1 ring-white/10 group-hover:bg-secondary/10 group-hover:ring-secondary/50 transition-all duration-300">
                                        <Mail className="h-6 w-6 text-secondary" aria-hidden="true" />
                                    </div>
                                    <div>
                                        <dt className="sr-only">البريد الإلكتروني</dt>
                                        <dd className="font-semibold text-white">البريد الإلكتروني</dd>
                                        <dd><a href="mailto:masareducation2@gmail.com" className="hover:text-secondary transition-colors">masareducation2@gmail.com</a></dd>
                                    </div>
                                </div>
                                <div className="flex gap-4 items-center group">
                                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white/5 ring-1 ring-white/10 group-hover:bg-secondary/10 group-hover:ring-secondary/50 transition-all duration-300">
                                        <Facebook className="h-6 w-6 text-secondary" aria-hidden="true" />
                                    </div>
                                    <div>
                                        <dt className="sr-only">فيسبوك</dt>
                                        <dd className="font-semibold text-white">تابعنا على فيسبوك</dd>
                                        <dd><a href="https://www.facebook.com/share/184pRg9jxs/" target="_blank" className="hover:text-secondary transition-colors">Masar Education</a></dd>
                                    </div>
                                </div>
                            </dl>
                        </div>
                    </FadeIn>

                    {/* Contact Form */}
                    <FadeIn delay={0.3} className="bg-white/5 rounded-3xl ring-1 ring-white/10 p-8 sm:p-10 backdrop-blur-sm">
                        <h3 className="text-2xl font-bold tracking-tight text-white mb-8 flex items-center gap-3">
                            <MessageCircle className="h-6 w-6 text-secondary" />
                            أرسل لنا استفسارك
                        </h3>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium leading-6 text-white">
                                    الاسم الكامل
                                </label>
                                <div className="mt-2 relative">
                                    <input
                                        type="text"
                                        name="name"
                                        id="name"
                                        required
                                        value={formState.name}
                                        onChange={handleChange}
                                        className="block w-full rounded-xl border-0 bg-white/5 py-3.5 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 pl-4 pr-10 transition-all hover:bg-white/10 focus:bg-white/10 placeholder:text-gray-500"
                                        placeholder="الاسم"
                                    />
                                    <User className="absolute left-3 top-3.5 h-5 w-5 text-gray-500" />
                                </div>
                            </div>
                            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                                <div>
                                    <label htmlFor="phone" className="block text-sm font-medium leading-6 text-white">
                                        رقم الهاتف
                                    </label>
                                    <div className="mt-2">
                                        <input
                                            type="tel"
                                            name="phone"
                                            id="phone"
                                            required
                                            value={formState.phone}
                                            onChange={handleChange}
                                            className="block w-full rounded-xl border-0 bg-white/5 py-3.5 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 px-4 transition-all hover:bg-white/10 focus:bg-white/10 placeholder:text-gray-500 text-left"
                                            placeholder="+905550000000"
                                            dir="ltr"
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label htmlFor="email" className="block text-sm font-medium leading-6 text-white">
                                        البريد الإلكتروني
                                    </label>
                                    <div className="mt-2">
                                        <input
                                            type="email"
                                            name="email"
                                            id="email"
                                            value={formState.email}
                                            onChange={handleChange}
                                            className="block w-full rounded-xl border-0 bg-white/5 py-3.5 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 px-4 transition-all hover:bg-white/10 focus:bg-white/10 placeholder:text-gray-500"
                                            placeholder="example@gmail.com"
                                        />
                                    </div>
                                </div>
                            </div>
                            <div>
                                <label htmlFor="message" className="block text-sm font-medium leading-6 text-white">
                                    الرسالة
                                </label>
                                <div className="mt-2">
                                    <textarea
                                        name="message"
                                        id="message"
                                        rows={4}
                                        required
                                        value={formState.message}
                                        onChange={handleChange}
                                        className="block w-full rounded-xl border-0 bg-white/5 py-3.5 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-sm sm:leading-6 px-4 transition-all hover:bg-white/10 focus:bg-white/10 placeholder:text-gray-500 resize-none"
                                        placeholder="اكتب استفسارك هنا..."
                                    />
                                </div>
                            </div>
                            <button
                                type="submit"
                                disabled={isSubmitting || isSent}
                                className="flex w-full items-center justify-center rounded-xl bg-secondary px-3.5 py-3.5 text-base font-bold text-white shadow-sm hover:bg-secondary-dark focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-all hover:scale-[1.02] active:scale-[0.98]"
                            >
                                {isSubmitting ? (
                                    <span className="flex items-center gap-2">
                                        <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                        </svg>
                                        جاري الإرسال...
                                    </span>
                                ) : isSent ? (
                                    <span className="flex items-center gap-2 text-white">
                                        تم الإرسال بنجاح!
                                    </span>
                                ) : (
                                    <span className="flex items-center gap-2">
                                        إرسال الرسالة <Send className="h-4 w-4" />
                                    </span>
                                )}
                            </button>
                        </form>
                    </FadeIn>
                </div>
            </div>
        </div>
    );
}

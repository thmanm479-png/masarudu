import { FileText, User, Stamp, Image as ImageIcon } from "lucide-react";

const documents = [
    { icon: FileText, text: "شهادة الثانوية العامة (مترجمة ومصدقة)" },
    { icon: FileText, text: "كشف الدرجات (مترجم ومصدق)" },
    { icon: Stamp, text: "جواز السفر (ساري المفعول)" },
    { icon: ImageIcon, text: "صور شخصية بيومترية" },
    //   { icon: User, text: "رسالة توصية (للماجستير والدكتوراه)" },
];

export default function Documents() {
    return (
        <div className="bg-primary py-24 sm:py-32">
            <div className="mx-auto max-w-7xl px-6 lg:px-8">
                <div className="mx-auto max-w-2xl lg:text-center">
                    <h2 className="text-base font-semibold leading-7 text-secondary">الأوراق المطلوبة</h2>
                    <p className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
                        حضّر ملفك للتقديم
                    </p>
                    <p className="mt-6 text-lg leading-8 text-gray-300">
                        لضمان عملية تقديم سلسة، يرجى تجهيز المستندات التالية بجودة عالية (Scan).
                    </p>
                </div>
                <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl">
                    <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-10 lg:max-w-none lg:grid-cols-2 lg:gap-y-16">
                        {documents.map((doc, index) => (
                            <div key={index} className="relative">
                                <dt className="text-lg font-semibold leading-7 text-white text-right pr-14 flex items-center h-full">
                                    <div className="absolute top-0 right-0 flex h-10 w-10 items-center justify-center rounded-lg bg-secondary/20 ring-1 ring-secondary/50">
                                        <doc.icon className="h-6 w-6 text-secondary" aria-hidden="true" />
                                    </div>
                                    {doc.text}
                                </dt>
                            </div>
                        ))}
                    </dl>
                </div>
            </div>
        </div>
    );
}

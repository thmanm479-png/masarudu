"use client";

import { useState } from "react";
import { ChevronDown, ChevronUp, HelpCircle } from "lucide-react";
import { cn } from "@/lib/utils";

const faqs = [
    {
        question: "هل القبول الجامعي مضمون؟",
        answer: "في الجامعات الخاصة، القبول مضمون بنسبة كبيرة جداً. أما في الجامعات الحكومية، فنحن نعمل بجهد كبير لزيادة فرص قبولك من خلال التقديم الصحيح واختيار الجامعات المناسبة لمؤهلاتك."
    },
    {
        question: "هل أحتاج شهادة يوس لتقديم الطلب؟",
        answer: "للجامعات الخاصة لا يطلب شهادة يوس غالباً، تكفي الشهادة الثانوية. أما الجامعات الحكومية القوية، فمعظمها يشترط وجود شهادة يوس (سواء يوس موحد أو خاص بالجامعة) للمنافسة على المقاعد."
    },
    {
        question: "ما الفرق بين الجامعات الحكومية والخاصة؟",
        answer: "الجامعات الحكومية رسومها الدراسية منخفضة ولكن المنافسة فيها عالية وتشترط اختبارات قبول غالباً. الجامعات الخاصة رسومها أعلى ولكن القبول فيها أسهل وتوفر لغات دراسة متعددة وتجهيزات حديثة."
    },
    {
        question: "متى تبدأ مواعيد التقديم للجامعات؟",
        answer: "يبدأ التقديم للجامعات الخاصة عادة من الشهر الرابع ويستمر حتى الشهر العاشر. أما الجامعات الحكومية فلها تقويم خاص يختلف من جامعة لأخرى، وغالباً تبدأ المفاضلات في الشهر الخامس."
    },
    {
        question: "هل الشهادة التركية معترف بها عالمياً؟",
        answer: "نعم، الجامعات التركية معترف بها في معظم دول العالم وضمن نظام التعليم الأوروبي (Bologna Process)، ولها تصنيفات عالمية جيدة."
    },
];

export default function FAQ() {
    const [openIndex, setOpenIndex] = useState<number | null>(null);

    const toggleFAQ = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    return (
        <div id="faq" className="bg-white py-24 sm:py-32">
            <div className="mx-auto max-w-7xl px-6 lg:px-8">
                <div className="mx-auto max-w-2xl text-center mb-16">
                    <h2 className="text-base font-semibold leading-7 text-secondary">الأسئلة الشائعة</h2>
                    <p className="mt-2 text-3xl font-bold tracking-tight text-primary sm:text-4xl">
                        إجابات لأهم استفساراتكم
                    </p>
                </div>
                <div className="mx-auto max-w-4xl divide-y divide-gray-900/10">
                    {faqs.map((faq, index) => (
                        <div key={index} className="py-6">
                            <button
                                onClick={() => toggleFAQ(index)}
                                className="flex w-full items-start justify-between text-right text-gray-900"
                            >
                                <span className="text-base font-semibold leading-7 flex items-center gap-2">
                                    <HelpCircle className="h-5 w-5 text-secondary" />
                                    {faq.question}
                                </span>
                                <span className="ml-6 flex h-7 items-center">
                                    {openIndex === index ? (
                                        <ChevronUp className="h-6 w-6 text-primary" aria-hidden="true" />
                                    ) : (
                                        <ChevronDown className="h-6 w-6 text-gray-400" aria-hidden="true" />
                                    )}
                                </span>
                            </button>
                            <div
                                className={cn(
                                    "mt-2 pr-12 text-base leading-7 text-gray-600 overflow-hidden transition-all duration-300",
                                    openIndex === index ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
                                )}
                            >
                                <p>{faq.answer}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

"use client";

import { useState, useEffect } from "react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { Rocket, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function FloatingAgentButton() {
    const pathname = usePathname();
    const [isVisible, setIsVisible] = useState(false);
    const [isDismissed, setIsDismissed] = useState(false);

    // Hide on admin, dashboard, and registration pages


    useEffect(() => {
        const handleScroll = () => {
            // Show button after scrolling 300px
            if (window.scrollY > 300) {
                setIsVisible(true);
            } else {
                setIsVisible(false);
            }
        };

        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    if (
        pathname.startsWith("/admin") ||
        pathname.startsWith("/agent-dashboard") ||
        pathname === "/agent-register" ||
        pathname === "/agent-login"
    ) {
        return null;
    }

    if (isDismissed) {
        return null;
    }

    return (
        <AnimatePresence>
            {isVisible && (
                <motion.div
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0, opacity: 0 }}
                    transition={{ type: "spring", stiffness: 260, damping: 20 }}
                    className="fixed bottom-6 right-6 z-50 lg:hidden"
                >
                    {/* Dismiss button */}
                    <button
                        onClick={() => setIsDismissed(true)}
                        className="absolute -top-2 -left-2 w-6 h-6 bg-gray-800 text-white rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors shadow-lg z-10"
                        aria-label="إخفاء الزر"
                    >
                        <X className="h-3 w-3" />
                    </button>

                    {/* Main button */}
                    <Link
                        href="/agent-register"
                        className="flex items-center gap-3 bg-secondary text-white px-6 py-4 rounded-full shadow-2xl shadow-secondary/40 hover:shadow-secondary/60 hover:bg-secondary-dark transition-all transform hover:scale-105 active:scale-95"
                    >
                        <Rocket className="h-5 w-5" />
                        <span className="font-bold text-sm">سجّل كوكيل</span>
                    </Link>

                    {/* Pulsing ring effect */}
                    <div className="absolute inset-0 rounded-full bg-secondary/30 animate-ping -z-10" />
                </motion.div>
            )}
        </AnimatePresence>
    );
}

"use client";

import { MessageCircle } from "lucide-react";
import { usePathname } from "next/navigation";

export default function FloatingWhatsapp() {
    const pathname = usePathname();

    if (pathname.startsWith("/admin") || pathname.startsWith("/agent-dashboard")) {
        return null;
    }
    return (
        <a
            href="https://wa.me/905054954299"
            target="_blank"
            rel="noopener noreferrer"
            className="fixed bottom-6 left-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:bg-[#20bd5a] transition-all hover:scale-110 animate-bounce"
            aria-label="Chat on WhatsApp"
        >
            <MessageCircle className="h-8 w-8" />
        </a>
    );
}

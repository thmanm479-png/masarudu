"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Facebook, Mail, Phone } from "lucide-react";
import Logo from "./Logo";

export default function Footer() {
    const pathname = usePathname();

    const [year, setYear] = useState(new Date().getFullYear());

    useEffect(() => {
        setYear(new Date().getFullYear());
    }, []);

    if (pathname.startsWith("/admin") || pathname.startsWith("/agent-dashboard")) {
        return null;
    }
    return (
        <footer className="bg-primary text-white" aria-labelledby="footer-heading">
            <h2 id="footer-heading" className="sr-only">
                تذييل الصفحة
            </h2>
            <div className="mx-auto max-w-7xl px-6 pb-8 pt-16 sm:pt-24 lg:px-8 lg:pt-32">
                <div className="xl:grid xl:grid-cols-4 xl:gap-8">
                    <div className="space-y-8 xl:col-span-1 text-center md:text-right">
                        <div className="flex items-center justify-center md:justify-start gap-2">
                            <Logo className="h-12" />
                        </div>
                        <p className="text-sm leading-6 text-gray-300 max-w-xs mx-auto md:mx-0">
                            نرافقك في مسارك للدراسة في الجامعات التركية بثقة واحترافية.
                        </p>
                        <div className="flex justify-center md:justify-start gap-x-6">
                            <a href="https://www.facebook.com/share/184pRg9jxs/" target="_blank" className="text-gray-400 hover:text-white transition-colors">
                                <span className="sr-only">Facebook</span>
                                <Facebook className="h-6 w-6" aria-hidden="true" />
                            </a>
                            <a href="mailto:masareducation2@gmail.com" className="text-gray-400 hover:text-white transition-colors">
                                <span className="sr-only">Email</span>
                                <Mail className="h-6 w-6" aria-hidden="true" />
                            </a>
                            <a href="https://wa.me/905054954299" className="text-gray-400 hover:text-white transition-colors">
                                <span className="sr-only">WhatsApp</span>
                                <Phone className="h-6 w-6" aria-hidden="true" />
                            </a>
                        </div>
                    </div>
                    <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 xl:col-span-3 xl:mt-0">
                        <div className="grid grid-cols-2 gap-8 sm:col-span-2 md:grid-cols-2">
                            <div>
                                <h3 className="text-sm font-semibold leading-6 text-white border-b border-white/10 pb-2 mb-4">
                                    الروابط
                                </h3>
                                <ul role="list" className="space-y-4">
                                    <li>
                                        <Link href="/#about" className="text-sm leading-6 text-gray-300 hover:text-white transition-colors">
                                            من نحن
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/#services" className="text-sm leading-6 text-gray-300 hover:text-white transition-colors">
                                            خدماتنا
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/#universities" className="text-sm leading-6 text-gray-300 hover:text-white transition-colors">
                                            الجامعات
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                            <div>
                                <h3 className="text-sm font-semibold leading-6 text-white border-b border-white/10 pb-2 mb-4">
                                    الدعم
                                </h3>
                                <ul role="list" className="space-y-4">
                                    <li>
                                        <Link href="/#faq" className="text-sm leading-6 text-gray-300 hover:text-white transition-colors">
                                            الأسئلة الشائعة
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/#contact" className="text-sm leading-6 text-gray-300 hover:text-white transition-colors">
                                            اتصل بنا
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="mt-10 lg:mt-0">
                            <h3 className="text-sm font-semibold leading-6 text-white border-b border-white/10 pb-2 mb-4">
                                النظام
                            </h3>
                            <ul role="list" className="space-y-4">
                                <li>
                                    <Link href="/admin" className="text-sm leading-6 text-gray-300 hover:text-white transition-colors flex items-center gap-2">
                                        <div className="h-1 w-1 bg-secondary rounded-full" />
                                        لوحة تحكم الإدارة
                                    </Link>
                                </li>
                                <li>
                                    <Link href="/agent-dashboard" className="text-sm leading-6 text-gray-300 hover:text-white transition-colors flex items-center gap-2">
                                        <div className="h-1 w-1 bg-secondary rounded-full" />
                                        لوحة تحكم الوكلاء
                                    </Link>
                                </li>
                                <li className="pt-2">
                                    <Link href="/agent-register" className="inline-block rounded-lg bg-secondary/10 px-4 py-2 text-sm font-bold text-secondary ring-1 ring-inset ring-secondary/20 hover:bg-secondary/20 transition-all">
                                        سجّل كوكيل
                                    </Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div className="mt-16 border-t border-white/10 pt-8 sm:mt-20 lg:mt-24 text-center md:text-right">
                    <p className="text-xs leading-5 text-gray-400">
                        &copy; {year} مسار للخدمات التعليمية. جميع الحقوق محفوظة.
                    </p>
                </div>
            </div>
        </footer>
    );
}

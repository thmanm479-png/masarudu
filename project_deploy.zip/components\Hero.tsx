"use client";

import Link from "next/link";
import Image from "next/image";
import { ArrowLeft, CheckCircle, Rocket } from "lucide-react";
import { motion } from "framer-motion";

export default function Hero({ content }: { content: any }) {
    const title = content?.hero_title || "نرافقك في مسارك نحو التميز الأكاديمي في تركيا";
    const subtitle = content?.hero_subtitle || "نقدم لك استشارات تعليمية شاملة، من اختيار الجامعة المناسبة وحتى التسجيل والسكن. فريقنا المتخصص يضمن لك قبولاً مضموناً وبداية موفقة في أقوى الجامعات التركية.";

    return (
        <div className="relative isolate overflow-hidden bg-primary min-h-[calc(100vh-80px)] flex items-center justify-center py-20 sm:py-0">
            {/* Background Image with Enhanced Overlays */}
            <div className="absolute inset-0 -z-10">
                <Image
                    src="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?q=80&w=2670&auto=format&fit=crop"
                    alt="University Campus in Turkey"
                    fill
                    className="object-cover object-center brightness-[0.4] scale-105"
                    priority
                />
                <div className="absolute inset-0 bg-gradient-to-b from-primary/80 via-primary/40 to-primary" />
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-secondary/10 via-transparent to-transparent" />
            </div>

            {/* Decorative Floating Elements */}
            <div className="absolute inset-0 -z-5 overflow-hidden pointer-events-none">
                <motion.div
                    animate={{
                        y: [0, -20, 0],
                        rotate: [0, 5, 0]
                    }}
                    transition={{
                        duration: 6,
                        repeat: Infinity,
                        ease: "easeInOut"
                    }}
                    className="absolute top-[20%] right-[10%] w-64 h-64 bg-secondary/10 rounded-full blur-3xl opacity-50"
                />
                <motion.div
                    animate={{
                        y: [0, 20, 0],
                        rotate: [0, -5, 0]
                    }}
                    transition={{
                        duration: 8,
                        repeat: Infinity,
                        ease: "easeInOut"
                    }}
                    className="absolute bottom-[20%] left-[10%] w-80 h-80 bg-primary-light/20 rounded-full blur-3xl opacity-50"
                />
            </div>

            <div className="mx-auto max-w-7xl px-6 lg:px-8 relative z-10 w-full mt-4 sm:mt-0">
                <div className="mx-auto max-w-3xl text-center">
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                        className="mb-6 sm:mb-8 flex justify-center"
                    >
                        <div className="inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs sm:text-sm font-medium leading-6 text-secondary ring-1 ring-secondary/30 bg-secondary/10 backdrop-blur-md transition-all duration-300 hover:bg-secondary/20">
                            <span className="relative flex h-2 w-2">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-secondary opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-secondary"></span>
                            </span>
                            ابدأ رحلتك الجامعية الآن
                            <Link href="#contact" className="font-bold flex items-center gap-1">
                                <span className="absolute inset-0" aria-hidden="true" />
                                تواصل معنا <ArrowLeft className="h-3 w-3" />
                            </Link>
                        </div>
                    </motion.div>

                    <motion.h1
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
                        className="text-3xl font-extrabold tracking-tight text-white sm:text-7xl font-sans drop-shadow-2xl leading-[1.2]"
                    >
                        {title.split(' ').map((word: string, i: number) => (
                            <span key={i} className={word === 'التميز' || word === 'تركيا' ? 'text-secondary' : ''}>
                                {word}{' '}
                            </span>
                        ))}
                    </motion.h1>

                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.4 }}
                        className="mt-8 text-xl leading-9 text-gray-200 font-medium max-w-2xl mx-auto"
                    >
                        {subtitle}
                    </motion.p>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.6 }}
                        className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6"
                    >
                        <Link
                            href="/register"
                            className="w-full sm:w-auto rounded-xl bg-secondary px-10 py-4 text-lg font-bold text-white shadow-[0_0_20px_rgba(212,175,55,0.4)] hover:bg-secondary-dark hover:shadow-[0_0_30px_rgba(212,175,55,0.6)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-secondary transition-all transform hover:scale-105 active:scale-95 duration-200"
                        >
                            سجل للتقديم
                        </Link>
                        <Link href="#services" className="hidden sm:flex text-base font-bold leading-6 text-white items-center gap-2 hover:text-secondary transition-all group p-2">
                            تعرف على خدماتنا
                            <div className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center group-hover:border-secondary group-hover:bg-secondary/10 transition-all">
                                <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
                            </div>
                        </Link>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 1, delay: 1 }}
                        className="mt-20 flex justify-center gap-x-12 gap-y-6 flex-wrap text-sm"
                    >
                        {[
                            { text: "قبولات مضمونة", icon: CheckCircle },
                            { text: "استشارات مجانية", icon: CheckCircle },
                            { text: "دعم متواصل 24/7", icon: CheckCircle }
                        ].map((item, i) => (
                            <div key={i} className="flex items-center gap-3 text-gray-300 bg-white/5 backdrop-blur-sm px-4 py-2 rounded-full border border-white/10">
                                <item.icon className="h-5 w-5 text-secondary" />
                                <span className="font-medium">{item.text}</span>
                            </div>
                        ))}
                    </motion.div>
                </div>
            </div>

            {/* Scroll Indicator */}
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.5, duration: 1 }}
                className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
            >
                <span className="text-white/40 text-[10px] uppercase tracking-widest font-bold">إلى الأسفل</span>
                <div className="w-5 h-8 border-2 border-white/20 rounded-full flex justify-center p-1">
                    <motion.div
                        animate={{ y: [0, 12, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                        className="w-1 h-1 bg-secondary rounded-full"
                    />
                </div>
            </motion.div>
        </div>
    );
}


"use client";

import { motion } from "framer-motion";

interface LogoProps {
    className?: string;
    showText?: boolean;
}

export default function Logo({ className = "h-12", showText = true }: LogoProps) {
    return (
        <motion.div
            className={`flex items-center gap-3 ${className}`}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            whileHover={{ scale: 1.05 }}
        >
            <div className="relative group">
                <svg
                    viewBox="0 0 100 80"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-full w-auto drop-shadow-lg"
                >
                    {/* Definitions for gradients and lighting */}
                    <defs>
                        <linearGradient id="gold-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stopColor="#D4AF37" />
                            <stop offset="50%" stopColor="#F9E076" />
                            <stop offset="100%" stopColor="#AA8C2C" />
                        </linearGradient>
                        <linearGradient id="shine-gradient" x1="-100%" y1="0%" x2="200%" y2="0%">
                            <stop offset="0%" stopColor="white" stopOpacity="0" />
                            <stop offset="50%" stopColor="white" stopOpacity="0.5" />
                            <stop offset="100%" stopColor="white" stopOpacity="0" />
                        </linearGradient>
                    </defs>

                    {/* The Book (Layers) */}
                    <path
                        d="M10 65 Q50 75 90 65 L90 55 Q50 65 10 55 Z"
                        fill="#D4AF37"
                        stroke="#AA8C2C"
                        strokeWidth="0.5"
                    />
                    <path
                        d="M15 60 Q50 68 85 60 L85 52 Q50 60 15 52 Z"
                        fill="white"
                    />
                    <path
                        d="M10 55 Q50 65 90 55 L90 45 Q50 55 10 45 Z"
                        fill="#D4AF37"
                    />
                    <path
                        d="M15 50 Q50 58 85 50 L85 42 Q50 58 15 42 Z"
                        fill="white"
                    />

                    {/* The Cap (Graduation) */}
                    <motion.g
                        animate={{
                            y: [0, -2, 0],
                        }}
                        transition={{
                            duration: 3,
                            repeat: Infinity,
                            ease: "easeInOut"
                        }}
                    >
                        {/* Cap Base */}
                        <path
                            d="M30 40 L50 48 L70 40 L50 32 Z"
                            fill="#0F3D39"
                            stroke="#D4AF37"
                            strokeWidth="1"
                        />
                        {/* Cap Top */}
                        <path
                            d="M20 30 L50 42 L80 30 L50 18 Z"
                            fill="#0F3D39"
                            stroke="#D4AF37"
                            strokeWidth="1.5"
                        />
                        {/* Tassel */}
                        <path
                            d="M50 30 L65 35 L68 45"
                            stroke="#D4AF37"
                            strokeWidth="2"
                            strokeLinecap="round"
                        />
                        <circle cx="68" cy="45" r="2" fill="#D4AF37" />
                    </motion.g>

                    {/* Shine Effect Overlay */}
                    <motion.rect
                        x="0"
                        y="0"
                        width="100"
                        height="80"
                        fill="url(#shine-gradient)"
                        initial={{ x: "-100%" }}
                        animate={{ x: "100%" }}
                        transition={{
                            duration: 2.5,
                            repeat: Infinity,
                            repeatDelay: 3,
                            ease: "linear",
                        }}
                        style={{ mixBlendMode: "overlay" }}
                    />
                </svg>
            </div>

            {showText && (
                <div className="flex flex-col">
                    <motion.span
                        className="text-2xl font-serif tracking-widest font-bold text-primary dark:text-secondary-light"
                        initial={{ x: -10, opacity: 0 }}
                        animate={{ x: 0, opacity: 1 }}
                        transition={{ delay: 0.2 }}
                    >
                        MASAR
                    </motion.span>
                    <motion.span
                        className="text-[10px] uppercase tracking-[0.3em] text-secondary font-semibold -mt-1"
                        initial={{ x: -10, opacity: 0 }}
                        animate={{ x: 0, opacity: 1 }}
                        transition={{ delay: 0.3 }}
                    >
                        Educational Services
                    </motion.span>
                </div>
            )}
        </motion.div>
    );
}

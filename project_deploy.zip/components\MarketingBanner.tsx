'use client';

import { useState, useEffect } from 'react';
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from 'framer-motion';

const messages = [
    "🎓 خصم خاص للتسجيل المبكر - سارع بحجز مقعدك الآن!",
    "✈️ خدمات استقبال من المطار وسكن مؤمن لجميع طلابنا الجدد",
    "🌟 استشارات مجانية طوال الأسبوع - تواصل معنا الآن",
];

export default function MarketingBanner() {
    const pathname = usePathname();
    const [index, setIndex] = useState(0);



    useEffect(() => {
        const timer = setInterval(() => {
            setIndex((prev) => (prev + 1) % messages.length);
        }, 5000);
        return () => clearInterval(timer);
    }, []);

    if (pathname.startsWith("/admin") || pathname.startsWith("/agent-dashboard")) {
        return null;
    }

    return (
        <div className="bg-secondary text-primary-dark font-bold text-sm py-2 overflow-hidden relative z-50">
            <div className="container mx-auto px-4 text-center">
                <AnimatePresence mode="wait">
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        transition={{ duration: 0.5 }}
                    >
                        {messages[index]}
                    </motion.div>
                </AnimatePresence>
            </div>
        </div>
    );
}

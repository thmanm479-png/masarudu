"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X, GraduationCap, ChevronDown, Rocket, LogIn, Crown, Shield } from "lucide-react";
import { cn } from "@/lib/utils";
import Logo from "./Logo";
import { motion, AnimatePresence } from "framer-motion";

const navigation = [
    { name: "الرئيسية", href: "/" },
    { name: "خدماتنا", href: "/#services" },
    { name: "الجامعات", href: "/#universities" },
    { name: "شركاؤنا", href: "/partners" },
    { name: "الأسئلة الشائعة", href: "/#faq" },
    { name: "من نحن", href: "/#about" },
    { name: "اتصل بنا", href: "/#contact" },
];

export default function Navbar() {
    const pathname = usePathname();
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const [scrolled, setScrolled] = useState(false);

    // Hide navbar on admin and dashboard routes
    if (pathname.startsWith("/admin") || pathname.startsWith("/agent-dashboard")) {
        return null;
    }

    return (
        <>
            <header className="bg-white/90 backdrop-blur-md sticky top-0 z-50 shadow-md transition-all duration-300">
                <nav
                    className="mx-auto flex max-w-7xl items-center justify-between p-4 lg:px-8"
                    aria-label="Global"
                >
                    <div className="flex lg:flex-1">
                        <Link href="/" className="-m-1.5 p-1.5">
                            <Logo className="h-10" />
                        </Link>
                    </div>
                    <div className="flex lg:hidden">
                        <button
                            type="button"
                            className="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700"
                            onClick={() => setMobileMenuOpen(true)}
                        >
                            <span className="sr-only">فتح القائمة</span>
                            <Menu className="h-6 w-6" aria-hidden="true" />
                        </button>
                    </div>
                    <div className="hidden lg:flex lg:gap-x-8">
                        {navigation.map((item) => (
                            <Link
                                key={item.name}
                                href={item.href}
                                className="text-sm font-semibold leading-6 text-gray-900 hover:text-secondary transition-colors"
                            >
                                {item.name}
                            </Link>
                        ))}
                    </div>
                    <div className="hidden lg:flex lg:flex-1 lg:justify-end gap-x-6 items-center">
                        <Link href="/agent-login" className="text-sm font-semibold leading-6 text-gray-900 hover:text-primary transition-colors">
                            دخول الوكلاء
                        </Link>
                        <Link href="/admin" className="text-sm font-semibold leading-6 text-gray-900 hover:text-primary transition-colors">
                            لوحة التحكم
                        </Link>
                        <Link
                            href="/agent-register"
                            className="rounded-md bg-secondary px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-secondary-dark focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-secondary"
                        >
                            سجّل كوكيل
                        </Link>
                    </div>
                </nav>
            </header>

            {/* Mobile menu */}
            <AnimatePresence>
                {mobileMenuOpen && (
                    <div className="lg:hidden fixed inset-0 z-[100]" role="dialog" aria-modal="true">
                        {/* Backdrop */}
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="fixed inset-0 bg-black/40 backdrop-blur-sm"
                            onClick={() => setMobileMenuOpen(false)}
                        />

                        {/* Menu Panel */}
                        <motion.div
                            initial={{ x: "100%" }}
                            animate={{ x: 0 }}
                            exit={{ x: "100%" }}
                            transition={{ type: "spring", damping: 25, stiffness: 200 }}
                            className="fixed inset-y-0 right-0 w-[280px] overflow-y-auto bg-white px-6 py-6 shadow-2xl"
                        >
                            <div className="flex items-center justify-between mb-8">
                                <Link href="/" className="-m-1.5 p-1.5" onClick={() => setMobileMenuOpen(false)}>
                                    <Logo className="h-8" />
                                </Link>
                                <button
                                    type="button"
                                    className="p-2 text-gray-700 hover:bg-gray-100 rounded-xl transition-colors"
                                    onClick={() => setMobileMenuOpen(false)}
                                >
                                    <span className="sr-only">إغلاق القائمة</span>
                                    <X className="h-6 w-6" aria-hidden="true" />
                                </button>
                            </div>

                            <div className="space-y-4">
                                <div className="grid gap-2">
                                    {navigation.map((item) => (
                                        <Link
                                            key={item.name}
                                            href={item.href}
                                            className={cn(
                                                "block rounded-xl px-4 py-3 text-base font-bold text-gray-900 hover:bg-gray-50 transition-colors",
                                                pathname === item.href && "text-secondary bg-secondary/5"
                                            )}
                                            onClick={(e) => {
                                                setMobileMenuOpen(false);
                                                // If it's an anchor link on the current page, we need to ensure it scrolls
                                                if (item.href.startsWith("/#") && pathname === "/") {
                                                    // Allow the menu to close before scrolling
                                                    setTimeout(() => {
                                                        const id = item.href.replace("/#", "");
                                                        const element = document.getElementById(id);
                                                        if (element) {
                                                            element.scrollIntoView({ behavior: "smooth" });
                                                        }
                                                    }, 300);
                                                }
                                            }}
                                        >
                                            {item.name}
                                        </Link>
                                    ))}
                                </div>

                                <div className="pt-6 mt-6 border-t border-gray-100 flex flex-col gap-3">
                                    <Link
                                        href="/admin"
                                        className="flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-base font-bold text-gray-900 border border-gray-200 hover:bg-gray-50 transition-colors"
                                        onClick={() => setMobileMenuOpen(false)}
                                    >
                                        <Shield className="h-4 w-4" />
                                        لوحة التحكم
                                    </Link>
                                    <Link
                                        href="/agent-dashboard"
                                        className="flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-base font-bold text-gray-900 border border-gray-200 hover:bg-gray-50 transition-colors"
                                        onClick={() => setMobileMenuOpen(false)}
                                    >
                                        <LogIn className="h-4 w-4" />
                                        لوحة الوكلاء
                                    </Link>
                                    <Link
                                        href="/agent-register"
                                        className="flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-base font-bold bg-secondary text-white shadow-lg shadow-secondary/20 hover:bg-secondary-dark transition-all transform active:scale-95"
                                        onClick={() => setMobileMenuOpen(false)}
                                    >
                                        <Rocket className="h-4 w-4" />
                                        سجّل كوكيل
                                    </Link>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </>
    );
}

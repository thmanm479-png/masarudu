"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { School, Building, Globe, Handshake, ChevronLeft } from "lucide-react";
import FadeIn from "./FadeIn";

const partners = [
    { name: "جامعة توكات", type: "Government", icon: School },
    { name: "جامعة كارابوك", type: "Government", icon: School },
    { name: "جامعة بولو أبانت عزت بايسال", type: "Government", icon: School },
    { name: "جامعة باتمان", type: "Government", icon: School },
    { name: "جامعة بيلجيك شيخ أديبالي", type: "Government", icon: School },
    { name: "جامعة سيواس جمهوريات", type: "Government", icon: School },
    { name: "جامعة غوموش خانة", type: "Government", icon: School },
    { name: "جامعة ساكاريا", type: "Government", icon: School },
    { name: "جامعة كوجالي", type: "Government", icon: School },
    { name: "جامعة دوزجه", type: "Government", icon: School },
];

export default function Partners() {
    return (
        <section id="partners" className="relative bg-white py-24 sm:py-32 overflow-hidden">
            {/* Background elements */}
            <div className="absolute top-0 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl pointer-events-none" />

            <div className="mx-auto max-w-7xl px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                    <div>
                        <FadeIn direction="right">
                            <h2 className="text-base font-bold tracking-wider text-secondary uppercase mb-4 flex items-center gap-2">
                                <Handshake className="h-5 w-5" />
                                شركاء النجاح
                            </h2>
                            <p className="text-4xl font-extrabold tracking-tight text-primary sm:text-5xl mb-8 leading-tight">
                                جسر تواصل آمن مع <span className="text-secondary text-5xl italic font-serif">أفضل</span> الجامعات التركية
                            </p>
                            <p className="text-lg leading-8 text-gray-600 mb-10">
                                نعتز بشراكاتنا الاستراتيجية مع نخبة من الجامعات الحكومية والخاصة المرموقة، مما يتيح لطلابنا الحصول على أولويات في القبول وخصومات حصرية غير متاحة في أي مكان آخر.
                            </p>

                            <div className="flex flex-col gap-4 mb-10">
                                {[
                                    "اتفاقيات حصرية مع أكثر من 50 جامعة.",
                                    "قبولات مباشرة وسريعة بفضل شراكاتنا.",
                                    "دعم متكامل للطالب داخل الحرم الجامعي."
                                ].map((item, i) => (
                                    <div key={i} className="flex items-center gap-3 text-gray-700 font-medium">
                                        <div className="w-5 h-5 rounded-full bg-secondary/20 flex items-center justify-center">
                                            <div className="w-2 h-2 rounded-full bg-secondary" />
                                        </div>
                                        {item}
                                    </div>
                                ))}
                            </div>

                            <Link
                                href="/partners/register"
                                className="inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-4 text-lg font-bold text-white shadow-xl hover:bg-primary-light transition-all transform hover:scale-105"
                            >
                                كن شريكاً معنا
                                <ChevronLeft className="h-5 w-5" />
                            </Link>
                        </FadeIn>
                    </div>

                    <div className="relative">
                        <FadeIn direction="left" className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-4">
                            {partners.map((partner, index) => (
                                <motion.div
                                    key={index}
                                    whileHover={{ y: -5, scale: 1.02 }}
                                    className="bg-gray-50 p-6 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col items-center justify-center text-center group transition-all hover:shadow-premium hover:bg-white"
                                >
                                    <div className="w-14 h-14 rounded-2xl bg-white shadow-sm flex items-center justify-center mb-4 group-hover:bg-primary/5 group-hover:text-primary transition-colors text-gray-400">
                                        <partner.icon className="h-7 w-7" />
                                    </div>
                                    <h3 className="font-bold text-gray-900 group-hover:text-primary transition-colors">{partner.name}</h3>
                                    <span className="text-xs text-secondary font-medium mt-1 uppercase tracking-widest">{partner.type === "Government" ? "حكومية" : "خاصة"}</span>
                                </motion.div>
                            ))}
                        </FadeIn>

                        {/* Decorative floating dots */}
                        <div className="absolute -z-10 -bottom-10 -right-10 w-40 h-40 bg-secondary/10 rounded-full blur-2xl" />
                    </div>
                </div>

            </div>
        </section>
    );
}

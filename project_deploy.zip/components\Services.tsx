import { GraduationCap, FileCheck, Scale, School, BookOpen, Home, Plane, CheckCircle, FileText, HeartHandshake, Rocket, Users } from "lucide-react";
import FadeIn from "./FadeIn";
import Link from "next/link";

const services = [
    {
        name: 'القبولات الجامعية',
        description: 'تأمين قبولك في أفضل الجامعات التركية الحكومية والخاصة باحترافية وسرعة.',
        icon: GraduationCap,
    },
    {
        name: 'تجهيز الملفات',
        description: 'مراجعة وتجهيز كافة الأوراق والمستندات المطلوبة للتقديم لضمان اكتمال ملفك.',
        icon: FileCheck,
    },
    {
        name: 'المفاضلات التركية',
        description: 'التقديم على المفاضلات الجامعية ومتابعة النتائج أولاً بأول.',
        icon: Scale,
    },
    {
        name: 'التسجيل النهائي',
        description: 'إتمام إجراءات التثبيت النهائي في الجامعة واستخراج وثيقة الطالب.',
        icon: School,
    },
    {
        name: 'الإرشاد الأكاديمي',
        description: 'نقدم لك الدعم والمشورة لاختيار التخصص المناسب والجامعة الأفضل.',
        icon: BookOpen,
    },
    {
        name: 'استخراج القبول النهائي 100%',
        description: 'نضمن لك استخراج القبول الجامعي النهائي في التخصص المطلوب بنسبة 100% ودون أي تعقيدات.',
        icon: CheckCircle,
    },
    {
        name: 'تأمين السكن الطلابي',
        description: 'نساعدك في توفير سكن طلابي آمن ومريح ومناسب لميزانيتك بالقرب من جامعتك.',
        icon: Home,
    },
    {
        name: 'الاستقبال من المطار',
        description: 'خدمة استقبال خاصة VIP من المطار وتأمين وصولك إلى مقر إقامتك بأمان.',
        icon: Plane,
    },
    {
        name: 'إجراءات الإقامة',
        description: 'متابعة شاملة لاستخراج الإقامة الطلابية والتأمين الصحي وتجهيز كافة الأوراق القانونية.',
        icon: FileText,
    },
    {
        name: 'خدمات ما بعد القبول',
        description: 'دعم مستمر يشمل فتح حساب بنكي، استخراج كرت المواصلات، والمساعدة في الاندماج بالحياة الجامعية.',
        icon: HeartHandshake,
    },
];

export default function Services() {
    return (
        <div id="services" className="bg-background py-24 sm:py-32">
            <div className="mx-auto max-w-7xl px-6 lg:px-8">
                <div className="mx-auto max-w-2xl text-center">
                    <h2 className="text-base font-semibold leading-7 text-secondary">خدماتنا</h2>
                    <p className="mt-2 text-3xl font-bold tracking-tight text-primary sm:text-4xl">
                        كل ما تحتاجه للدراسة في تركيا
                    </p>
                    <p className="mt-6 text-lg leading-8 text-gray-600">
                        نقدم باقة متكاملة من الخدمات لتسهيل رحلتك الدراسية في تركيا
                    </p>
                </div>
                <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
                    <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3">
                        {services.map((service, index) => (
                            <FadeIn key={service.name} delay={index * 0.1} className="group flex flex-col items-start bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-secondary/20 hover:-translate-y-1 h-full relative overflow-hidden">
                                <div className="absolute inset-0 bg-gradient-to-br from-primary/0 to-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                                <div className="relative z-10 rounded-xl bg-primary/5 p-3 ring-1 ring-primary/10 transition-all duration-300 group-hover:bg-primary text-primary group-hover:text-secondary group-hover:shadow-[0_0_30px_rgba(212,175,55,0.3)] group-hover:scale-110">
                                    <service.icon className="h-8 w-8 transition-colors duration-300" aria-hidden="true" />
                                </div>
                                <dt className="relative z-10 mt-6 font-bold text-gray-900 text-xl group-hover:text-primary transition-colors duration-300">{service.name}</dt>
                                <dd className="relative z-10 mt-4 leading-7 text-gray-600 flex-grow">{service.description}</dd>
                            </FadeIn>
                        ))}
                    </dl>
                </div>

                {/* Agent CTA Section */}
                <FadeIn delay={0.3} className="mt-20 sm:mt-24">
                    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary via-primary-dark to-primary p-8 sm:p-12 shadow-2xl">
                        {/* Decorative elements */}
                        <div className="absolute top-0 right-0 -mt-4 -mr-4 h-32 w-32 rounded-full bg-secondary/20 blur-3xl" />
                        <div className="absolute bottom-0 left-0 -mb-4 -ml-4 h-40 w-40 rounded-full bg-secondary/10 blur-3xl" />

                        <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8">
                            <div className="flex-1 text-center lg:text-right">
                                <div className="inline-flex items-center gap-2 px-4 py-2 bg-secondary/20 rounded-full mb-4">
                                    <Users className="h-5 w-5 text-secondary" />
                                    <span className="text-sm font-bold text-secondary">انضم إلى شبكتنا</span>
                                </div>
                                <h3 className="text-3xl sm:text-4xl font-extrabold text-white mb-4">
                                    كن وكيلاً معتمداً لدينا
                                </h3>
                                <p className="text-lg text-gray-200 max-w-2xl mx-auto lg:mx-0">
                                    انضم إلى شبكة وكلائنا المعتمدين واحصل على عمولات مميزة مقابل كل طالب تحيله إلينا. نقدم لك الدعم الكامل والأدوات اللازمة للنجاح
                                </p>
                            </div>
                            <div className="flex flex-col sm:flex-row gap-4">
                                <Link
                                    href="/agent-register"
                                    className="inline-flex items-center justify-center gap-3 px-8 py-4 bg-secondary text-primary-dark font-bold text-lg rounded-xl shadow-[0_0_30px_rgba(212,175,55,0.4)] hover:shadow-[0_0_40px_rgba(212,175,55,0.6)] hover:bg-secondary-dark hover:scale-105 transition-all duration-300"
                                >
                                    <Rocket className="h-6 w-6" />
                                    سجّل كوكيل الآن
                                </Link>
                                <Link
                                    href="/agent-login"
                                    className="inline-flex items-center justify-center gap-3 px-8 py-4 bg-white/10 backdrop-blur-sm text-white font-bold text-lg rounded-xl border-2 border-white/30 hover:bg-white/20 hover:border-white/50 hover:scale-105 transition-all duration-300"
                                >
                                    دخول الوكلاء
                                </Link>
                            </div>
                        </div>
                    </div>
                </FadeIn>
            </div>
        </div>
    );
}

"use client";

import { motion, useInView, useMotionValue, useSpring } from "framer-motion";
import { useEffect, useRef } from "react";
import { Users, GraduationCap, Building2, Award, Heart, ShieldCheck, Sparkles } from "lucide-react";

interface CounterProps {
    value: number;
    suffix?: string;
    prefix?: string;
}

function Counter({ value, suffix = "", prefix = "" }: CounterProps) {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true });
    const motionValue = useMotionValue(0);
    const springValue = useSpring(motionValue, {
        damping: 30,
        stiffness: 100,
    });

    useEffect(() => {
        if (isInView) {
            motionValue.set(value);
        }
    }, [isInView, value, motionValue]);

    const displayValue = useRef<HTMLSpanElement>(null);

    useEffect(() => {
        return springValue.on("change", (latest) => {
            if (displayValue.current) {
                displayValue.current.textContent = Intl.NumberFormat("en-US").format(
                    Math.floor(latest)
                );
            }
        });
    }, [springValue]);

    return (
        <span ref={ref} className="tabular-nums">
            {prefix}
            <span ref={displayValue}>0</span>
            {suffix}
        </span>
    );
}

const stats = [
    {
        id: 1,
        name: "طالب وثق بنا",
        value: 1200,
        suffix: "+",
        icon: Users,
    },
    {
        id: 2,
        name: "جامعة شريكة",
        value: 50,
        suffix: "+",
        icon: Building2,
    },
    {
        id: 3,
        name: "قبول مستخرج",
        value: 3500,
        suffix: "+",
        icon: GraduationCap,
    },
    {
        id: 4,
        name: "سنوات خبرة",
        value: 8,
        suffix: "+",
        icon: Award,
    },
    {
        id: 5,
        name: "نسبة الرضا",
        value: 98,
        suffix: "%",
        icon: Heart,
    },
    {
        id: 6,
        name: "دعم متواصل",
        value: 24,
        suffix: "/7",
        icon: ShieldCheck,
    },
];

export default function Stats() {
    return (
        <section id="stats" className="relative py-24 sm:py-32 overflow-hidden bg-white">
            {/* Premium Background Effects */}
            <div className="absolute inset-0 pointer-events-none">
                <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary/[0.02] rounded-full blur-[100px]" />
                <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-secondary/[0.04] rounded-full blur-[100px]" />
            </div>

            <div className="mx-auto max-w-7xl px-6 lg:px-8 relative z-10">
                <div className="flex flex-col items-center text-center mb-16 sm:mb-20">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.5 }}
                        className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-secondary/10 text-secondary border border-secondary/20 mb-6"
                    >
                        <Sparkles className="h-4 w-4" />
                        <span className="text-xs font-bold uppercase tracking-wider">الأرقام لا تكذب</span>
                    </motion.div>

                    <motion.h2
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6 }}
                        className="text-3xl font-extrabold text-primary sm:text-5xl mb-6 tracking-tight"
                    >
                        إنجازات تدفعنا <span className="text-secondary">للأمام</span>
                    </motion.h2>

                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.1 }}
                        className="text-base sm:text-lg text-gray-600 max-w-2xl leading-relaxed"
                    >
                        نفخر بما حققناه من بصمة حقيقية في مسيرة آلاف الطلاب، ونسعى دائماً لتوسيع آفاقنا لتقديم الأفضل.
                    </motion.p>
                </div>

                <div className="grid grid-cols-2 gap-x-4 gap-y-10 text-center sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 sm:gap-x-8 sm:gap-y-16">
                    {stats.map((stat, index) => (
                        <motion.div
                            key={stat.id}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.5, delay: index * 0.1 }}
                            viewport={{ once: true }}
                            className="flex flex-col items-center gap-y-3 sm:gap-y-4 p-4 rounded-3xl transition-all hover:bg-gray-50 group"
                        >
                            <div className="p-3 sm:p-4 rounded-2xl bg-white shadow-sm border border-gray-100 text-secondary group-hover:bg-secondary group-hover:text-white transition-all duration-300">
                                <stat.icon className="h-6 w-6 sm:h-8 sm:w-8" />
                            </div>
                            <dd className="text-2xl sm:text-4xl font-extrabold tracking-tight text-primary">
                                <Counter value={stat.value} suffix={stat.suffix} />
                            </dd>
                            <dt className="text-xs sm:text-base font-medium text-gray-600">
                                {stat.name}
                            </dt>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
}

"use client";

import { useState, useEffect } from "react";
import { Building2, GraduationCap, MapPin, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import FadeIn from "./FadeIn";
import Link from "next/link";

type University = {
    id: number;
    name: string;
    city: string;
    type: "Government" | "Private";
    description: string;
};



export default function Universities() {
    const [activeTab, setActiveTab] = useState<"Government" | "Private">("Government");
    const [searchTerm, setSearchTerm] = useState("");
    const [universities, setUniversities] = useState<University[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchUniversities = async () => {
            try {
                const res = await fetch("/api/universities");
                if (res.ok) {
                    const data = await res.json();
                    setUniversities(data);
                }
            } catch (error) {
                console.error("Failed to fetch universities", error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchUniversities();
    }, []);

    const filteredUniversities = universities.filter(u =>
        u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.city.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div id="universities" className="bg-gray-50 py-24 sm:py-32 relative overflow-hidden">
            {/* Background decoration */}
            <div className="absolute top-0 right-0 -mr-24 -mt-24 w-96 h-96 rounded-full bg-secondary/5 blur-3xl z-0" />
            <div className="absolute bottom-0 left-0 -ml-24 -mb-24 w-96 h-96 rounded-full bg-primary/5 blur-3xl z-0" />

            <div className="mx-auto max-w-7xl px-6 lg:px-8 relative z-10">
                <div className="mx-auto max-w-2xl text-center">
                    <h2 className="text-base font-semibold leading-7 text-secondary">الجامعات التركية</h2>
                    <p className="mt-2 text-3xl font-bold tracking-tight text-primary sm:text-4xl">
                        اختر وجهتك الأكاديمية
                    </p>
                    <p className="mt-6 text-lg leading-8 text-gray-600">
                        قائمة مختارة من أفضل الجامعات التركية، تعرف على نبذة مختصرة عن كل جامعة وموقعها.
                    </p>
                </div>

                <div className="mt-12 flex flex-col items-center gap-6">
                    {/* Search */}
                    <div className="relative w-full max-w-lg">
                        <div className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none">
                            <Search className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                            type="text"
                            className="block w-full rounded-2xl border-0 py-4 pr-12 pl-4 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-200 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-secondary/50 sm:text-sm sm:leading-6 transition-all focus:scale-[1.01]"
                            placeholder="ابحث باسم الـجــامــعــة أو المدينة..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>

                <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
                    {isLoading ? (
                        Array.from({ length: 3 }).map((_, i) => (
                            <div key={i} className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 h-64 animate-pulse flex flex-col gap-4">
                                <div className="h-16 w-16 bg-gray-200 rounded-full" />
                                <div className="h-6 w-3/4 bg-gray-200 rounded" />
                                <div className="h-4 w-full bg-gray-200 rounded" />
                                <div className="mt-auto h-4 w-1/2 bg-gray-200 rounded" />
                            </div>
                        ))
                    ) : filteredUniversities.length > 0 ? (
                        filteredUniversities.map((uni, index) => (
                            <FadeIn key={uni.id} delay={index * 0.05} className="group relative flex flex-col bg-white rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-secondary/30 overflow-hidden hover:-translate-y-1">
                                <Link href={`/universities/${uni.id}`} className="block h-full cursor-pointer">
                                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-50/50 opacity-0 group-hover:opacity-100 transition-opacity" />

                                    <div className="p-8 flex flex-col h-full relative z-10">
                                        <div className="flex items-start justify-between mb-6">
                                            <div className={cn("p-3 rounded-2xl", uni.type === "Government" ? "bg-primary/10 text-primary" : "bg-secondary/10 text-secondary")}>
                                                {uni.type === "Government" ? <Building2 className="h-8 w-8" /> : <GraduationCap className="h-8 w-8" />}
                                            </div>
                                            <div className="flex items-center gap-1.5 text-xs font-medium text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                                                <MapPin className="h-3 w-3" />
                                                {uni.city}
                                            </div>
                                        </div>

                                        <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-primary transition-colors">{uni.name}</h3>
                                        <p className="text-sm text-gray-600 mb-6 leading-relaxed line-clamp-3">{uni.description}</p>

                                        <div className="mt-auto flex justify-end">
                                            <span className="text-xs font-bold text-secondary group-hover:translate-x-1 transition-transform rtl:group-hover:-translate-x-1">
                                                عرض التفاصيل &larr;
                                            </span>
                                        </div>
                                    </div>
                                </Link>
                            </FadeIn>
                        ))
                    ) : (
                        <div className="col-span-full py-20 text-center">
                            <div className="bg-gray-50 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                                <Search className="h-8 w-8 text-gray-400" />
                            </div>
                            <h3 className="text-lg font-bold text-gray-900">لا توجد نتائج</h3>
                            <p className="text-gray-500 mt-2">جرب البحث عن جامعة أخرى أو مدينة مختلفة.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

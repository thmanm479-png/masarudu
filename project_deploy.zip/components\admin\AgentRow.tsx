"use client";

import { Agent } from "@prisma/client";
import { Eye, Edit, Trash2 } from "lucide-react";
import TableActions from "@/components/TableActions";
import { deleteAgent } from "@/app/actions/admin";
import { useRouter } from "next/navigation";
import { useState } from "react";

interface AgentRowProps {
    agent: Agent & { _count: { clients: number } };
}

export default function AgentRow({ agent }: AgentRowProps) {
    const router = useRouter();
    const [isDeleting, setIsDeleting] = useState(false);

    const handleDelete = async () => {
        if (confirm("هل أنت متأكد من حذف هذا الوكيل؟")) {
            setIsDeleting(true);
            const result = await deleteAgent(agent.id);
            if (!result.success) {
                alert(result.error);
                setIsDeleting(false);
            }
        }
    };

    return (
        <tr className={`hover:bg-gray-50 transition-colors ${isDeleting ? "opacity-50" : ""}`}>
            <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                    <div className="h-10 w-10 flex-shrink-0">
                        <div className="h-10 w-10 rounded-full bg-secondary/10 flex items-center justify-center text-secondary font-bold">
                            {agent.fullName.charAt(0)}
                        </div>
                    </div>
                    <div className="mr-4">
                        <div className="text-sm font-medium text-gray-900">{agent.fullName}</div>
                        <div className="text-sm text-gray-500">{agent.id}#</div>
                    </div>
                </div>
            </td>
            <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900" dir="ltr">{agent.phone}</div>
                <div className="text-sm text-gray-500">{agent.email}</div>
            </td>
            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {agent.city || "-"}
            </td>
            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-bold">
                {agent._count.clients}
            </td>
            <td className="px-6 py-4 whitespace-nowrap">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                    ${agent.status === 'نشط' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                    {agent.status}
                </span>
            </td>
            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                <TableActions
                    actions={[
                        { label: "عرض التفاصيل", icon: Eye, onClick: () => router.push(`/admin/agents/${agent.id}`) },
                        { label: "تعديل", icon: Edit, onClick: () => router.push(`/admin/agents/${agent.id}/edit`) },
                        { label: "حذف", icon: Trash2, onClick: handleDelete, variant: "danger" },
                    ]}
                />
            </td>
        </tr>
    );
}

"use client";

import { Client } from "@prisma/client";
import { Eye, Edit, Trash2 } from "lucide-react";
import TableActions from "@/components/TableActions";
import { deleteClient } from "@/app/actions/admin";
import { useRouter } from "next/navigation";
import { useState } from "react";

interface ClientRowProps {
    client: Client;
}

export default function ClientRow({ client }: ClientRowProps) {
    const router = useRouter();
    const [isDeleting, setIsDeleting] = useState(false);

    const handleDelete = async () => {
        if (confirm("هل أنت متأكد من حذف هذا العميل؟")) {
            setIsDeleting(true);
            const result = await deleteClient(client.id);
            if (!result.success) {
                alert(result.error);
                setIsDeleting(false);
            }
        }
    };

    return (
        <tr className={`hover:bg-gray-50 transition-colors ${isDeleting ? "opacity-50" : ""}`}>
            <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                    <div className="h-10 w-10 flex-shrink-0">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                            {client.fullName.charAt(0)}
                        </div>
                    </div>
                    <div className="mr-4">
                        <div className="text-sm font-medium text-gray-900">{client.fullName}</div>
                        <div className="text-sm text-gray-500">{client.nationality || "غير محدد"}</div>
                    </div>
                </div>
            </td>
            <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900" dir="ltr">{client.phone}</div>
                <div className="text-sm text-gray-500">{client.email || "-"}</div>
            </td>
            <td className="px-6 py-4 whitespace-nowrap">
                <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    {client.desiredMajor}
                </span>
                <div className="text-xs text-gray-500 mt-1">{client.universityType}</div>
            </td>
            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                    ${client.status === 'جديد' ? 'bg-blue-100 text-blue-800' :
                        client.status === 'تم القبول' ? 'bg-green-100 text-green-800' :
                            'bg-gray-100 text-gray-800'}`}>
                    {client.status}
                </span>
            </td>
            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                <TableActions
                    actions={[
                        { label: "عرض التفاصيل", icon: Eye, onClick: () => router.push(`/admin/clients/${client.id}`) },
                        { label: "تعديل", icon: Edit, onClick: () => router.push(`/admin/clients/${client.id}/edit`) },
                        { label: "حذف", icon: Trash2, onClick: handleDelete, variant: "danger" },
                    ]}
                />
            </td>
        </tr>
    );
}

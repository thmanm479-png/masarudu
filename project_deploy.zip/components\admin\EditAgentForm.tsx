"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Save } from "lucide-react";
import { updateAgent as updateAgentAction } from "@/app/actions/admin";

interface EditAgentFormProps {
    agent: any;
}

export default function EditAgentForm({ agent }: EditAgentFormProps) {
    const router = useRouter();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [formData, setFormData] = useState({
        fullName: agent.fullName || "",
        email: agent.email || "",
        phone: agent.phone || "",
        city: agent.city || "",
        status: agent.status || "نشط",
        paymentMethod: agent.paymentMethod || "",
        paymentDetails: agent.paymentDetails || "",
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        try {
            const result = await updateAgentAction(agent.id, formData);
            if (result.success) {
                router.push(`/admin/agents/${agent.id}`);
                router.refresh();
            } else {
                alert("فشل التحديث: " + result.error);
            }
        } catch (error) {
            console.error(error);
            alert("حدث خطأ غير متوقع");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="md:col-span-2 pb-4 border-b border-gray-100">
                    <h2 className="text-lg font-semibold text-gray-800">بيانات الوكيل الشخصية</h2>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">الاسم الكامل</label>
                    <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        required
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">البريد الإلكتروني</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        dir="ltr"
                        required
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">رقم الهاتف</label>
                    <input
                        type="text"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        dir="ltr"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">المدينة</label>
                    <input
                        type="text"
                        name="city"
                        value={formData.city}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">حالة الحساب</label>
                    <select
                        name="status"
                        value={formData.status}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    >
                        <option value="نشط">نشط</option>
                        <option value="غير نشط">غير نشط</option>
                        <option value="قيد المراجعة">قيد المراجعة</option>
                    </select>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 gap-6 grid grid-cols-1 md:grid-cols-2">
                <div className="md:col-span-2 pb-4 border-b border-gray-100">
                    <h2 className="text-lg font-semibold text-gray-800">بيانات الدفع</h2>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">طريقة الدفع المفضلة</label>
                    <select
                        name="paymentMethod"
                        value={formData.paymentMethod}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    >
                        <option value="">اختر...</option>
                        <option value="Bank Transfer">تحويل بنكي</option>
                        <option value="USDT">USDT</option>
                        <option value="Western Union">ويسترن يونيون</option>
                        <option value="Cash">كاش</option>
                    </select>
                </div>

                <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">تفاصيل الدفع (رقم الحساب / المحفظة)</label>
                    <textarea
                        name="paymentDetails"
                        rows={3}
                        value={formData.paymentDetails}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
                    />
                </div>
            </div>

            <div className="flex justify-end gap-4">
                <button
                    type="button"
                    onClick={() => router.back()}
                    className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                    disabled={isSubmitting}
                >
                    إلغاء
                </button>
                <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors flex items-center gap-2 disabled:opacity-70"
                >
                    {isSubmitting ? (
                        <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            جاري الحفظ...
                        </>
                    ) : (
                        <>
                            <Save className="w-4 h-4" />
                            حفظ التغييرات
                        </>
                    )}
                </button>
            </div>
        </form>
    );
}

"use client";

import { Employee } from "@prisma/client";
import { Eye, Edit, Trash2 } from "lucide-react";
import TableActions from "@/components/TableActions";
import { deleteEmployee } from "@/app/actions/admin";
import { useRouter } from "next/navigation";
import { useState } from "react";

interface EmployeeRowProps {
    employee: Employee;
}

export default function EmployeeRow({ employee }: EmployeeRowProps) {
    const router = useRouter();
    const [isDeleting, setIsDeleting] = useState(false);

    const handleDelete = async () => {
        if (confirm("هل أنت متأكد من حذف هذا الموظف؟")) {
            setIsDeleting(true);
            const result = await deleteEmployee(employee.id);
            if (!result.success) {
                alert(result.error);
                setIsDeleting(false);
            }
        }
    };

    return (
        <tr className={`hover:bg-gray-50 transition-colors ${isDeleting ? "opacity-50" : ""}`}>
            <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                    <div className="h-10 w-10 flex-shrink-0">
                        <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-bold">
                            {employee.fullName.charAt(0)}
                        </div>
                    </div>
                    <div className="mr-4">
                        <div className="text-sm font-medium text-gray-900">{employee.fullName}</div>
                    </div>
                </div>
            </td>
            <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{employee.email}</div>
                <div className="text-sm text-gray-500" dir="ltr">{employee.phone || "-"}</div>
            </td>
            <td className="px-6 py-4 whitespace-nowrap">
                <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                    {employee.role}
                </span>
            </td>
            <td className="px-6 py-4 whitespace-nowrap">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                    ${employee.status === 'نشط' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {employee.status}
                </span>
            </td>
            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {new Date(employee.createdAt).toLocaleDateString("ar-EG")}
            </td>
            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                <TableActions
                    actions={[
                        { label: "عرض التفاصيل", icon: Eye, onClick: () => router.push(`/admin/employees/${employee.id}`) },
                        { label: "تعديل", icon: Edit, onClick: () => router.push(`/admin/employees/${employee.id}/edit`) },
                        { label: "حذف", icon: Trash2, onClick: handleDelete, variant: "danger" },
                    ]}
                />
            </td>
        </tr>
    );
}

"use client";

import { useState } from "react";
import { Mail, Trash2, Calendar, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { useRouter } from "next/navigation";

type Submission = {
    id: number;
    name: string;
    email: string | null;
    phone: string;
    message: string;
    status: string;
    createdAt: string; // Changed to string for serialization
};

export default function SubmissionRow({ submission }: { submission: Submission }) {
    const [isDeleting, setIsDeleting] = useState(false);
    const router = useRouter();

    const handleDelete = async () => {
        if (!confirm("هل أنت متأكد من حذف هذه الرسالة؟")) return;

        setIsDeleting(true);
        try {
            const res = await fetch(`/api/contact/${submission.id}`, {
                method: "DELETE",
            });

            if (res.ok) {
                router.refresh(); // Refresh server component
            } else {
                alert("فشل الحذف");
            }
        } catch (error) {
            console.error("Delete failed", error);
            alert("حدث خطأ ما");
        } finally {
            setIsDeleting(false);
        }
    };

    const handleReply = () => {
        if (submission.email) {
            window.location.href = `mailto:${submission.email}?subject=رد على استفسارك - مسار التعليمية`;
        } else {
            // Fallback for WhatsApp if phone exists?
            // Assuming phone is international format.
            const phone = submission.phone.replace(/\D/g, '');
            window.open(`https://wa.me/${phone}`, '_blank');
        }
    };

    return (
        <tr className="hover:bg-gray-50/50 transition-colors group">
            <td className="px-6 py-4">
                <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/5 flex items-center justify-center text-primary font-bold">
                        {submission.name.charAt(0)}
                    </div>
                    <div className="flex flex-col">
                        <span className="text-sm font-bold text-gray-900">{submission.name}</span>
                        <div className="flex items-center gap-2 text-xs text-gray-400">
                            <span dir="ltr">{submission.phone}</span>
                            {submission.email && (
                                <>
                                    <span>•</span>
                                    <span>{submission.email}</span>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </td>
            <td className="px-6 py-4">
                <p className="text-sm text-gray-600 line-clamp-2 max-w-xs" title={submission.message}>{submission.message}</p>
            </td>
            <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Calendar className="h-3.5 w-3.5" />
                    {format(new Date(submission.createdAt), 'dd MMMM yyyy', { locale: ar })}
                </div>
            </td>
            <td className="px-6 py-4 whitespace-nowrap">
                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium
                    ${submission.status === 'جديد' ? 'bg-yellow-50 text-yellow-700' :
                        submission.status === 'تم الرد' ? 'bg-green-50 text-green-700' :
                            'bg-gray-50 text-gray-700'}`}>
                    <span className={`h-1.5 w-1.5 rounded-full ${submission.status === 'جديد' ? 'bg-yellow-500' :
                        submission.status === 'تم الرد' ? 'bg-green-500' : 'bg-gray-400'
                        }`} />
                    {submission.status}
                </span>
            </td>
            <td className="px-6 py-4 whitespace-nowrap text-center">
                <div className="flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                        onClick={handleReply}
                        className="p-2 hover:bg-primary/10 text-primary rounded-lg transition-colors"
                        title={submission.email ? "رد عبر الإيميل" : "رد عبر واتساب"}
                    >
                        <Mail className="h-4 w-4" />
                    </button>
                    <button
                        onClick={handleDelete}
                        disabled={isDeleting}
                        className="p-2 hover:bg-red-50 text-red-600 rounded-lg transition-colors disabled:opacity-50"
                        title="حذف"
                    >
                        {isDeleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                    </button>
                </div>
            </td>
        </tr>
    );
}

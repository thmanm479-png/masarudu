-- Enable RLS on all tables
ALTER TABLE "Agent" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Client" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Admin" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Employee" ENABLE ROW LEVEL SECURITY;

-- Policies for Agent
-- Allow agents to read their own data
CREATE POLICY "Agents can view own data" ON "Agent"
FOR SELECT USING (auth.uid()::text = id::text OR auth.role() = 'service_role');

-- Allow agents to update their own data
CREATE POLICY "Agents can update own data" ON "Agent"
FOR UPDATE USING (auth.uid()::text = id::text);

-- Policies for Client
-- Allow agents to view their own clients
CREATE POLICY "Agents can view own clients" ON "Client"
FOR SELECT USING (auth.uid()::text = "agentId"::text OR auth.role() = 'service_role');

-- Allow agents to create clients
CREATE POLICY "Agents can create clients" ON "Client"
FOR INSERT WITH CHECK (auth.uid()::text = "agentId"::text);

-- Default RLS for public tables (Universities, FAQs, Settings) - readable by everyone
ALTER TABLE "University" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read access for universities" ON "University"
FOR SELECT USING (true);

ALTER TABLE "FAQ" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read access for FAQs" ON "FAQ"
FOR SELECT USING (true);

ALTER TABLE "Settings" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read access for Settings" ON "Settings"
FOR SELECT USING (true);

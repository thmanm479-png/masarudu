-- AlterTable
ALTER TABLE "Agent" ADD COLUMN "paymentDetails" TEXT;
ALTER TABLE "Agent" ADD COLUMN "resetToken" TEXT;
ALTER TABLE "Agent" ADD COLUMN "resetTokenExpires" DATETIME;

-- CreateTable
CREATE TABLE "SiteContent" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "key" TEXT NOT NULL,
    "value" TEXT NOT NULL,
    "group" TEXT,
    "updatedAt" DATETIME NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "SiteContent_key_key" ON "SiteContent"("key");

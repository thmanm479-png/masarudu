const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
    const universities = [
        { name: "Tokat University", city: "Tokat", type: "Government", applicationFee: "50$", tuitionFee: "400$ - 1200$", admissionReqs: "High School Diploma + YOS" },
        { name: "Karabuk University", city: "Karabuk", type: "Government", applicationFee: "40$", tuitionFee: "350$ - 1000$", admissionReqs: "High School Diploma + YOS" },
        { name: "Bolu Abant Izzet Baysal University", city: "Bolu", type: "Government", applicationFee: "60$", tuitionFee: "500$ - 1500$", admissionReqs: "High School Diploma + YOS" },
        { name: "Batman University", city: "Batman", type: "Government", applicationFee: "30$", tuitionFee: "300$ - 800$", admissionReqs: "High School Diploma" },
        { name: "Bilecik Şeyh Edebali University", city: "Bilecik", type: "Government", applicationFee: "45$", tuitionFee: "400$ - 1100$", admissionReqs: "High School Diploma + YOS" },
        { name: "Sivas Cumhuriyet University", city: "Sivas", type: "Government", applicationFee: "55$", tuitionFee: "450$ - 1300$", admissionReqs: "High School Diploma + YOS" },
        { name: "Gümüşhane University", city: "Gümüşhane", type: "Government", applicationFee: "35$", tuitionFee: "350$ - 900$", admissionReqs: "High School Diploma" },
        { name: "Sakarya University", city: "Sakarya", type: "Government", applicationFee: "70$", tuitionFee: "600$ - 2000$", admissionReqs: "High School Diploma + YOS" },
        { name: "Kocaeli University", city: "Kocaeli", type: "Government", applicationFee: "65$", tuitionFee: "550$ - 1800$", admissionReqs: "High School Diploma + YOS" },
        { name: "Düzce University", city: "Düzce", type: "Government", applicationFee: "50$", tuitionFee: "400$ - 1400$", admissionReqs: "High School Diploma + YOS" },
    ];

    console.log('Seeding universities...');
    for (const uni of universities) {
        await prisma.university.upsert({
            where: { id: 0 }, // This is a bit hacky for a simple seed, usually we use unique names
            update: {},
            create: uni,
        });
    }

    // Also seed some initial FAQs
    const faqs = [
        { question: "هل القبول الجامعي مضمون؟", answer: "في الجامعات الخاصة، القبول مضمون بنسبة كبيرة جداً. أما في الجامعات الحكومية، فنحن نعمل بجهد كبير لزيادة فرص قبولك." },
        { question: "هل أحتاج شهادة يوس؟", answer: "للجامعات الخاصة لا يطلب غالباً. أما الحكومية القوية فمعظمها يشترط وجود شهادة يوس." },
    ];

    console.log('Seeding FAQs...');
    for (const faq of faqs) {
        await prisma.fAQ.create({
            data: faq,
        });
    }

    console.log('Seeding complete!');
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });

const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function approveAgents() {
    try {
        console.log('🔍 Checking for pending agents...');
        const pendingAgents = await prisma.agent.findMany({
            where: { status: 'قيد المراجعة' }
        });

        console.log(`📝 Found ${pendingAgents.length} pending agents.`);

        if (pendingAgents.length > 0) {
            const updateResult = await prisma.agent.updateMany({
                where: { status: 'قيد المراجعة' },
                data: { status: 'نشط' }
            });
            console.log(`✅ Approved ${updateResult.count} agents.`);
        } else {
            console.log('✨ No pending agents to approve.');
        }

    } catch (e) {
        console.error('❌ Error approving agents:', e);
    } finally {
        await prisma.$disconnect();
    }
}

approveAgents();

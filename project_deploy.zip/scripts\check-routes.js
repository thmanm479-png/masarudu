const http = require('http');

const routes = [
    '/',
    '/universities',
    '/admin',
    '/admin/login',
    '/agent-login',
    '/agent-register',
    '/api/admin/login',
    '/api/agents/login'
];

function checkRoute(path) {
    return new Promise((resolve) => {
        const options = {
            hostname: 'localhost',
            port: 3000,
            path: path,
            method: 'GET' // using GET for pages
        };

        if (path.startsWith('/api/')) {
            options.method = 'POST'; // APIs are POST usually
        }

        const req = http.request(options, (res) => {
            resolve({ path, status: res.statusCode });
        });

        req.on('error', (e) => {
            resolve({ path, status: 'ERROR', error: e.message });
        });

        // For POST requests, we need to end the request even if empty
        if (options.method === 'POST') {
            req.write(JSON.stringify({})); // Sending empty body might trigger 400 but ensures status code
        }

        req.end();
    });
}

async function checkAll() {
    console.log('Checking routes...');
    for (const route of routes) {
        const result = await checkRoute(route);
        console.log(`${result.path}: ${result.status}`);
    }
}

checkAll();

const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
    try {
        const adminCount = await prisma.admin.count();
        const agentCount = await prisma.agent.count();
        console.log(`✅ DB Connection OK. Admins: ${adminCount}, Agents: ${agentCount}`);
    } catch (e) {
        console.error('❌ DB Connection Failed:', e.message);
    } finally {
        await prisma.$disconnect();
    }
}

main();

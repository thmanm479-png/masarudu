const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function main() {
    try {
        const usernameToDelete = 'testadmin_temp_1740669149457';
        console.log(`Deleting test admin: ${usernameToDelete}`);

        const deletedUser = await prisma.admin.delete({
            where: {
                username: usernameToDelete,
            },
        });

        console.log('Test admin deleted successfully:', deletedUser);

    } catch (error) {
        if (error.code === 'P2025') {
            console.log('Test admin not found (already deleted or never created).');
        } else {
            console.error('Error deleting test admin:', error);
        }
    } finally {
        await prisma.$disconnect();
    }
}

main();

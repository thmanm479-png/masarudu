const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
    try {
        const testUsername = 'testadmin_temp_' + Date.now();
        const testPassword = 'password123';
        const hashedPassword = await bcrypt.hash(testPassword, 10);

        console.log(`Creating test admin: ${testUsername}`);

        const admin = await prisma.admin.create({
            data: {
                username: testUsername,
                password: hashedPassword,
                email: `test_${Date.now()}@example.com`
            },
        });

        console.log('Test admin created successfully.');
        console.log(JSON.stringify({
            username: testUsername,
            password: testPassword,
            id: admin.id
        }));

    } catch (error) {
        console.error('Error creating test admin:', error);
    } finally {
        await prisma.$disconnect();
    }
}

main();

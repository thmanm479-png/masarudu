const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
    let createdId = null;
    try {
        console.log('--- Debugging Admin Creation & Login ---');

        // 1. Check DB Connection URL (masked)
        const url = process.env.DATABASE_URL || 'UNDEFINED';
        console.log(`DB URL starts with: ${url.substring(0, 15)}...`);

        // 2. Create User
        const testUsername = 'debug_admin_' + Date.now();
        const testPassword = 'password123';
        const hashedPassword = await bcrypt.hash(testPassword, 10);

        console.log(`\nCreating user: ${testUsername}`);
        const admin = await prisma.admin.create({
            data: {
                username: testUsername,
                password: hashedPassword,
                email: `debug_${Date.now()}@example.com`
            },
        });
        createdId = admin.id;
        console.log(`User created with ID: ${createdId}`);

        // 3. Verify immediately in DB
        const foundAdmin = await prisma.admin.findUnique({
            where: { id: createdId }
        });
        console.log(`\nImmediate DB lookup: ${foundAdmin ? 'FOUND' : 'NOT FOUND'}`);
        if (foundAdmin) {
            console.log(`Stored Password Hash: ${foundAdmin.password.substring(0, 10)}...`);
        }

        // 4. Verify Password Match
        if (foundAdmin) {
            const match = await bcrypt.compare(testPassword, foundAdmin.password);
            console.log(`\nBcrypt Compare (local): ${match ? 'MATCH' : 'FAIL'}`);
        }

    } catch (error) {
        console.error('Debug script failed:', error);
    } finally {
        // 5. Cleanup
        if (createdId) {
            console.log(`\nCleaning up user ID: ${createdId}`);
            await prisma.admin.delete({ where: { id: createdId } });
            console.log('Cleanup complete.');
        }
        await prisma.$disconnect();
    }
}

main();

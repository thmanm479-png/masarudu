const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function main() {
    try {
        const admins = await prisma.admin.findMany({
            select: {
                id: true,
                username: true,
                email: true,
            },
        });

        console.log('--- Admin Users List ---');
        if (admins.length === 0) {
            console.log('RESULT: NO_ADMINS_FOUND');
        } else {
            console.log('RESULT: ADMINS_FOUND');
            console.log(JSON.stringify(admins, null, 2));
        }

    } catch (error) {
        console.error('Error fetching admins:', error);
    } finally {
        await prisma.$disconnect();
    }
}

main();

const { exec } = require('child_process');

console.log('Attempting deployment to Netlify...');

// Use npx to run netlify-cli without global installation
// --prod: Deploy to production
// --dir: .next (or build directory) - Wait, Netlify builds it usually.
// Actually, standard command is just "netlify deploy --prod" if linked.

// Since we have siteId, we can try linking or just deploying with --site
const siteId = '9374e020-5334-4ead-b146-160d3d221ffa';

const command = `npx netlify-cli deploy --prod --site ${siteId}`;

console.log(`Running: ${command}`);

const child = exec(command, {
    cwd: process.cwd(),
    env: { ...process.env } // Pass current env vars which might include auth
});

child.stdout.on('data', (data) => {
    console.log(`stdout: ${data}`);
});

child.stderr.on('data', (data) => {
    console.error(`stderr: ${data}`);
});

child.on('close', (code) => {
    console.log(`child process exited with code ${code}`);
});

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
    const targetUsername = 'admin';
    const newPassword = 'admin123';

    try {
        const hashedPassword = await bcrypt.hash(newPassword, 10);

        console.log(`Resetting password for user: ${targetUsername}...`);

        const updatedAdmin = await prisma.admin.update({
            where: { username: targetUsername },
            data: { password: hashedPassword },
        });

        console.log('SUCCESS: Password updated successfully.');
        console.log(`Username: ${updatedAdmin.username}`);
        console.log(`New Password: ${newPassword}`);

    } catch (error) {
        if (error.code === 'P2025') {
            console.error(`Error: User '${targetUsername}' not found.`);
        } else {
            console.error('Error updating password:', error);
        }
    } finally {
        await prisma.$disconnect();
    }
}

main();

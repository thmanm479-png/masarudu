const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const prisma = new PrismaClient();

async function main() {
    const username = 'admin';
    const password = 'Admin@Masar2024';

    const existingAdmin = await prisma.admin.findUnique({
        where: { username }
    });

    const hashedPassword = await bcrypt.hash(password, 10);
    const adminData = {
        username,
        email: 'admin@masar-edu.com',
        password: hashedPassword
    };

    if (existingAdmin) {
        await prisma.admin.update({
            where: { username },
            data: adminData
        });
        console.log('Admin updated successfully');
        return;
    }

    const admin = await prisma.admin.create({
        data: adminData
    });

    console.log('Admin created successfully:', admin.username);
}

main()
    .catch(e => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });

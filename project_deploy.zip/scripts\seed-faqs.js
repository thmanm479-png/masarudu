const { PrismaClient } = require('@prisma/client');
require('dotenv').config();

const prisma = new PrismaClient();

const faqs = [
    {
        question: "كيف يمكنني التسجيل في الجامعات التركية؟",
        answer: "يمكنك التسجيل عبر اختيار الجامعة والتخصص من موقعنا، ثم ملء استمارة التسجيل. فريقنا سيتواصل معك لجمع الأوراق المطلوبة وبدء الإجراءات.",
        order: 1
    },
    {
        question: "ما هي الأوراق المطلوبة للتقديم؟",
        answer: "عادة ما تشمل: جواز سفر ساري المفعول، شهادة الثانوية العامة المترجمة والمصدقة، صور شخصية، وفي بعض الجامعات شهادة اختبار اليوس أو السات.",
        order: 2
    },
    {
        question: "هل أحتاج لتعلم اللغة التركية قبل السفر؟",
        answer: "ليس بالضرورة. توفر معظم الجامعات سنة تحضيرية لتعلم اللغة التركية (تومر) أو الإنجليزية قبل البدء في دراسة التخصص.",
        order: 3
    },
    {
        question: "هل توفرون خدمة السكن الطلابي؟",
        answer: "نعم، نساعد الطلاب في الحصول على سكن طلابي مريح وآمن سواء كان سكناً حكومياً أو خاصاً قريباً من الجامعة.",
        order: 4
    }
];

async function main() {
    console.log('Start seeding FAQs...');
    await prisma.fAQ.deleteMany({});
    for (const faq of faqs) {
        await prisma.fAQ.create({
            data: faq
        });
    }
    console.log('Seeding FAQs finished.');
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });

const { PrismaClient } = require('@prisma/client');
require('dotenv').config();

const prisma = new PrismaClient();

const universities = [
    {
        name: "جامعة توكات",
        city: "توكات",
        type: "Government",
        description: "تعتبر من الجامعات التركية العريقة وتتميز بتخصصات الطب والزراعة.",
        admissionReqs: "شهادة السات أو اليوس مطلوبة للقبول",
        language: "التركية والإنجليزية"
    },
    {
        name: "جامعة كارابوك",
        city: "كارابوك",
        type: "Government",
        description: "ثاني أكبر جامعة من حيث عدد الطلاب الدوليين في تركيا.",
        admissionReqs: "تقبل بمعظم الشهادات الثانوية واليوس",
        language: "التركية، الفرنسية، الإنجليزية"
    },
    {
        name: "جامعة بولو أبانت عزت بايسال",
        city: "بولو",
        type: "Government",
        description: "تتميز بموقعها الجغرافي الخلاب بين اسطنبول وأنقرة ورسومها المنخفضة.",
        admissionReqs: "أولوية لليوس الخاص بالجامعة",
        language: "التركية والإنجليزية"
    },
    {
        name: "جامعة باتمان",
        city: "باتمان",
        type: "Government",
        description: "جامعة حديثة متطورة تركز على الأبحاث التقنية والهندسية.",
        admissionReqs: "شهادة الثانوية العامة",
        language: "التركية"
    },
    {
        name: "جامعة بيلجيك شيخ أديبالي",
        city: "بيلجيك",
        type: "Government",
        description: "جامعة تاريخية تقع في قلب منطقة مرمرة.",
        admissionReqs: "الشهادة الثانوية + اليوس",
        language: "التركية"
    },
    {
        name: "جامعة سيواس جمهوريات",
        city: "سيواس",
        type: "Government",
        description: "من أكبر الجامعات التركية مساحةً وتضم كليات طبية وهندسية قوية.",
        admissionReqs: "اختبار اليوس الخاص بالجامعة",
        language: "التركية"
    },
    {
        name: "جامعة غوموش خانة",
        city: "غوموش خانة",
        type: "Government",
        description: "جامعة حكومية صاعدة توفر بيئة دراسية هادئة وتكاليف معيشة منخفضة.",
        admissionReqs: "شهادة الثانوية",
        language: "التركية"
    },
    {
        name: "جامعة صكاريا",
        city: "صكاريا",
        type: "Government",
        description: "واحدة من أفضل الجامعات الحكومية القريبة من اسطنبول.",
        admissionReqs: "اختبار السات أو يوس صكاريا",
        language: "التركية والإنجليزية"
    },
    {
        name: "جامعة كوجالي",
        city: "كوجالي",
        type: "Government",
        description: "تتمتع بارتباط قوي مع القطاع الصناعي في تركيا.",
        admissionReqs: "اختبارات الياس والحصل على معدل جيد",
        language: "التركية"
    },
    {
        name: "جامعة دوزجة",
        city: "دوزجة",
        type: "Government",
        description: "جامعة متميزة في مجالات البحوث العلمية والطب البديل.",
        admissionReqs: "شهادة الثانوية أو اليوس",
        language: "التركية"
    }
];

async function main() {
    console.log('Start seeding universities...');

    // Clear existing universities if any
    await prisma.university.deleteMany({});

    for (const uni of universities) {
        await prisma.university.create({
            data: uni
        });
    }

    console.log('Seeding finished.');
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });

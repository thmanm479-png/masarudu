const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function testAdmin() {
    try {
        const admin = await prisma.admin.findFirst({
            where: { username: 'admin' }
        });

        if (!admin) {
            console.log("Admin not found in database.");
            return;
        }

        console.log("Admin found:", admin.username);

        const testPassword = 'Admin@Masar2024';
        const isValid = await bcrypt.compare(testPassword, admin.password);
        console.log("Password 'Admin@Masar2024' is valid:", isValid);

        // Also check if there are other admins
        const allAdmins = await prisma.admin.findMany();
        console.log("Total admins in DB:", allAdmins.length);
        allAdmins.forEach(a => console.log("- User:", a.username));

    } catch (error) {
        console.error("Database connection error:", error);
    } finally {
        await prisma.$disconnect();
    }
}

testAdmin();

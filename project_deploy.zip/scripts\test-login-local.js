async function testLocalLogin() {
    console.log('Running local login test at http://localhost:3001...');
    try {
        const response = await fetch('http://localhost:3001/api/admin/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: 'admin',
                password: 'Admin@Masar2024'
            })
        });

        const data = await response.json();

        if (response.ok) {
            console.log('✅ Success! Login works perfectly locally.');
            console.log('Response:', data);
        } else {
            console.log('❌ Failed! Server returned:', response.status);
            console.log('Error:', data);
        }

    } catch (e) {
        console.error('❌ Connection failed! Is localhost:3001 running?', e.message);
    }
}

testLocalLogin();

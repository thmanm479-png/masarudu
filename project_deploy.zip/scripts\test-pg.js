const { Client } = require('pg');

const connectionString = "postgresql://postgres:Admin%40Masar2024@db.triwrtqolnqkfempwlqz.supabase.co:5432/postgres";

async function testConnection() {
    console.log('Testing connection with pg client...');
    const client = new Client({
        connectionString,
        ssl: { rejectUnauthorized: false } // Try with relaxed SSL first
    });

    try {
        await client.connect();
        console.log('✅ Connected successfully!');
        const res = await client.query('SELECT NOW()');
        console.log('Query result:', res.rows[0]);
        await client.end();
    } catch (err) {
        console.error('❌ Connection failed:', err);
    }
}

testConnection();

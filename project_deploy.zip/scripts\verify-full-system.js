const http = require('http');

// Helper to make requests
function request(path, method, body = null, headers = {}) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: 3000,
            path,
            method,
            headers: {
                'Content-Type': 'application/json',
                ...headers
            }
        };

        const req = http.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => resolve({ status: res.statusCode, body: data, headers: res.headers }));
        });

        req.on('error', reject);
        if (body) req.write(JSON.stringify(body));
        req.end();
    });
}

async function runTests() {
    console.log('--- STARTING SYSTEM VERIFICATION ---\n');

    // 1. Verify Universities Public Page
    console.log('1. Checking Public Content (Universities)...');
    try {
        const uniRes = await request('/universities', 'GET');
        if (uniRes.status === 200) console.log('✅ Universities page loads (200 OK)');
        else console.log(`❌ Universities page failed (${uniRes.status})`);
    } catch (e) { console.error('❌ Network error checking universities:', e.message); }

    // 2. Admin Flow
    console.log('\n2. Testing Admin Flow...');
    let adminCookie = '';
    try {
        // Login
        const loginRes = await request('/api/admin/login', 'POST', { username: 'admin', password: 'admin' });
        if (loginRes.status === 200) {
            console.log('✅ Admin Login Successful');
            // Extract cookie if present (mocking browser behavior)
            // Note: In a real app we'd parse set-cookie, but for API tests we mainly check status
        } else {
            console.log(`❌ Admin Login Failed: ${loginRes.status} - ${loginRes.body}`);
        }
    } catch (e) { console.error('❌ Admin flow error:', e.message); }

    // 3. Agent Flow
    console.log('\n3. Testing Agent Flow...');
    const testAgent = {
        fullName: `Verif Agent ${Date.now()}`,
        phone: "0555555555",
        email: `agent${Date.now()}@test.com`,
        studentCount: "10-20",
        experience: "Verification Test",
        password: "password123",
        paymentMethod: "Bank"
    };

    try {
        // Register
        const regRes = await request('/api/agents', 'POST', testAgent);
        if (regRes.status === 200) {
            console.log('✅ Agent Registration Successful');

            // Login
            const agentLoginRes = await request('/api/agents/login', 'POST', {
                email: testAgent.email,
                password: testAgent.password
            });

            if (agentLoginRes.status === 200) {
                console.log('✅ Agent Login Successful');
                const body = JSON.parse(agentLoginRes.body);
                if (body.token) console.log('✅ Auth Token Received');
                else console.log('⚠️ No auth token in response');
            } else {
                console.log(`❌ Agent Login Failed: ${agentLoginRes.status} - ${agentLoginRes.body}`);
            }

        } else {
            console.log(`❌ Agent Registration Failed: ${regRes.status} - ${regRes.body}`);
        }
    } catch (e) { console.error('❌ Agent flow error:', e.message); }

    console.log('\n--- VERIFICATION COMPLETE ---');
}

runTests();

const http = require('http');
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

function checkEndpoint(path, method, data = null) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: '127.0.0.1',
            port: 3000,
            path: path,
            method: method,
            headers: data ? {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(data)
            } : {}
        };

        const req = http.request(options, (res) => {
            let body = '';
            res.setEncoding('utf8');
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => {
                resolve({ statusCode: res.statusCode, body });
            });
        });

        req.on('error', (e) => reject(e));
        if (data) req.write(data);
        req.end();
    });
}

async function main() {
    let createdId = null;
    const testUsername = 'api_test_admin_' + Date.now();
    const testPassword = 'password123';

    try {
        // 1. Create User
        console.log(`Creating test user: ${testUsername} for API test...`);
        const hashedPassword = await bcrypt.hash(testPassword, 10);
        const admin = await prisma.admin.create({
            data: {
                username: testUsername,
                password: hashedPassword,
                email: `api_test_${Date.now()}@example.com`
            },
        });
        createdId = admin.id;

        // 2. Test Login API
        console.log('Testing Login API with valid credentials...');
        const postData = JSON.stringify({ username: testUsername, password: testPassword });
        const response = await checkEndpoint('/api/admin/login', 'POST', postData);

        console.log(`API Status: ${response.statusCode}`);
        if (response.statusCode === 200) {
            console.log('SUCCESS: API Login successful.');
        } else {
            console.log('FAILURE: API returned error.');
            console.log('Response Body:', response.body);
        }

    } catch (error) {
        console.error('Test failed:', error);
    } finally {
        if (createdId) {
            console.log('Cleaning up...');
            await prisma.admin.delete({ where: { id: createdId } });
        }
        await prisma.$disconnect();
    }
}

main();

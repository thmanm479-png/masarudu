const http = require('http');

const postData = JSON.stringify({
    username: 'testuser',
    password: 'wrongpassword'
});

const options = {
    hostname: 'localhost',
    port: 3000,
    path: '/api/admin/login',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
    }
};

console.log('Testing /api/admin/login with invalid credentials...');

const req = http.request(options, (res) => {
    console.log(`STATUS: ${res.statusCode}`);
    console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
    res.setEncoding('utf8');
    res.on('data', (chunk) => {
        console.log(`BODY: ${chunk}`);
    });
    res.on('end', () => {
        console.log('No more data in response.');
        if (res.statusCode === 401) {
            console.log('SUCCESS: Middleware and API are working correctly (Auth failed as expected).');
        } else if (res.statusCode === 500) {
            console.log('FAILURE: Internal Server Error (Middleware or API crash).');
        } else {
            console.log(`UNKNOWN: Unexpected status code ${res.statusCode}`);
        }
    });
});

req.on('error', (e) => {
    console.error(`problem with request: ${e.message}`);
});

// Write data to request body
req.write(postData);
req.end();

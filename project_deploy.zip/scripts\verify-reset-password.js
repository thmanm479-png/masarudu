const http = require('http');

function checkEndpoint(path, method, data = null) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: '127.0.0.1',
            port: 3000,
            path: path,
            method: method,
            headers: data ? {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(data)
            } : {}
        };

        console.log(`Testing ${method} ${path}...`);

        const req = http.request(options, (res) => {
            console.log(`STATUS: ${res.statusCode}`);
            let body = '';
            res.setEncoding('utf8');
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => {
                resolve({ statusCode: res.statusCode, body });
            });
        });

        req.on('error', (e) => {
            console.error(`Request error: ${e.message}`);
            reject(e);
        });

        if (data) req.write(data);
        req.end();
    });
}

async function run() {
    try {
        // Check Login (Valid - Reset Password)
        console.log('\n--- Checking Admin Login API (Reset Password) ---');
        const validPostData = JSON.stringify({ username: 'admin', password: 'admin123' });
        const validLogin = await checkEndpoint('/api/admin/login', 'POST', validPostData);

        if (validLogin.statusCode === 200) {
            console.log('SUCCESS: Valid credentials accepted for "admin".');
            console.log('Body:', validLogin.body.substring(0, 200));
        } else {
            console.log(`FAILURE: Expected 200 for valid login, got ${validLogin.statusCode}`);
            console.log('Body:', validLogin.body.substring(0, 200));
        }

    } catch (error) {
        console.error('Test execution failed:', error);
    }
}

run();

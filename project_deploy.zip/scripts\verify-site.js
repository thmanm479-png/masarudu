const http = require('http');

function checkEndpoint(path, method, data = null) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: '127.0.0.1', // Use IPv4 explicitly
            port: 3000,
            path: path,
            method: method,
            headers: data ? {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(data)
            } : {}
        };

        console.log(`Testing ${method} ${path}...`);

        const req = http.request(options, (res) => {
            console.log(`STATUS: ${res.statusCode}`);
            let body = '';
            res.setEncoding('utf8');
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => {
                resolve({ statusCode: res.statusCode, body });
            });
        });

        req.on('error', (e) => {
            console.error(`Request error: ${e.message}`);
            reject(e);
        });

        if (data) req.write(data);
        req.end();
    });
}

async function run() {
    try {
        // Check Home
        console.log('--- Checking Homepage ---');
        try {
            const home = await checkEndpoint('/', 'GET');
            console.log('Homepage Status:', home.statusCode);
            if (home.statusCode === 200) console.log('SUCCESS: Homepage is accessible.');
            else console.log('WARNING: Homepage returned non-200 status.');
        } catch (e) {
            console.error('Homepage check failed:', e.message);
        }

        // Check Login (Invalid)
        console.log('\n--- Checking Admin Login API (Invalid Credentials) ---');
        const postData = JSON.stringify({ username: 'testuser', password: 'wrongpassword' });
        const login = await checkEndpoint('/api/admin/login', 'POST', postData);

        if (login.statusCode === 401) {
            console.log('SUCCESS: Middleware and API are working correctly (Auth failed as expected).');
        } else if (login.statusCode === 500) {
            console.log('FAILURE: Internal Server Error (Middleware or API crash).');
        } else {
            console.log(`UNKNOWN: Unexpected status code ${login.statusCode}`);
            console.log('Body:', login.body.substring(0, 200));
        }

        // Check Login (Valid)
        console.log('\n--- Checking Admin Login API (Valid Credentials) ---');
        const validPostData = JSON.stringify({ username: 'testadmin_temp_1740669149457', password: 'password123' });
        const validLogin = await checkEndpoint('/api/admin/login', 'POST', validPostData);

        if (validLogin.statusCode === 200) {
            console.log('SUCCESS: Valid credentials accepted. Session cookie likely set.');
            const setCookie = validLogin.body.includes('success')
            console.log('Body:', validLogin.body.substring(0, 200));
        } else {
            console.log(`FAILURE: Expected 200 for valid login, got ${validLogin.statusCode}`);
            console.log('Body:', validLogin.body.substring(0, 200));
        }

    } catch (error) {
        console.error('Test execution failed:', error);
    }
}

run();
